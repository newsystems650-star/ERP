#!/usr/bin/env python3
# ============================================================
# NICORE BOOTSTRAP - PUNTO DE ENTRADA ÚNICO
# ============================================================
# Orquesta TODO el sistema en el orden correcto
# ============================================================

import os
import sys
import time
import subprocess
import json
import shutil
from pathlib import Path
from typing import Dict, List, Tuple
from datetime import datetime

# Colores
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

# Configuración
PROJECT_ROOT = Path(__file__).parent.absolute()
ENV_FILE = PROJECT_ROOT / '.env'
DOCKER_COMPOSE = PROJECT_ROOT / 'docker-compose.yml'
BIN_DIR = PROJECT_ROOT / 'bin'
SRC_DIR = PROJECT_ROOT / 'src'

class NicCoreBootstrap:
    def __init__(self):
        self.start_time = datetime.now()
        self.steps = []
        self.errors = []
        self.env_vars = {}
    
    def log(self, msg: str, level: str = "INFO"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        prefix = {
            "INFO": f"{Colors.CYAN}[{timestamp}] INFO{Colors.RESET}",
            "OK": f"{Colors.GREEN}[{timestamp}] ✅{Colors.RESET}",
            "WARN": f"{Colors.YELLOW}[{timestamp}] ⚠️{Colors.RESET}",
            "ERROR": f"{Colors.RED}[{timestamp}] ❌{Colors.RESET}",
            "STEP": f"{Colors.BLUE}[{timestamp}] ▶️ {Colors.RESET}",
        }.get(level, f"[{timestamp}] {level}")
        print(f"{prefix} {msg}")
        self.steps.append({"time": timestamp, "level": level, "msg": msg})
    
    def run_cmd(self, cmd: List[str], cwd=None, check=True) -> Tuple[bool, str]:
        """Ejecuta un comando y retorna (éxito, salida)"""
        try:
            result = subprocess.run(
                cmd,
                cwd=cwd or PROJECT_ROOT,
                capture_output=True,
                text=True,
                timeout=60
            )
            output = result.stdout + result.stderr
            if result.returncode != 0 and check:
                self.log(f"Comando falló: {' '.join(cmd)}", "ERROR")
                self.log(output, "ERROR")
                return False, output
            return True, output
        except subprocess.TimeoutExpired:
            self.log(f"Timeout: {' '.join(cmd)}", "ERROR")
            return False, "Timeout"
        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            return False, str(e)
    
    def check_system(self) -> bool:
        """Verifica el sistema base"""
        self.log("Verificando sistema...", "STEP")
        
        checks = [
            ("Python", "python3 --version"),
            ("Node", "node --version"),
            ("npm", "npm --version"),
            ("Docker", "docker --version"),
            ("Docker Compose", "docker-compose --version"),
            ("Git", "git --version"),
        ]
        
        all_ok = True
        for name, cmd in checks:
            try:
                result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=5)
                version = result.stdout.strip().split('\n')[0]
                self.log(f"{name}: {version}", "OK")
            except:
                self.log(f"{name}: NO ENCONTRADO", "ERROR")
                all_ok = False
        
        # Verificar PostgreSQL
        try:
            result = subprocess.run(["psql", "--version"], capture_output=True, text=True, timeout=5)
            self.log(f"PostgreSQL: {result.stdout.strip()}", "OK")
        except:
            self.log("PostgreSQL: NO ENCONTRADO (usando Docker)", "WARN")
        
        # Verificar Redis
        try:
            result = subprocess.run(["redis-cli", "--version"], capture_output=True, text=True, timeout=5)
            self.log(f"Redis: {result.stdout.strip()}", "OK")
        except:
            self.log("Redis: NO ENCONTRADO (usando Docker)", "WARN")
        
        return all_ok
    
    def check_env(self) -> bool:
        """Verifica y crea .env si no existe"""
        self.log("Verificando .env...", "STEP")
        
        if ENV_FILE.exists():
            self.log(".env encontrado", "OK")
            # Cargar variables
            with open(ENV_FILE) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        key, val = line.split('=', 1)
                        self.env_vars[key] = val
            return True
        
        self.log(".env no encontrado, creando...", "WARN")
        template = """# NicCore Environment Variables
NODE_ENV=development
PORT=3000
DATABASE_URL=postgresql://nicdev:nicdev123@localhost:5432/nicplatform
REDIS_URL=redis://localhost:6379
JWT_SECRET=niccore_jwt_secret_change_me
API_URL=http://localhost:3000
FRONTEND_URL=http://localhost:5173
"""
        with open(ENV_FILE, 'w') as f:
            f.write(template)
        self.log(".env creado", "OK")
        return True
    
    def check_docker(self) -> bool:
        """Verifica Docker y levanta servicios"""
        self.log("Verificando Docker...", "STEP")
        
        # Verificar que Docker está corriendo
        ok, _ = self.run_cmd(["docker", "ps"], check=False)
        if not ok:
            self.log("Docker no está corriendo", "ERROR")
            return False
        
        self.log("Docker OK", "OK")
        
        # Levantar servicios
        self.log("Levantando servicios con Docker Compose...", "STEP")
        ok, _ = self.run_cmd(["docker-compose", "up", "-d"])
        if not ok:
            self.log("Error levantando Docker Compose", "ERROR")
            return False
        
        self.log("Servicios Docker levantados", "OK")
        return True
    
    def wait_for_postgres(self, timeout: int = 30) -> bool:
        """Espera que PostgreSQL esté listo"""
        self.log("Esperando PostgreSQL...", "STEP")
        
        for i in range(timeout):
            ok, _ = self.run_cmd([
                "docker", "exec", "nic_db", 
                "pg_isready", "-U", "nicdev"
            ], check=False)
            if ok:
                self.log("PostgreSQL listo", "OK")
                return True
            time.sleep(1)
            if i % 5 == 0:
                self.log(f"Esperando... {i}s", "WARN")
        
        self.log("Timeout esperando PostgreSQL", "ERROR")
        return False
    
    def wait_for_redis(self, timeout: int = 15) -> bool:
        """Espera que Redis esté listo"""
        self.log("Esperando Redis...", "STEP")
        
        for i in range(timeout):
            ok, _ = self.run_cmd([
                "docker", "exec", "nic_redis", 
                "redis-cli", "ping"
            ], check=False)
            if ok:
                self.log("Redis listo", "OK")
                return True
            time.sleep(1)
        
        self.log("Timeout esperando Redis", "ERROR")
        return False
    
    def run_prisma_migrations(self) -> bool:
        """Ejecuta migraciones de Prisma"""
        self.log("Ejecutando migraciones Prisma...", "STEP")
        
        # Generar cliente
        ok, _ = self.run_cmd(["npx", "prisma", "generate"])
        if not ok:
            self.log("Error generando Prisma client", "ERROR")
            return False
        
        # Ejecutar migraciones
        ok, _ = self.run_cmd(["npx", "prisma", "migrate", "dev", "--name", "init"])
        if not ok:
            self.log("Error ejecutando migraciones", "ERROR")
            return False
        
        self.log("Migraciones Prisma ejecutadas", "OK")
        return True
    
    def compile_engines(self) -> bool:
        """Compila los motores C++"""
        self.log("Compilando motores C++...", "STEP")
        
        # Crear directorio bin
        BIN_DIR.mkdir(exist_ok=True)
        
        # Compilar niccore_engine
        cpp_file = SRC_DIR / 'native' / 'niccore_engine.cpp'
        if cpp_file.exists():
            ok, _ = self.run_cmd([
                "g++", "-O3", "-std=c++17", 
                "-o", str(BIN_DIR / 'niccore_engine'),
                str(cpp_file),
                "-lsqlite3"
            ])
            if ok:
                self.log("niccore_engine compilado", "OK")
            else:
                self.log("Error compilando niccore_engine", "ERROR")
                return False
        
        # Compilar wood_engine
        cpp_file = SRC_DIR / 'native' / 'wood_engine.cpp'
        if cpp_file.exists():
            ok, _ = self.run_cmd([
                "g++", "-O3", "-std=c++17", 
                "-o", str(BIN_DIR / 'wood_engine'),
                str(cpp_file),
                "-lsqlite3"
            ])
            if ok:
                self.log("wood_engine compilado", "OK")
            else:
                self.log("Error compilando wood_engine", "ERROR")
                return False
        
        # Compilar ejecutables de src/core
        core_dir = SRC_DIR / 'core'
        for cpp in core_dir.glob("*.cpp"):
            name = cpp.stem
            ok, _ = self.run_cmd([
                "g++", "-O3", "-std=c++17",
                "-o", str(BIN_DIR / name),
                str(cpp),
                "-lpthread"
            ])
            if ok:
                self.log(f"{name} compilado", "OK")
        
        self.log("Motores C++ compilados", "OK")
        return True
    
    def start_api(self) -> bool:
        """Inicia la API en segundo plano"""
        self.log("Iniciando API...", "STEP")
        
        # Matar proceso anterior si existe
        self.run_cmd(["pkill", "-f", "tsx watch src/index.ts"], check=False)
        
        # Iniciar en background
        cmd = ["npm", "run", "dev:backend"]
        process = subprocess.Popen(
            cmd,
            cwd=PROJECT_ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
        self.log(f"API iniciada (PID: {process.pid})", "OK")
        return True
    
    def start_frontend(self) -> bool:
        """Inicia el frontend en segundo plano"""
        self.log("Iniciando Frontend...", "STEP")
        
        # Matar proceso anterior
        self.run_cmd(["pkill", "-f", "vite"], check=False)
        
        # Iniciar en background
        cmd = ["npm", "run", "dev:client"]
        process = subprocess.Popen(
            cmd,
            cwd=PROJECT_ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
        self.log(f"Frontend iniciado (PID: {process.pid})", "OK")
        return True
    
    def health_check(self) -> bool:
        """Verifica que todo esté funcionando"""
        self.log("Verificando health check...", "STEP")
        
        import requests
        try:
            resp = requests.get("http://localhost:3000/health", timeout=5)
            if resp.status_code == 200:
                self.log("Health check OK", "OK")
                return True
        except:
            pass
        
        self.log("Health check falló", "ERROR")
        return False
    
    def run(self):
        """Ejecuta todo el bootstrap"""
        self.log("=" * 50, "INFO")
        self.log("NICCORE BOOTSTRAP", "INFO")
        self.log("=" * 50, "INFO")
        
        # 1. Verificar sistema
        if not self.check_system():
            self.log("Sistema incompleto", "ERROR")
            return False
        
        # 2. Verificar .env
        if not self.check_env():
            return False
        
        # 3. Verificar Docker
        if not self.check_docker():
            return False
        
        # 4. Esperar PostgreSQL
        if not self.wait_for_postgres():
            return False
        
        # 5. Esperar Redis
        if not self.wait_for_redis():
            return False
        
        # 6. Ejecutar migraciones
        if not self.run_prisma_migrations():
            return False
        
        # 7. Compilar motores
        if not self.compile_engines():
            return False
        
        # 8. Iniciar API
        if not self.start_api():
            return False
        
        # 9. Iniciar Frontend
        if not self.start_frontend():
            return False
        
        # 10. Health check
        time.sleep(5)
        if not self.health_check():
            self.log("Health check falló, pero el sistema podría estar iniciando", "WARN")
        
        # 11. Resumen final
        elapsed = datetime.now() - self.start_time
        self.log("=" * 50, "INFO")
        self.log(f"✅ NICORE LISTO en {elapsed.total_seconds():.1f}s", "OK")
        self.log("=" * 50, "INFO")
        self.log("📡 API: http://localhost:3000", "INFO")
        self.log("🎨 Frontend: http://localhost:5173", "INFO")
        self.log("📊 Health: http://localhost:3000/health", "INFO")
        self.log("=" * 50, "INFO")
        
        return True

if __name__ == "__main__":
    bootstrap = NicCoreBootstrap()
    success = bootstrap.run()
    sys.exit(0 if success else 1)

# ============================================================
# VERIFICACIÓN DE FIRMAS
# ============================================================

def check_signatures():
    log("▶️  Verificando firmas de archivos...")
    result = run_command("./signature_system.sh verify")
    if result.returncode != 0:
        log("⚠️ Algunas firmas no coinciden", "WARN")
    else:
        log("✅ Firmas verificadas", "OK")

# Agregar al main
check_signatures()
