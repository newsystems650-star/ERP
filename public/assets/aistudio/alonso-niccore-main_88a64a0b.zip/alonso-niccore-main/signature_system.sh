#!/bin/bash
# ============================================================
# NICORE - SISTEMA DE FIRMAS Y REGISTRO DE ARCHIVOS
# ============================================================

SIGNATURE_DIR="$HOME/alonso-niccore/.signatures"
REGISTRY_FILE="$HOME/alonso-niccore/.registry.log"
PROJECT_DIR="$HOME/alonso-niccore"

mkdir -p "$SIGNATURE_DIR"

# ============================================================
# 1. GENERAR FIRMA PARA UN ARCHIVO
# ============================================================
generate_signature() {
    local file="$1"
    if [ ! -f "$file" ]; then
        echo "❌ Archivo no encontrado: $file"
        return 1
    fi
    
    local hash=$(sha256sum "$file" | awk '{print $1}')
    local size=$(stat -c%s "$file" 2>/dev/null || stat -f%z "$file" 2>/dev/null)
    local modified=$(stat -c%y "$file" 2>/dev/null || stat -f%Sm "$file" 2>/dev/null)
    local filename=$(basename "$file")
    local rel_path=${file#$PROJECT_DIR/}
    
    echo "{
        \"file\": \"$rel_path\",
        \"filename\": \"$filename\",
        \"hash\": \"$hash\",
        \"size\": $size,
        \"modified\": \"$modified\",
        \"signature_date\": \"$(date -Iseconds)\"
    }" > "$SIGNATURE_DIR/$(echo $rel_path | tr '/' '_').sig"
    
    echo "✅ Firma generada: $rel_path"
}

# ============================================================
# 2. REGISTRAR UN CAMBIO
# ============================================================
log_change() {
    local file="$1"
    local action="$2"
    local user="${USER:-unknown}"
    
    echo "[$(date -Iseconds)] [$user] [$action] $file" >> "$REGISTRY_FILE"
    echo "📝 Registrado: $action $file"
}

# ============================================================
# 3. VERIFICAR FIRMAS
# ============================================================
verify_signatures() {
    echo "🔍 Verificando firmas..."
    local errors=0
    
    for sig_file in "$SIGNATURE_DIR"/*.sig; do
        [ -f "$sig_file" ] || continue
        
        local rel_path=$(cat "$sig_file" | grep -o '"file": "[^"]*"' | head -1 | cut -d'"' -f4)
        local expected_hash=$(cat "$sig_file" | grep -o '"hash": "[^"]*"' | head -1 | cut -d'"' -f4)
        local full_path="$PROJECT_DIR/$rel_path"
        
        if [ ! -f "$full_path" ]; then
            echo "❌ Archivo eliminado: $rel_path"
            log_change "$rel_path" "DELETED"
            ((errors++))
            continue
        fi
        
        local current_hash=$(sha256sum "$full_path" | awk '{print $1}')
        if [ "$current_hash" != "$expected_hash" ]; then
            echo "⚠️ Archivo modificado: $rel_path"
            log_change "$rel_path" "MODIFIED"
            ((errors++))
        else
            echo "✅ OK: $rel_path"
        fi
    done
    
    if [ $errors -eq 0 ]; then
        echo "✅ Todas las firmas verificadas"
    else
        echo "⚠️ $errors archivos con cambios detectados"
    fi
}

# ============================================================
# 4. GENERAR FIRMAS PARA TODOS LOS ARCHIVOS IMPORTANTES
# ============================================================
generate_all_signatures() {
    echo "📦 Generando firmas para todos los archivos..."
    
    # Archivos importantes
    find "$PROJECT_DIR" -type f \
        -not -path "*/node_modules/*" \
        -not -path "*/.git/*" \
        -not -path "*/build/*" \
        -not -path "*/logs/*" \
        -not -path "*/backups/*" \
        -not -path "*/.signatures/*" \
        -not -name "*.log" \
        -not -name "*.lock" \
        | while read -r file; do
            generate_signature "$file"
            log_change "${file#$PROJECT_DIR/}" "SIGNED"
        done
    
    echo "✅ Todas las firmas generadas"
}

# ============================================================
# 5. MOSTRAR REGISTRO
# ============================================================
show_registry() {
    if [ ! -f "$REGISTRY_FILE" ]; then
        echo "📋 No hay registros aún"
        return
    fi
    
    echo "📋 REGISTRO DE CAMBIOS"
    echo "=================================================="
    tail -50 "$REGISTRY_FILE"
}

# ============================================================
# 6. MENÚ PRINCIPAL
# ============================================================
case "$1" in
    gen|generate)
        generate_all_signatures
        ;;
    verify)
        verify_signatures
        ;;
    reg|registry)
        show_registry
        ;;
    file|f)
        if [ -z "$2" ]; then
            echo "Uso: $0 file <ruta>"
            exit 1
        fi
        generate_signature "$2"
        log_change "$2" "SIGNED"
        ;;
    *)
        echo "NICORE - SISTEMA DE FIRMAS Y REGISTRO"
        echo ""
        echo "Uso: $0 [comando] [opciones]"
        echo ""
        echo "Comandos:"
        echo "  generate, gen    - Generar firmas para todos los archivos"
        echo "  verify           - Verificar firmas existentes"
        echo "  registry, reg    - Mostrar registro de cambios"
        echo "  file, f <ruta>   - Firmar un archivo específico"
        echo ""
        echo "Ejemplos:"
        echo "  $0 gen           # Generar todas las firmas"
        echo "  $0 verify        # Verificar cambios"
        echo "  $0 reg           # Ver registro"
        echo "  $0 f src/index.ts # Firmar un archivo"
        ;;
esac
