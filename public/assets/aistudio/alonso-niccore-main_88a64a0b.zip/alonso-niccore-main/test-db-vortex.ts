const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function test() {
  try {
    console.log("📡 Conectando al motor Vortex en Postgres...");
    const event = await prisma.woodEvent.create({
      data: {
        tenantId: 'niccore-master',
        userId: 'admin-alonso',
        type: 'WOOD_VORTEX_INIT',
        payload: { status: 'GOD_MODE_ACTIVE', engine: 'C++' }
      }
    });
    console.log("✅ ÉXITO: Evento guardado con ID:", event.id);
  } catch (e) {
    console.error("❌ ERROR DE DB:", e);
  } finally {
    await prisma.$disconnect();
  }
}
test();
