import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Importamos tus dos módulos soberanos
import NicCoreVentas from './NicCoreVentas';
import NicEditor from './NicEditor'; // Asegúrate de que el archivo exista con este nombre

const App = () => {
  return (
    <BrowserRouter>
      <div style={{ margin: 0, padding: 0, height: '100vh', width: '100vw' }}>
        <Routes>
          {/* Ruta principal: Ventanilla de Ventas */}
          <Route path="/" element={<NicCoreVentas />} />
          
          {/* Ruta secundaria: NIC-Editor */}
          <Route path="/editor" element={<NicEditor />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;
