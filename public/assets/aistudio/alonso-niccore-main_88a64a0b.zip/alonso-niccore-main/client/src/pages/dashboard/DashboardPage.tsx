import { useQuery } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { StatCard } from '../../components/ui/Card'
import { DollarSign, ClipboardList, AlertTriangle, FileText, TrendingUp, Users } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

export default function DashboardPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get('/dashboard').then(r => r.data),
    refetchInterval: 30000,
  })

  if (isLoading) return (
    <div className="flex items-center justify-center h-full">
      <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const d = data || {}
  const fmt = (n: number) => '$' + n.toLocaleString('es-MX', { minimumFractionDigits: 2 })

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-gray-500 text-sm mt-1">Resumen del día</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Ventas hoy" value={fmt(d.resumenHoy?.totalVentas || 0)} icon={DollarSign} color="green" sub={`${d.resumenHoy?.ticketsConfirmados || 0} tickets`} />
        <StatCard label="Pendientes" value={d.resumenHoy?.ticketsPendientes || 0} icon={ClipboardList} color="yellow" />
        <StatCard label="Alertas stock" value={d.alertasStock?.count || 0} icon={AlertTriangle} color={d.alertasStock?.count > 0 ? 'red' : 'blue'} />
        <StatCard label="Cotizaciones" value={d.cotizaciones?.converted || 0} icon={FileText} color="purple" sub="convertidas hoy" />
      </div>

      {/* Gráfica ventas semana */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h2 className="text-sm font-medium text-gray-400 mb-4">Ventas últimos 7 días</h2>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={d.ventasSemana || []}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
            <XAxis dataKey="fecha" tickFormatter={(v) => new Date(v).toLocaleDateString('es-MX', { weekday: 'short' })} tick={{ fill: '#6b7280', fontSize: 12 }} />
            <YAxis tick={{ fill: '#6b7280', fontSize: 12 }} tickFormatter={(v) => '$' + (v/1000).toFixed(0) + 'k'} />
            <Tooltip
              contentStyle={{ backgroundColor: '#111827', border: '1px solid #1f2937', borderRadius: '8px' }}
              formatter={(v: number) => [fmt(v), 'Ventas']}
              labelFormatter={(v) => new Date(v).toLocaleDateString('es-MX')}
            />
            <Bar dataKey="total" fill="#3b82f6" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Últimos tickets + alertas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Últimos tickets */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <h2 className="text-sm font-medium text-gray-400 mb-4">Últimos tickets</h2>
          <div className="space-y-3">
            {(d.ultimosTickets || []).map((t: any) => (
              <div key={t.id} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{t.code}</p>
                  <p className="text-xs text-gray-500">{t.usuario}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{fmt(t.total)}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    t.status === 'CONFIRMED' ? 'bg-green-400/10 text-green-400' :
                    t.status === 'PENDING' ? 'bg-yellow-400/10 text-yellow-400' :
                    'bg-red-400/10 text-red-400'
                  }`}>{t.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Alertas stock */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <h2 className="text-sm font-medium text-gray-400 mb-4 flex items-center gap-2">
            <AlertTriangle size={14} className="text-yellow-400" />
            Alertas de stock bajo
          </h2>
          {d.alertasStock?.count === 0 ? (
            <p className="text-sm text-gray-500">✅ Todo el inventario está bien</p>
          ) : (
            <div className="space-y-3">
              {(d.alertasStock?.productos || []).map((p: any) => (
                <div key={p.sku} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{p.nombre}</p>
                    <p className="text-xs text-gray-500">{p.sku}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-red-400 font-medium">{p.disponible} {p.unidad}</p>
                    <p className="text-xs text-gray-500">mín: {p.minimo}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
