import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Card, StatCard } from '../../components/ui/Card'
import { Plus, DollarSign, TrendingUp, TrendingDown, Users, X } from 'lucide-react'
import clsx from 'clsx'

const fmt = (n: number) => '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 2 })

const EXPENSE_TYPES = ['SALARY','SUPPLIER','RENT','UTILITIES','MAINTENANCE','TAXES','OTHER']
const TYPE_LABELS: Record<string, string> = {
  SALARY: 'Sueldos', SUPPLIER: 'Proveedores', RENT: 'Renta',
  UTILITIES: 'Servicios', MAINTENANCE: 'Mantenimiento', TAXES: 'Impuestos', OTHER: 'Otros'
}

export default function AccountingPage() {
  const [tab, setTab] = useState<'resumen' | 'gastos' | 'nomina' | 'empleados'>('resumen')
  const [showExpenseForm, setShowExpenseForm] = useState(false)
  const [showEmployeeForm, setShowEmployeeForm] = useState(false)
  const [expenseForm, setExpenseForm] = useState({ type: 'OTHER', category: '', description: '', amount: '', applyTax: false })
  const [employeeForm, setEmployeeForm] = useState({ name: '', position: '', salary: '', payPeriod: 'BIWEEKLY', startDate: '' })
  const qc = useQueryClient()

  const { data: resumen } = useQuery({
    queryKey: ['accounting-resumen'],
    queryFn: () => api.get('/accounting/resumen').then(r => r.data),
  })

  const { data: gastos } = useQuery({
    queryKey: ['accounting-gastos'],
    queryFn: () => api.get('/accounting/gastos', { params: { limit: 50 } }).then(r => r.data),
    enabled: tab === 'gastos',
  })

  const { data: empleados } = useQuery({
    queryKey: ['empleados'],
    queryFn: () => api.get('/accounting/empleados').then(r => r.data),
    enabled: tab === 'empleados' || tab === 'nomina',
  })

  const { data: nomina } = useQuery({
    queryKey: ['nomina'],
    queryFn: () => api.get('/accounting/nomina').then(r => r.data),
    enabled: tab === 'nomina',
  })

  const createExpense = useMutation({
    mutationFn: (data: any) => api.post('/accounting/gastos', data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['accounting-gastos'] }); qc.invalidateQueries({ queryKey: ['accounting-resumen'] }); setShowExpenseForm(false) },
  })

  const createEmployee = useMutation({
    mutationFn: (data: any) => api.post('/accounting/empleados', data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['empleados'] }); setShowEmployeeForm(false) },
  })

  const payNomina = useMutation({
    mutationFn: (id: string) => api.patch(`/accounting/nomina/${id}/pagar`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['nomina'] }),
  })

  const margen = resumen?.margen || '0%'
  const margenPositivo = !margen.startsWith('-')

  return (
    <div className="p-6 space-y-6">
      {/* Modales */}
      {showExpenseForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-md">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
              <h2 className="font-bold">Nuevo gasto</h2>
              <button onClick={() => setShowExpenseForm(false)}><X size={18} className="text-gray-500" /></button>
            </div>
            <form onSubmit={e => { e.preventDefault(); createExpense.mutate({ ...expenseForm, amount: Number(expenseForm.amount) }) }}
              className="p-6 space-y-4">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Tipo</label>
                <select value={expenseForm.type} onChange={e => setExpenseForm({...expenseForm, type: e.target.value})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none">
                  {EXPENSE_TYPES.map(t => <option key={t} value={t}>{TYPE_LABELS[t]}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Categoría</label>
                <input value={expenseForm.category} onChange={e => setExpenseForm({...expenseForm, category: e.target.value})} required
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Descripción</label>
                <input value={expenseForm.description} onChange={e => setExpenseForm({...expenseForm, description: e.target.value})} required
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Monto</label>
                <input type="number" step="0.01" value={expenseForm.amount} onChange={e => setExpenseForm({...expenseForm, amount: e.target.value})} required
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={expenseForm.applyTax} onChange={e => setExpenseForm({...expenseForm, applyTax: e.target.checked})}
                  className="accent-blue-500" />
                <span className="text-sm text-gray-300">Aplicar IVA 16%</span>
              </label>
              <div className="flex justify-end gap-3">
                <Button type="button" variant="secondary" onClick={() => setShowExpenseForm(false)}>Cancelar</Button>
                <Button type="submit" loading={createExpense.isPending}>Guardar</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Contabilidad</h1>
        {tab === 'gastos' && <Button onClick={() => setShowExpenseForm(true)}><Plus size={16} />Nuevo gasto</Button>}
        {tab === 'empleados' && <Button onClick={() => setShowEmployeeForm(true)}><Plus size={16} />Nuevo empleado</Button>}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-900 border border-gray-800 rounded-xl p-1 w-fit flex-wrap">
        {(['resumen', 'gastos', 'nomina', 'empleados'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={clsx('px-4 py-2 rounded-lg text-sm font-medium transition-colors capitalize', {
              'bg-blue-600 text-white': tab === t,
              'text-gray-400 hover:text-white': tab !== t,
            })}>
            {t === 'nomina' ? 'Nómina' : t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === 'resumen' && resumen && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard label="Ventas" value={fmt(resumen.ventas?.total || 0)} icon={TrendingUp} color="green"
              sub={`${resumen.ventas?.tickets || 0} tickets`} />
            <StatCard label="Gastos" value={fmt(resumen.gastos?.total || 0)} icon={TrendingDown} color="red" />
            <StatCard label="Nómina" value={fmt(resumen.nomina?.total || 0)} icon={Users} color="yellow" />
            <StatCard label="Utilidad" value={fmt(resumen.utilidad || 0)} icon={DollarSign}
              color={margenPositivo ? 'green' : 'red'} sub={`Margen: ${margen}`} />
          </div>

          <Card>
            <h2 className="text-sm font-medium text-gray-400 mb-4">Gastos por categoría</h2>
            <div className="space-y-3">
              {(resumen.gastos?.porTipo || []).map((g: any) => (
                <div key={g.tipo} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-gray-400">{TYPE_LABELS[g.tipo] || g.tipo}</span>
                    <span className="text-xs text-gray-600">{g.count} registros</span>
                  </div>
                  <span className="font-medium">{fmt(g.total)}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {tab === 'gastos' && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                <th className="text-left px-6 py-3">Descripción</th>
                <th className="text-left px-6 py-3">Tipo</th>
                <th className="text-left px-6 py-3">Categoría</th>
                <th className="text-right px-6 py-3">Total</th>
                <th className="text-left px-6 py-3">Fecha</th>
              </tr>
            </thead>
            <tbody>
              {(gastos?.data || []).map((g: any) => (
                <tr key={g.id} className="border-b border-gray-800/50">
                  <td className="px-6 py-4">{g.description}</td>
                  <td className="px-6 py-4 text-gray-400">{TYPE_LABELS[g.type]}</td>
                  <td className="px-6 py-4 text-gray-400">{g.category}</td>
                  <td className="px-6 py-4 text-right font-medium">{fmt(g.total)}</td>
                  <td className="px-6 py-4 text-gray-500 text-xs">{new Date(g.date).toLocaleDateString('es-MX')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'empleados' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {(empleados?.data || []).map((e: any) => (
            <Card key={e.id}>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-purple-600/20 flex items-center justify-center text-purple-400 font-bold">
                  {e.name[0]}
                </div>
                <div>
                  <p className="font-medium">{e.name}</p>
                  <p className="text-xs text-gray-500">{e.position}</p>
                </div>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Sueldo</span>
                <span className="font-bold text-green-400">{fmt(e.salary)}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500">Período</span>
                <span className="text-gray-300">{e.payPeriod}</span>
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab === 'nomina' && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                <th className="text-left px-6 py-3">Empleado</th>
                <th className="text-left px-6 py-3">Período</th>
                <th className="text-right px-6 py-3">Total</th>
                <th className="text-center px-6 py-3">Estado</th>
                <th className="px-6 py-3" />
              </tr>
            </thead>
            <tbody>
              {(nomina?.data || []).map((n: any) => (
                <tr key={n.id} className="border-b border-gray-800/50">
                  <td className="px-6 py-4 font-medium">{n.employee?.name}</td>
                  <td className="px-6 py-4 text-gray-400 text-xs">
                    {new Date(n.periodStart).toLocaleDateString('es-MX')} — {new Date(n.periodEnd).toLocaleDateString('es-MX')}
                  </td>
                  <td className="px-6 py-4 text-right font-bold">{fmt(n.total)}</td>
                  <td className="px-6 py-4 text-center">
                    <span className={clsx('text-xs px-2 py-0.5 rounded-full', n.paid
                      ? 'bg-green-400/10 text-green-400'
                      : 'bg-yellow-400/10 text-yellow-400')}>
                      {n.paid ? 'Pagado' : 'Pendiente'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {!n.paid && (
                      <Button size="sm" onClick={() => payNomina.mutate(n.id)} loading={payNomina.isPending}>
                        Pagar
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
