import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { Plus, Package, Search, AlertTriangle, Edit2, X } from 'lucide-react'
import clsx from 'clsx'

const fmt = (n: number) => '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 2 })
const UNITS = ['M2','M3','KG','LITER','LINEAR_M','FEET','INCH','PIECE']

function ProductForm({ product, onClose }: { product?: any; onClose: () => void }) {
  const qc = useQueryClient()
  const [form, setForm] = useState({
    name: product?.name || '',
    sku: product?.sku || '',
    unit: product?.unit || 'PIECE',
    price: product?.price || '',
    description: product?.description || '',
    initialStock: '',
    minAlert: product?.stock?.minAlert || '',
  })
  const [error, setError] = useState('')

  const save = useMutation({
    mutationFn: (data: any) => product
      ? api.put(`/products/${product.id}`, data)
      : api.post('/products', data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['products'] }); onClose() },
    onError: (err: any) => setError(err.response?.data?.error?.message || 'Error'),
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    save.mutate({
      name: form.name,
      sku: form.sku.toUpperCase(),
      unit: form.unit,
      price: Number(form.price),
      description: form.description || undefined,
      initialStock: form.initialStock ? Number(form.initialStock) : undefined,
      minAlert: form.minAlert ? Number(form.minAlert) : undefined,
    })
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-lg">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <h2 className="font-bold">{product ? 'Editar producto' : 'Nuevo producto'}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="text-xs text-gray-500 mb-1 block">Nombre</label>
              <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} required
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">SKU</label>
              <input value={form.sku} onChange={e => setForm({...form, sku: e.target.value})} required
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Unidad</label>
              <select value={form.unit} onChange={e => setForm({...form, unit: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500">
                {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Precio</label>
              <input type="number" step="0.01" value={form.price} onChange={e => setForm({...form, price: e.target.value})} required
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            {!product && (
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Stock inicial</label>
                <input type="number" step="0.01" value={form.initialStock} onChange={e => setForm({...form, initialStock: e.target.value})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
              </div>
            )}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Alerta mínima</label>
              <input type="number" step="0.01" value={form.minAlert} onChange={e => setForm({...form, minAlert: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
          </div>
          {error && <p className="text-xs text-red-400 bg-red-400/10 px-3 py-2 rounded-lg">{error}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
            <Button type="submit" loading={save.isPending}>Guardar</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function ProductsPage() {
  const [search, setSearch] = useState('')
  const [modal, setModal] = useState<'new' | 'edit' | null>(null)
  const [selected, setSelected] = useState<any>(null)
  const [tab, setTab] = useState<'products' | 'inventory'>('products')

  const { data: products, isLoading } = useQuery({
    queryKey: ['products', search],
    queryFn: () => api.get('/products', { params: { search: search || undefined, limit: 100 } }).then(r => r.data),
  })

  const { data: inventory } = useQuery({
    queryKey: ['inventory'],
    queryFn: () => api.get('/inventory').then(r => r.data),
    enabled: tab === 'inventory',
  })

  const { data: alerts } = useQuery({
    queryKey: ['inventory-alerts'],
    queryFn: () => api.get('/inventory/alerts').then(r => r.data),
  })

  return (
    <div className="p-6 space-y-6">
      {modal && (
        <ProductForm
          product={modal === 'edit' ? selected : undefined}
          onClose={() => { setModal(null); setSelected(null) }}
        />
      )}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Productos e Inventario</h1>
          {alerts?.count > 0 && (
            <p className="text-sm text-red-400 flex items-center gap-1 mt-1">
              <AlertTriangle size={14} />{alerts.count} productos con stock bajo
            </p>
          )}
        </div>
        <Button onClick={() => setModal('new')}><Plus size={16} />Nuevo producto</Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-900 border border-gray-800 rounded-xl p-1 w-fit">
        {(['products', 'inventory'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={clsx('px-4 py-2 rounded-lg text-sm font-medium transition-colors', {
              'bg-blue-600 text-white': tab === t,
              'text-gray-400 hover:text-white': tab !== t,
            })}>
            {t === 'products' ? 'Productos' : 'Inventario'}
          </button>
        ))}
      </div>

      {/* Búsqueda */}
      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
        <input placeholder="Buscar..." value={search} onChange={e => setSearch(e.target.value)}
          className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500" />
      </div>

      {tab === 'products' ? (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          {isLoading ? (
            <div className="flex justify-center py-16">
              <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                  <th className="text-left px-6 py-3">Producto</th>
                  <th className="text-left px-6 py-3">SKU</th>
                  <th className="text-left px-6 py-3">Unidad</th>
                  <th className="text-right px-6 py-3">Precio</th>
                  <th className="text-right px-6 py-3">Stock</th>
                  <th className="px-6 py-3" />
                </tr>
              </thead>
              <tbody>
                {(products?.data || []).map((p: any) => {
                  const stock = Number(p.stock?.quantity || 0)
                  const minAlert = Number(p.stock?.minAlert || 0)
                  const lowStock = minAlert > 0 && stock <= minAlert
                  return (
                    <tr key={p.id} className="border-b border-gray-800/50 hover:bg-gray-800/30">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Package size={14} className="text-gray-600" />
                          <span className="font-medium">{p.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono text-gray-400">{p.sku}</td>
                      <td className="px-6 py-4 text-gray-400">{p.unit}</td>
                      <td className="px-6 py-4 text-right font-medium">{fmt(p.price)}</td>
                      <td className="px-6 py-4 text-right">
                        <span className={clsx('font-medium', lowStock ? 'text-red-400' : 'text-white')}>
                          {stock}
                          {lowStock && <AlertTriangle size={12} className="inline ml-1" />}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <Button variant="ghost" size="sm" onClick={() => { setSelected(p); setModal('edit') }}>
                          <Edit2 size={14} />
                        </Button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {(inventory?.data || []).map((s: any) => (
            <Card key={s.id} className={clsx(s.alert ? 'border-red-500/50' : '')}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-medium">{s.product.name}</p>
                  <p className="text-xs text-gray-500">{s.product.sku}</p>
                </div>
                {s.alert && <AlertTriangle size={16} className="text-red-400 shrink-0" />}
              </div>
              <div className="flex items-end justify-between">
                <div>
                  <p className={clsx('text-3xl font-bold', s.alert ? 'text-red-400' : 'text-white')}>
                    {Number(s.quantity).toFixed(2)}
                  </p>
                  <p className="text-xs text-gray-500">{s.product.unit}</p>
                </div>
                {s.minAlert && (
                  <p className="text-xs text-gray-500">mín: {Number(s.minAlert)}</p>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
