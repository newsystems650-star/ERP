import { useState, useRef } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import {
  MapPin, CheckCircle, Clock, Package, Camera,
  Truck, Phone, ChevronDown, ChevronUp, AlertCircle
} from 'lucide-react'
import clsx from 'clsx'

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  PENDING:   { label: 'Pendiente',  color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  ASSIGNED:  { label: 'Asignado',   color: 'text-blue-400',   bg: 'bg-blue-400/10' },
  IN_ROUTE:  { label: 'En ruta',    color: 'text-purple-400', bg: 'bg-purple-400/10' },
  ARRIVED:   { label: 'Llegué',     color: 'text-orange-400', bg: 'bg-orange-400/10' },
  DELIVERED: { label: 'Entregado',  color: 'text-green-400',  bg: 'bg-green-400/10' },
  FAILED:    { label: 'Fallido',    color: 'text-red-400',    bg: 'bg-red-400/10' },
}

function DeliveryCard({ delivery, onAction }: { delivery: any; onAction: () => void }) {
  const [expanded, setExpanded] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [photo, setPhoto] = useState<string | null>(null)
  const [notes, setNotes] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)
  const qc = useQueryClient()

  const s = STATUS_CONFIG[delivery.status]

  const arrived = useMutation({
    mutationFn: () => api.patch(`/deliveries/${delivery.id}/arrived`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['driver-deliveries'] }); onAction() },
  })

  const complete = useMutation({
    mutationFn: () => api.patch(`/deliveries/${delivery.id}/complete`, {
      photoBase64: photo || undefined,
      driverNotes: notes || undefined,
    }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['driver-deliveries'] }); onAction() },
  })

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => setPhoto(reader.result as string)
    reader.readAsDataURL(file)
  }

  const isCompleted = delivery.status === 'DELIVERED'

  return (
    <div className={clsx(
      'rounded-2xl border overflow-hidden transition-all',
      isCompleted ? 'bg-gray-900/50 border-gray-800/50 opacity-70' : 'bg-gray-900 border-gray-800'
    )}>
      {/* Header */}
      <div className="p-4" onClick={() => setExpanded(!expanded)}>
        <div className="flex items-start justify-between mb-2">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono text-blue-400">{delivery.ticket?.code}</span>
              {delivery.freightFree && (
                <span className="text-xs bg-green-400/10 text-green-400 px-2 py-0.5 rounded-full">Flete gratis</span>
              )}
            </div>
            <span className={clsx('text-xs px-2 py-0.5 rounded-full font-medium', s.bg, s.color)}>
              {s.label}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {delivery.eta && !isCompleted && (
              <div className="text-right">
                <p className="text-xs text-gray-500">ETA</p>
                <p className="text-sm font-bold text-white">{delivery.eta}</p>
              </div>
            )}
            {expanded ? <ChevronUp size={16} className="text-gray-500" /> : <ChevronDown size={16} className="text-gray-500" />}
          </div>
        </div>

        <div className="flex items-start gap-2">
          <MapPin size={14} className="text-gray-500 mt-0.5 shrink-0" />
          <p className="text-sm text-gray-300 leading-tight">{delivery.address}</p>
        </div>

        {delivery.scheduledAt && (
          <div className="flex items-center gap-2 mt-2">
            <Clock size={12} className="text-gray-500" />
            <p className="text-xs text-gray-500">
              {new Date(delivery.scheduledAt).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
        )}
      </div>

      {/* Expandido */}
      {expanded && (
        <div className="px-4 pb-4 space-y-4 border-t border-gray-800 pt-4">
          {/* Contacto */}
          {(delivery.contactName || delivery.contactPhone) && (
            <div className="bg-gray-800 rounded-xl p-3">
              <p className="text-xs text-gray-500 mb-1">Contacto</p>
              {delivery.contactName && <p className="text-sm font-medium">{delivery.contactName}</p>}
              {delivery.contactPhone && (
                <a href={`tel:${delivery.contactPhone}`}
                  className="flex items-center gap-2 text-blue-400 text-sm mt-1">
                  <Phone size={14} />{delivery.contactPhone}
                </a>
              )}
            </div>
          )}

          {/* Notas */}
          {delivery.notes && (
            <div className="bg-gray-800 rounded-xl p-3">
              <p className="text-xs text-gray-500 mb-1">Instrucciones</p>
              <p className="text-sm text-gray-300">{delivery.notes}</p>
            </div>
          )}

          {/* Productos */}
          {delivery.ticket?.items?.length > 0 && (
            <div className="bg-gray-800 rounded-xl p-3">
              <p className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                <Package size={12} />Productos
              </p>
              <div className="space-y-1">
                {delivery.ticket.items.map((item: any) => (
                  <p key={item.id} className="text-xs text-gray-300">
                    • {Number(item.quantity)} {item.unit} — {item.product?.name}
                  </p>
                ))}
              </div>
            </div>
          )}

          {/* Acciones según estado */}
          {!isCompleted && (
            <div className="space-y-3">
              {delivery.status === 'ARRIVED' && (
                <>
                  {/* Foto */}
                  <div>
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      className="hidden"
                      onChange={handlePhoto}
                    />
                    {photo ? (
                      <div className="relative">
                        <img src={photo} alt="Evidencia" className="w-full h-40 object-cover rounded-xl" />
                        <button onClick={() => setPhoto(null)}
                          className="absolute top-2 right-2 bg-red-600 text-white text-xs px-2 py-1 rounded-lg">
                          Cambiar
                        </button>
                      </div>
                    ) : (
                      <button onClick={() => fileRef.current?.click()}
                        className="w-full border-2 border-dashed border-gray-700 rounded-xl p-6 flex flex-col items-center gap-2 text-gray-500 hover:border-blue-500 hover:text-blue-400 transition-colors">
                        <Camera size={24} />
                        <span className="text-sm">Tomar foto de evidencia</span>
                      </button>
                    )}
                  </div>

                  {/* Notas del chofer */}
                  <textarea
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Notas de entrega (opcional)..."
                    rows={2}
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500 resize-none"
                  />

                  <Button
                    onClick={() => complete.mutate()}
                    loading={complete.isPending}
                    className="w-full justify-center py-3"
                  >
                    <CheckCircle size={18} />
                    Confirmar entrega
                  </Button>
                </>
              )}

              {(delivery.status === 'ASSIGNED' || delivery.status === 'PENDING' || delivery.status === 'IN_ROUTE') && (
                <Button
                  variant="secondary"
                  onClick={() => arrived.mutate()}
                  loading={arrived.isPending}
                  className="w-full justify-center py-3"
                >
                  <MapPin size={18} />
                  Llegué al domicilio
                </Button>
              )}
            </div>
          )}

          {/* Entregado */}
          {isCompleted && (
            <div className="flex items-center gap-2 text-green-400 bg-green-400/10 px-3 py-2 rounded-xl">
              <CheckCircle size={16} />
              <div>
                <p className="text-sm font-medium">Entregado</p>
                {delivery.deliveredAt && (
                  <p className="text-xs opacity-70">
                    {new Date(delivery.deliveredAt).toLocaleTimeString('es-MX')}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default function DriverPage() {
  const qc = useQueryClient()

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['driver-deliveries'],
    queryFn: () => api.get('/deliveries/my-deliveries').then(r => r.data),
    refetchInterval: 30000,
  })

  const arrivedWarehouse = useMutation({
    mutationFn: () => api.post('/deliveries/arrived-warehouse'),
    onSuccess: () => refetch(),
  })

  if (isLoading) return (
    <div className="flex items-center justify-center min-h-screen bg-gray-950">
      <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const d = data || { totalHoy: 0, pendientes: 0, completadas: 0, entregas: [], historial: [] }

  return (
    <div className="min-h-screen bg-gray-950 text-white pb-8">
      {/* Header */}
      <div className="bg-gray-900 border-b border-gray-800 px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Truck size={20} className="text-blue-400" />
            <span className="font-bold">Mis Entregas</span>
          </div>
          <button onClick={() => refetch()} className="text-gray-500 text-xs">Actualizar</button>
        </div>

        {/* Stats */}
        <div className="flex gap-4 mt-3">
          <div className="flex-1 bg-gray-800 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-yellow-400">{d.pendientes}</p>
            <p className="text-xs text-gray-500">Pendientes</p>
          </div>
          <div className="flex-1 bg-gray-800 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-green-400">{d.completadas}</p>
            <p className="text-xs text-gray-500">Completadas</p>
          </div>
          <div className="flex-1 bg-gray-800 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold">{d.totalHoy}</p>
            <p className="text-xs text-gray-500">Total hoy</p>
          </div>
        </div>
      </div>

      <div className="px-4 pt-4 space-y-4">
        {/* Botón llegué al negocio */}
        <Button
          onClick={() => arrivedWarehouse.mutate()}
          loading={arrivedWarehouse.isPending}
          variant="secondary"
          className="w-full justify-center py-4 text-base"
        >
          <Truck size={20} />
          Llegué al negocio a cargar
        </Button>

        {/* Entregas pendientes */}
        {d.entregas.length === 0 ? (
          <div className="text-center py-16 text-gray-600">
            <CheckCircle size={40} className="mx-auto mb-3 opacity-30" />
            <p className="text-sm">No tienes entregas pendientes hoy</p>
          </div>
        ) : (
          <>
            <p className="text-xs text-gray-500 font-medium uppercase tracking-wide">
              Entregas pendientes
            </p>
            {d.entregas.map((delivery: any) => (
              <DeliveryCard key={delivery.id} delivery={delivery} onAction={refetch} />
            ))}
          </>
        )}

        {/* Historial del día */}
        {d.historial.length > 0 && (
          <>
            <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mt-6">
              Completadas hoy
            </p>
            {d.historial.map((delivery: any) => (
              <DeliveryCard key={delivery.id} delivery={delivery} onAction={refetch} />
            ))}
          </>
        )}
      </div>
    </div>
  )
}
