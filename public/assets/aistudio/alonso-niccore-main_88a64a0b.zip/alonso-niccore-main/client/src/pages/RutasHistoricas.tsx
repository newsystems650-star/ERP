import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Breadcrumb { lat: number; lon: number; spd: number; timestamp: string; }
interface ViajeResumen { tripId: string; inicio: string; fin: string; duracionMin: number; distanciaKm: number; }
interface ResumenNodo { nodeId: string; totalViajes: number; viajes: ViajeResumen[]; }
interface Viaje { tripId: string; nodeId: string; inicio: string; fin: string; duracionMin: number; distanciaKm: number; spdPromedio: number; spdMaxima: number; puntos: Breadcrumb[]; }

const API = 'http://localhost:3000/api';
const colorVel = (spd: number) => spd < 20 ? '#22c55e' : spd < 60 ? '#f59e0b' : '#ef4444';

export default function RutasHistoricas() {
    const mapRef     = useRef<HTMLDivElement>(null);
    const leafletMap = useRef<L.Map | null>(null);
    const layers     = useRef<L.LayerGroup | null>(null);
    const [nodeId, setNodeId]     = useState('');
    const [nodos,  setNodos]      = useState<string[]>([]);
    const [resumen, setResumen]   = useState<ResumenNodo | null>(null);
    const [viaje,  setViaje]      = useState<Viaje | null>(null);
    const [loading, setLoading]   = useState(false);

    useEffect(() => {
        if (!mapRef.current || leafletMap.current) return;
        leafletMap.current = L.map(mapRef.current, { center: [19.43, -99.13], zoom: 11 });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(leafletMap.current);
        layers.current = L.layerGroup().addTo(leafletMap.current);
    }, []);

    useEffect(() => {
        fetch(`${API}/rutas/nodos`).then((r) => r.json()).then((d) => setNodos(d.nodos ?? [])).catch(console.error);
    }, []);

    async function cargarViajes(nodo: string) {
        setNodeId(nodo); setResumen(null); setViaje(null); layers.current?.clearLayers(); setLoading(true);
        try { setResumen(await (await fetch(`${API}/rutas/nodo/${nodo}`)).json()); }
        catch (e) { console.error(e); } finally { setLoading(false); }
    }

    async function renderizarViaje(tripId: string) {
        layers.current?.clearLayers(); setLoading(true);
        try {
            const data: Viaje = await (await fetch(`${API}/rutas/viaje/${tripId}`)).json();
            setViaje(data);
            if (!leafletMap.current || !layers.current || data.puntos.length === 0) return;
            for (let i = 1; i < data.puntos.length; i++) {
                const a = data.puntos[i - 1], b = data.puntos[i];
                L.polyline([[a.lat, a.lon], [b.lat, b.lon]], { color: colorVel(a.spd), weight: 4, opacity: 0.85 }).addTo(layers.current);
            }
            const p0 = data.puntos[0], pN = data.puntos[data.puntos.length - 1];
            L.circleMarker([p0.lat, p0.lon], { radius: 8, color: '#16a34a', fillColor: '#22c55e', fillOpacity: 1 }).bindPopup(`<b>Inicio</b><br>${new Date(p0.timestamp).toLocaleTimeString()}`).addTo(layers.current);
            L.circleMarker([pN.lat, pN.lon], { radius: 8, color: '#b91c1c', fillColor: '#ef4444', fillOpacity: 1 }).bindPopup(`<b>Fin</b><br>${new Date(pN.timestamp).toLocaleTimeString()}`).addTo(layers.current);
            leafletMap.current.fitBounds(L.latLngBounds(data.puntos.map((p) => [p.lat, p.lon] as [number, number])), { padding: [32, 32] });
        } catch (e) { console.error(e); } finally { setLoading(false); }
    }

    const s: Record<string, React.CSSProperties> = {
        wrap:    { display: 'flex', height: '100vh', fontFamily: 'monospace' },
        panel:   { width: '300px', minWidth: '300px', background: '#0f172a', color: '#e2e8f0', display: 'flex', flexDirection: 'column', borderRight: '1px solid #1e293b' },
        header:  { padding: '16px', borderBottom: '1px solid #1e293b' },
        label:   { fontSize: '11px', color: '#64748b', marginBottom: '4px' },
        select:  { width: '100%', padding: '8px', background: '#1e293b', color: '#e2e8f0', border: '1px solid #334155', borderRadius: '4px' },
        stats:   { padding: '16px', borderBottom: '1px solid #1e293b' },
        list:    { flex: 1, overflowY: 'auto', padding: '8px' },
        map:     { flex: 1 },
    };

    return (
        <div style={s.wrap}>
            <div style={s.panel}>
                <div style={s.header}>
                    <div style={s.label}>NICCORE / RUTAS HISTÓRICAS</div>
                    <select value={nodeId} onChange={(e) => cargarViajes(e.target.value)} style={s.select}>
                        <option value="">— Seleccionar nodo —</option>
                        {nodos.map((n) => <option key={n} value={n}>{n}</option>)}
                    </select>
                </div>

                {viaje && (
                    <div style={s.stats}>
                        <div style={s.label}>VIAJE ACTIVO</div>
                        {[['Nodo', viaje.nodeId], ['Distancia', `${viaje.distanciaKm} km`], ['Duración', `${viaje.duracionMin} min`], ['Vel. prom.', `${viaje.spdPromedio} km/h`], ['Vel. máx.', `${viaje.spdMaxima} km/h`], ['Puntos', viaje.puntos.length]].map(([l, v]) => (
                            <div key={String(l)} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', fontSize: '12px' }}>
                                <span style={{ color: '#64748b' }}>{l}</span>
                                <span style={{ color: '#38bdf8' }}>{v}</span>
                            </div>
                        ))}
                        <div style={{ ...s.label, marginTop: '12px' }}>VELOCIDAD</div>
                        {[['#22c55e', '< 20 km/h'], ['#f59e0b', '20–60 km/h'], ['#ef4444', '> 60 km/h']].map(([c, l]) => (
                            <div key={String(l)} style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px', fontSize: '11px' }}>
                                <div style={{ width: '24px', height: '4px', background: String(c), borderRadius: '2px' }} />
                                <span>{l}</span>
                            </div>
                        ))}
                    </div>
                )}

                <div style={s.list}>
                    {loading && <div style={{ padding: '16px', color: '#64748b', fontSize: '12px' }}>Cargando...</div>}
                    {resumen && !loading && resumen.viajes.map((v) => (
                        <div key={v.tripId} onClick={() => renderizarViaje(v.tripId)} style={{ padding: '10px', marginBottom: '4px', background: viaje?.tripId === v.tripId ? '#1e3a5f' : '#1e293b', border: `1px solid ${viaje?.tripId === v.tripId ? '#38bdf8' : '#334155'}`, borderRadius: '4px', cursor: 'pointer' }}>
                            <div style={{ fontSize: '10px', color: '#38bdf8', marginBottom: '4px' }}>{new Date(v.inicio).toLocaleDateString('es-MX', { weekday: 'short', day: 'numeric', month: 'short' })}</div>
                            <div style={{ fontSize: '11px', color: '#94a3b8' }}>{new Date(v.inicio).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })} → {new Date(v.fin).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '4px', fontSize: '11px', color: '#64748b' }}>
                                <span>{v.distanciaKm} km</span><span>{v.duracionMin} min</span>
                            </div>
                        </div>
                    ))}
                    {resumen && !loading && resumen.viajes.length === 0 && <div style={{ padding: '16px', color: '#64748b', fontSize: '12px' }}>Sin viajes en los últimos 7 días.</div>}
                </div>
            </div>
            <div ref={mapRef} style={s.map} />
        </div>
    );
}
