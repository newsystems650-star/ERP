import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { Plus, Calculator, TrendingUp, Package, ChevronDown, ChevronUp } from 'lucide-react'
import clsx from 'clsx'

const fmt   = (n: number) => '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 2 })
const CLASS_COLORS: Record<string, string> = {
  PRIMERA:  'bg-yellow-400/10 text-yellow-400',
  SEGUNDA:  'bg-blue-400/10 text-blue-400',
  TERCERA:  'bg-gray-400/10 text-gray-400',
  ESPECIAL: 'bg-purple-400/10 text-purple-400',
}

function MarginSlider({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="text-gray-400">Margen de ganancia</span>
        <span className="font-bold text-green-400 text-lg">{value}%</span>
      </div>
      <input
        type="range" min="1" max="100" value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full accent-green-500"
      />
      <div className="flex justify-between text-xs text-gray-600">
        <span>1%</span><span>25%</span><span>50%</span><span>75%</span><span>100%</span>
      </div>
    </div>
  )
}

function WoodCalculator({ onSave }: { onSave: () => void }) {
  const [form, setForm] = useState({
    woodType: 'Pino', woodClass: 'PRIMERA',
    widthCm: 30, thicknessCm: 2.5, lengthCm: 250,
    totalPieces: 100, costPerFoot: 18, marginPercent: 30,
    notes: '', generateStrips: true,
  })
  const [preview, setPreview] = useState<any>(null)
  const [error, setError] = useState('')
  const qc = useQueryClient()

  const TOKEN = localStorage.getItem('token')

  // Preview automático cuando cambian los valores
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (form.widthCm && form.thicknessCm && form.lengthCm && form.totalPieces && form.costPerFoot) {
        try {
          const res = await api.post('/wood-entries/preview', {
            widthCm: form.widthCm, thicknessCm: form.thicknessCm,
            lengthCm: form.lengthCm, totalPieces: form.totalPieces,
            costPerFoot: form.costPerFoot, marginPercent: form.marginPercent,
          })
          setPreview(res.data)
        } catch {}
      }
    }, 500)
    return () => clearTimeout(timer)
  }, [form.widthCm, form.thicknessCm, form.lengthCm, form.totalPieces, form.costPerFoot, form.marginPercent])

  const save = useMutation({
    mutationFn: () => api.post('/wood-entries', form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['wood-entries'] }); onSave() },
    onError: (err: any) => setError(err.response?.data?.error?.message || 'Error'),
  })

  const calc = preview?.calculations

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onSave}>← Volver</Button>
        <h1 className="text-xl font-bold">Entrada de madera</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Formulario */}
        <div className="space-y-4">
          <Card>
            <h2 className="text-sm font-medium text-gray-400 mb-4">Tipo de madera</h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Tipo</label>
                <input value={form.woodType} onChange={e => setForm({...form, woodType: e.target.value})}
                  placeholder="Pino, Cedro, MDF..."
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Clase</label>
                <select value={form.woodClass} onChange={e => setForm({...form, woodClass: e.target.value})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none">
                  {['PRIMERA','SEGUNDA','TERCERA','ESPECIAL'].map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>
          </Card>

          <Card>
            <h2 className="text-sm font-medium text-gray-400 mb-4">Medidas (en cm)</h2>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Ancho (cm)', key: 'widthCm', hint: `= ${calc?.widthInch || '?'}"` },
                { label: 'Grueso (cm)', key: 'thicknessCm', hint: `= ${calc?.thicknessInch || '?'}"` },
                { label: 'Largo (cm)', key: 'lengthCm', hint: `= ${calc?.lengthFeet || '?'}'` },
              ].map(({ label, key, hint }) => (
                <div key={key}>
                  <label className="text-xs text-gray-500 mb-1 block">{label}</label>
                  <input
                    type="number" step="0.5"
                    value={form[key as keyof typeof form] as number}
                    onChange={e => setForm({...form, [key]: Number(e.target.value)})}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                  {calc && <p className="text-xs text-blue-400 mt-1">{hint}</p>}
                </div>
              ))}
            </div>

            {calc && (
              <div className="mt-3 bg-gray-800 rounded-lg p-3 text-xs text-center">
                <span className="text-gray-400">Pie tablar por pieza: </span>
                <span className="text-white font-bold text-sm">{calc.feetPerPiece} pt</span>
                <span className="text-gray-500 ml-2">
                  ({calc.thicknessInch}" × {calc.widthInch}" × {calc.lengthFeet}') ÷ 12
                </span>
              </div>
            )}
          </Card>

          <Card>
            <h2 className="text-sm font-medium text-gray-400 mb-4">Compra</h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Total de piezas</label>
                <input type="number" min="1" value={form.totalPieces}
                  onChange={e => setForm({...form, totalPieces: Number(e.target.value)})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Precio por pie tablar ($)</label>
                <input type="number" step="0.50" min="0" value={form.costPerFoot}
                  onChange={e => setForm({...form, costPerFoot: Number(e.target.value)})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
              </div>
            </div>
            {calc && (
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-800 rounded p-2">
                  <p className="text-gray-500">Total pies tablares</p>
                  <p className="font-bold text-white">{calc.totalFeet} pt</p>
                </div>
                <div className="bg-gray-800 rounded p-2">
                  <p className="text-gray-500">Costo total</p>
                  <p className="font-bold text-red-400">{fmt(calc.totalCost)}</p>
                </div>
              </div>
            )}
          </Card>

          <Card>
            <MarginSlider value={form.marginPercent} onChange={v => setForm({...form, marginPercent: v})} />
          </Card>

          <label className="flex items-center gap-3 cursor-pointer px-1">
            <input type="checkbox" checked={form.generateStrips}
              onChange={e => setForm({...form, generateStrips: e.target.checked})}
              className="w-4 h-4 accent-blue-500" />
            <span className="text-sm text-gray-300">Calcular tiras de pino (1cm a 9.5cm)</span>
          </label>

          {error && <p className="text-sm text-red-400 bg-red-400/10 px-3 py-2 rounded-lg">{error}</p>}

          <Button onClick={() => save.mutate()} loading={save.isPending} className="w-full justify-center py-3">
            <Package size={18} />Guardar entrada de madera
          </Button>
        </div>

        {/* Preview de precios */}
        {calc && (
          <div className="space-y-4">
            <Card>
              <h2 className="text-sm font-medium text-gray-400 mb-4 flex items-center gap-2">
                <TrendingUp size={14} className="text-green-400" />
                Precios al público con {form.marginPercent}% de margen
              </h2>
              <div className="space-y-3">
                {[
                  { label: 'Por pie tablar',  value: calc.pricePerFoot,  cost: form.costPerFoot },
                  { label: 'Por pieza',       value: calc.pricePerPiece, cost: calc.costPerPiece },
                  { label: 'Por metro cúbico',value: calc.pricePerM3,    cost: null },
                  { label: 'Por metro cuadrado',value: calc.pricePerM2,  cost: null },
                ].map(({ label, value, cost }) => (
                  <div key={label} className="flex items-center justify-between py-2 border-b border-gray-800">
                    <span className="text-sm text-gray-400">{label}</span>
                    <div className="text-right">
                      <p className="font-bold text-white">{fmt(value)}</p>
                      {cost !== null && (
                        <p className="text-xs text-green-400">+{fmt(value - Number(cost))} ganancia</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 bg-green-400/10 rounded-xl p-4 text-center">
                <p className="text-xs text-gray-400">Ganancia total ({form.totalPieces} piezas)</p>
                <p className="text-3xl font-bold text-green-400 mt-1">{fmt(calc.profitTotal)}</p>
              </div>
            </Card>

            {/* Tiras de pino */}
            {preview?.strips?.length > 0 && (
              <Card>
                <h2 className="text-sm font-medium text-gray-400 mb-3">
                  Tiras disponibles de esta tabla
                </h2>
                <div className="overflow-auto max-h-64">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-gray-500 border-b border-gray-800">
                        <th className="text-left py-1">Ancho</th>
                        <th className="text-center py-1">Pulgadas</th>
                        <th className="text-center py-1">Tiras/tabla</th>
                        <th className="text-right py-1">Precio</th>
                      </tr>
                    </thead>
                    <tbody>
                      {preview.strips.map((s: any) => (
                        <tr key={s.widthCm} className="border-b border-gray-800/50">
                          <td className="py-1.5 font-medium">{s.widthCm}cm</td>
                          <td className="py-1.5 text-center text-gray-400">{s.widthInch}"</td>
                          <td className="py-1.5 text-center">{s.piecesPerPlan}</td>
                          <td className="py-1.5 text-right text-blue-400 font-medium">{fmt(s.pricePerPiece)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

function WoodEntryList({ onNew }: { onNew: () => void }) {
  const { data, isLoading } = useQuery({
    queryKey: ['wood-entries'],
    queryFn: () => api.get('/wood-entries').then(r => r.data),
  })

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Entrada de Madera</h1>
          <p className="text-gray-500 text-sm mt-1">Calculadora de precios y márgenes</p>
        </div>
        <Button onClick={onNew}><Plus size={16} />Nueva entrada</Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : !data?.data?.length ? (
        <Card className="text-center py-16">
          <Package size={40} className="mx-auto mb-4 text-gray-700" />
          <p className="text-gray-500">No hay entradas registradas</p>
          <Button className="mt-4" onClick={onNew}><Plus size={16} />Primera entrada</Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {data.data.map((e: any) => (
            <Card key={e.id}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-bold">{e.woodType}</p>
                  <p className="text-xs text-gray-500 font-mono">{e.entryCode}</p>
                </div>
                <span className={clsx('text-xs px-2 py-0.5 rounded-full', CLASS_COLORS[e.woodClass])}>
                  {e.woodClass}
                </span>
              </div>

              <div className="text-xs text-gray-400 mb-3">
                {Number(e.widthInch)}" × {Number(e.thicknessInch)}" × {Number(e.lengthFeet)}'
                <span className="ml-2 text-gray-600">
                  ({Number(e.widthCm)}×{Number(e.thicknessCm)}×{Number(e.lengthCm)}cm)
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                <div className="bg-gray-800 rounded p-2">
                  <p className="text-gray-500">Por pieza</p>
                  <p className="font-bold text-white">{fmt(e.pricePerPiece)}</p>
                </div>
                <div className="bg-gray-800 rounded p-2">
                  <p className="text-gray-500">Por pie tablar</p>
                  <p className="font-bold text-blue-400">{fmt(e.pricePerFoot)}</p>
                </div>
                <div className="bg-gray-800 rounded p-2">
                  <p className="text-gray-500">Piezas</p>
                  <p className="font-bold">{e.totalPieces}</p>
                </div>
                <div className="bg-gray-800 rounded p-2">
                  <p className="text-gray-500">Ganancia total</p>
                  <p className="font-bold text-green-400">{fmt(e.profitTotal)}</p>
                </div>
              </div>

              <div className="flex justify-between text-xs text-gray-500">
                <span>Margen: {Number(e.marginPercent)}%</span>
                <span>{new Date(e.createdAt).toLocaleDateString('es-MX')}</span>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

export default function WoodEntriesPage() {
  const [view, setView] = useState<'list' | 'new'>('list')
  if (view === 'new') return (
    <div className="p-6">
      <WoodCalculator onSave={() => setView('list')} />
    </div>
  )
  return <WoodEntryList onNew={() => setView('new')} />
}
