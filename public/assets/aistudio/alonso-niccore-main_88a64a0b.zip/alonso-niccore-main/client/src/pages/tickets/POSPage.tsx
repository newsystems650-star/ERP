import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Plus, Minus, Trash2, ShoppingCart, CheckCircle, Search, Package, ClipboardList } from 'lucide-react'
import clsx from 'clsx'

const UNITS = ['PIECE','M2','M3','KG','LITER','LINEAR_M','FEET','INCH']
const fmt = (n: number) => '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 2 })

interface CartItem {
  productId: string
  name: string
  sku: string
  quantity: number
  unitPrice: number
  unit: string
}

// ─── Ticket reciente ──────────────────────────────────────────
function RecentTickets() {
  const { data } = useQuery({
    queryKey: ['tickets-recent'],
    queryFn: () => api.get('/tickets', { params: { limit: 10, type: 'SALE' } }).then(r => r.data),
    refetchInterval: 10000,
  })

  const qc = useQueryClient()
  const confirm = useMutation({
    mutationFn: (id: string) => api.patch(`/tickets/${id}/confirm`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tickets-recent'] }),
  })
  const cancel = useMutation({
    mutationFn: (id: string) => api.patch(`/tickets/${id}/cancel`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tickets-recent'] }),
  })

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-800 flex items-center gap-2">
        <ClipboardList size={14} className="text-gray-500" />
        <span className="text-sm font-medium text-gray-400">Tickets recientes</span>
      </div>
      <div className="divide-y divide-gray-800 max-h-80 overflow-y-auto">
        {(data?.data || []).map((t: any) => (
          <div key={t.id} className="px-4 py-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-xs font-mono text-blue-400">{t.code}</p>
                <p className="text-sm font-medium">{fmt(t.total)}</p>
                <p className="text-xs text-gray-500">{t.items?.length} productos</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className={clsx('text-xs px-2 py-0.5 rounded-full', {
                  'bg-yellow-400/10 text-yellow-400': t.status === 'PENDING',
                  'bg-green-400/10 text-green-400': t.status === 'CONFIRMED',
                  'bg-red-400/10 text-red-400': t.status === 'CANCELLED',
                })}>{t.status}</span>
                {t.status === 'PENDING' && (
                  <div className="flex gap-1 mt-1">
                    <button onClick={() => confirm.mutate(t.id)}
                      className="text-xs bg-green-600 hover:bg-green-500 text-white px-2 py-1 rounded transition-colors">
                      ✓
                    </button>
                    <button onClick={() => cancel.mutate(t.id)}
                      className="text-xs bg-red-700 hover:bg-red-600 text-white px-2 py-1 rounded transition-colors">
                      ✕
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── POS Principal ────────────────────────────────────────────
export default function POSPage() {
  const [cart, setCart] = useState<CartItem[]>([])
  const [search, setSearch] = useState('')
  const [notes, setNotes] = useState('')
  const [success, setSuccess] = useState<string | null>(null)
  const [error, setError] = useState('')
  const qc = useQueryClient()

  const { data: products } = useQuery({
    queryKey: ['products-pos', search],
    queryFn: () => api.get('/products', { params: { search: search || undefined, limit: 50 } }).then(r => r.data.data),
    staleTime: 10000,
  })

  const createTicket = useMutation({
    mutationFn: (data: any) => api.post('/tickets', data),
    onSuccess: (res) => {
      setSuccess(res.data.ticket.code)
      setCart([])
      setNotes('')
      setError('')
      qc.invalidateQueries({ queryKey: ['tickets-recent'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
      setTimeout(() => setSuccess(null), 4000)
    },
    onError: (err: any) => setError(err.response?.data?.error?.message || 'Error al crear ticket'),
  })

  const addToCart = (product: any) => {
    setCart(prev => {
      const existing = prev.find(i => i.productId === product.id)
      if (existing) {
        return prev.map(i => i.productId === product.id
          ? { ...i, quantity: i.quantity + 1 }
          : i
        )
      }
      return [...prev, {
        productId: product.id,
        name: product.name,
        sku: product.sku,
        quantity: 1,
        unitPrice: Number(product.price),
        unit: product.unit,
      }]
    })
  }

  const updateQty = (productId: string, delta: number) => {
    setCart(prev => prev.map(i => i.productId === productId
      ? { ...i, quantity: Math.max(0.01, i.quantity + delta) }
      : i
    ).filter(i => i.quantity > 0))
  }

  const updatePrice = (productId: string, price: number) => {
    setCart(prev => prev.map(i => i.productId === productId ? { ...i, unitPrice: price } : i))
  }

  const updateUnit = (productId: string, unit: string) => {
    setCart(prev => prev.map(i => i.productId === productId ? { ...i, unit } : i))
  }

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(i => i.productId !== productId))
  }

  const total = cart.reduce((s, i) => s + i.quantity * i.unitPrice, 0)

  const handleSubmit = () => {
    if (cart.length === 0) return
    setError('')
    createTicket.mutate({
      type: 'SALE',
      notes: notes || undefined,
      items: cart.map(i => ({
        productId: i.productId,
        quantity: i.quantity,
        unitPrice: i.unitPrice,
        unit: i.unit,
      })),
    })
  }

  return (
    <div className="h-full flex overflow-hidden">
      {/* Panel izquierdo — Productos */}
      <div className="flex-1 flex flex-col border-r border-gray-800 overflow-hidden">
        {/* Búsqueda */}
        <div className="p-4 border-b border-gray-800">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              placeholder="Buscar producto por nombre o SKU..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Grid de productos */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-2 xl:grid-cols-3 gap-3">
            {(products || []).map((p: any) => {
              const inCart = cart.find(i => i.productId === p.id)
              const stock = Number(p.stock?.quantity || 0)
              const lowStock = stock < 5

              return (
                <button
                  key={p.id}
                  onClick={() => addToCart(p)}
                  className={clsx(
                    'text-left p-4 rounded-xl border transition-all',
                    inCart
                      ? 'bg-blue-600/20 border-blue-500'
                      : 'bg-gray-900 border-gray-800 hover:border-gray-600 hover:bg-gray-800/50'
                  )}
                >
                  <div className="flex items-start justify-between mb-2">
                    <Package size={16} className={inCart ? 'text-blue-400' : 'text-gray-600'} />
                    {inCart && (
                      <span className="text-xs bg-blue-500 text-white px-1.5 py-0.5 rounded-full font-medium">
                        ×{inCart.quantity}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-medium leading-tight mb-1">{p.name}</p>
                  <p className="text-xs text-gray-500 mb-2">{p.sku} · {p.unit}</p>
                  <p className="text-sm font-bold text-blue-400">{fmt(p.price)}</p>
                  <p className={clsx('text-xs mt-1', lowStock ? 'text-red-400' : 'text-gray-600')}>
                    Stock: {stock}
                  </p>
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Panel derecho — Carrito */}
      <div className="w-96 flex flex-col bg-gray-950">
        {/* Header carrito */}
        <div className="px-4 py-3 border-b border-gray-800 flex items-center gap-2">
          <ShoppingCart size={16} className="text-gray-400" />
          <span className="font-medium text-sm">Ticket de venta</span>
          {cart.length > 0 && (
            <span className="ml-auto text-xs bg-blue-600 text-white px-2 py-0.5 rounded-full">
              {cart.length} items
            </span>
          )}
        </div>

        {/* Items del carrito */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="text-center py-12 text-gray-600">
              <ShoppingCart size={32} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">Selecciona productos del catálogo</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.productId} className="bg-gray-900 border border-gray-800 rounded-xl p-3">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{item.name}</p>
                    <p className="text-xs text-gray-500">{item.sku}</p>
                  </div>
                  <button onClick={() => removeFromCart(item.productId)}
                    className="text-gray-600 hover:text-red-400 transition-colors ml-2 shrink-0">
                    <Trash2 size={14} />
                  </button>
                </div>

                <div className="flex items-center gap-2 mb-2">
                  {/* Cantidad */}
                  <div className="flex items-center gap-1 bg-gray-800 rounded-lg">
                    <button onClick={() => updateQty(item.productId, -1)}
                      className="p-1.5 text-gray-400 hover:text-white transition-colors">
                      <Minus size={12} />
                    </button>
                    <span className="text-sm font-medium px-1 min-w-8 text-center">{item.quantity}</span>
                    <button onClick={() => updateQty(item.productId, 1)}
                      className="p-1.5 text-gray-400 hover:text-white transition-colors">
                      <Plus size={12} />
                    </button>
                  </div>

                  {/* Unidad */}
                  <select value={item.unit} onChange={e => updateUnit(item.productId, e.target.value)}
                    className="bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-xs text-white outline-none">
                    {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                  </select>

                  {/* Precio editable */}
                  <input type="number" value={item.unitPrice} min="0" step="0.01"
                    onChange={e => updatePrice(item.productId, Number(e.target.value))}
                    className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-xs text-white outline-none focus:border-blue-500 w-0"
                  />
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">{item.quantity} × {fmt(item.unitPrice)}</span>
                  <span className="font-medium text-white">{fmt(item.quantity * item.unitPrice)}</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer con total y acciones */}
        <div className="border-t border-gray-800 p-4 space-y-3">
          {/* Notas */}
          <input placeholder="Notas del ticket (opcional)"
            value={notes} onChange={e => setNotes(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500"
          />

          {/* Total */}
          <div className="flex justify-between items-center py-2">
            <span className="text-gray-400 text-sm">Total</span>
            <span className="text-2xl font-bold text-blue-400">{fmt(total)}</span>
          </div>

          {error && <p className="text-xs text-red-400 bg-red-400/10 px-3 py-2 rounded-lg">{error}</p>}

          {success && (
            <div className="flex items-center gap-2 text-green-400 bg-green-400/10 px-3 py-2 rounded-lg">
              <CheckCircle size={16} />
              <span className="text-sm font-medium">Ticket {success} creado</span>
            </div>
          )}

          <Button
            onClick={handleSubmit}
            loading={createTicket.isPending}
            disabled={cart.length === 0}
            className="w-full justify-center py-3 text-base"
          >
            <ShoppingCart size={18} />
            Crear ticket
          </Button>

          {cart.length > 0 && (
            <button onClick={() => setCart([])}
              className="w-full text-xs text-gray-600 hover:text-red-400 transition-colors py-1">
              Limpiar carrito
            </button>
          )}
        </div>
      </div>

      {/* Panel tickets recientes — columna extra en pantallas grandes */}
      <div className="hidden xl:flex xl:flex-col w-72 border-l border-gray-800 p-4 space-y-4 overflow-y-auto">
        <RecentTickets />
      </div>
    </div>
  )
}
