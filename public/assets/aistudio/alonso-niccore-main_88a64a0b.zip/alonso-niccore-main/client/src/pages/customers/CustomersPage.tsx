import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Plus, Users, Search, Phone, MapPin, X, CreditCard, ChevronRight } from 'lucide-react'
import clsx from 'clsx'

const fmt = (n: number) => '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 2 })

function CustomerForm({ customer, onClose }: { customer?: any; onClose: () => void }) {
  const qc = useQueryClient()
  const [form, setForm] = useState({
    name: customer?.name || '',
    phone: customer?.phone || '',
    email: customer?.email || '',
    address: customer?.address || '',
    rfc: customer?.rfc || '',
    notes: customer?.notes || '',
  })
  const [error, setError] = useState('')

  const save = useMutation({
    mutationFn: (data: any) => customer
      ? api.put(`/customers/${customer.id}`, data)
      : api.post('/customers', data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['customers'] }); onClose() },
    onError: (err: any) => setError(err.response?.data?.error?.message || 'Error'),
  })

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-lg">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <h2 className="font-bold">{customer ? 'Editar cliente' : 'Nuevo cliente'}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><X size={18} /></button>
        </div>
        <form onSubmit={e => { e.preventDefault(); save.mutate(form) }} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="text-xs text-gray-500 mb-1 block">Nombre *</label>
              <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} required
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Teléfono</label>
              <input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">RFC</label>
              <input value={form.rfc} onChange={e => setForm({...form, rfc: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            <div className="col-span-2">
              <label className="text-xs text-gray-500 mb-1 block">Dirección</label>
              <input value={form.address} onChange={e => setForm({...form, address: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            <div className="col-span-2">
              <label className="text-xs text-gray-500 mb-1 block">Email</label>
              <input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500" />
            </div>
            <div className="col-span-2">
              <label className="text-xs text-gray-500 mb-1 block">Notas</label>
              <textarea value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} rows={2}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500 resize-none" />
            </div>
          </div>
          {error && <p className="text-xs text-red-400 bg-red-400/10 px-3 py-2 rounded-lg">{error}</p>}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="secondary" onClick={onClose}>Cancelar</Button>
            <Button type="submit" loading={save.isPending}>Guardar</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function CustomerDetail({ customer, onBack }: { customer: any; onBack: () => void }) {
  const { data } = useQuery({
    queryKey: ['customer', customer.id],
    queryFn: () => api.get(`/customers/${customer.id}`).then(r => r.data.customer),
  })

  const c = data || customer
  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>← Volver</Button>
        <h1 className="text-xl font-bold">{c.name}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 space-y-3">
          <h2 className="text-sm font-medium text-gray-400">Datos del cliente</h2>
          {c.phone && <p className="text-sm flex items-center gap-2"><Phone size={14} className="text-gray-500" />{c.phone}</p>}
          {c.address && <p className="text-sm flex items-center gap-2"><MapPin size={14} className="text-gray-500" />{c.address}</p>}
          {c.rfc && <p className="text-sm text-gray-400">RFC: <span className="text-white font-mono">{c.rfc}</span></p>}
          {c.notes && <p className="text-sm text-gray-500">{c.notes}</p>}
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
          <h2 className="text-sm font-medium text-gray-400 mb-3">Créditos activos</h2>
          {c.credits?.length === 0 ? (
            <p className="text-sm text-gray-600">Sin créditos activos</p>
          ) : (
            c.credits?.map((cr: any) => (
              <div key={cr.id} className="flex justify-between items-center py-2 border-b border-gray-800">
                <span className="text-sm text-gray-400">Saldo</span>
                <span className="text-red-400 font-bold">{fmt(cr.balance)}</span>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-gray-800">
          <h2 className="text-sm font-medium text-gray-400">Últimos tickets</h2>
        </div>
        <table className="w-full text-sm">
          <tbody>
            {(c.tickets || []).map((t: any) => (
              <tr key={t.id} className="border-b border-gray-800/50">
                <td className="px-5 py-3 font-mono text-blue-400">{t.code}</td>
                <td className="px-5 py-3 font-medium">{fmt(t.total)}</td>
                <td className="px-5 py-3">
                  <span className={clsx('text-xs px-2 py-0.5 rounded-full', {
                    'bg-green-400/10 text-green-400': t.status === 'CONFIRMED',
                    'bg-yellow-400/10 text-yellow-400': t.status === 'PENDING',
                    'bg-red-400/10 text-red-400': t.status === 'CANCELLED',
                  })}>{t.status}</span>
                </td>
                <td className="px-5 py-3 text-gray-500 text-xs">{new Date(t.createdAt).toLocaleDateString('es-MX')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default function CustomersPage() {
  const [search, setSearch] = useState('')
  const [modal, setModal] = useState(false)
  const [selected, setSelected] = useState<any>(null)
  const [detail, setDetail] = useState<any>(null)

  const { data, isLoading } = useQuery({
    queryKey: ['customers', search],
    queryFn: () => api.get('/customers', { params: { search: search || undefined, limit: 100 } }).then(r => r.data),
  })

  if (detail) return <CustomerDetail customer={detail} onBack={() => setDetail(null)} />

  return (
    <div className="p-6 space-y-6">
      {modal && <CustomerForm customer={selected} onClose={() => { setModal(false); setSelected(null) }} />}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Clientes</h1>
          <p className="text-gray-500 text-sm mt-1">{data?.meta?.total || 0} clientes</p>
        </div>
        <Button onClick={() => setModal(true)}><Plus size={16} />Nuevo cliente</Button>
      </div>

      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
        <input placeholder="Buscar cliente..." value={search} onChange={e => setSearch(e.target.value)}
          className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500" />
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-16">
            <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                <th className="text-left px-6 py-3">Cliente</th>
                <th className="text-left px-6 py-3">Teléfono</th>
                <th className="text-left px-6 py-3">RFC</th>
                <th className="text-left px-6 py-3">Dirección</th>
                <th className="px-6 py-3" />
              </tr>
            </thead>
            <tbody>
              {(data?.data || []).map((c: any) => (
                <tr key={c.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 cursor-pointer"
                  onClick={() => setDetail(c)}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 text-xs font-bold">
                        {c.name[0].toUpperCase()}
                      </div>
                      <span className="font-medium">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{c.phone || '—'}</td>
                  <td className="px-6 py-4 font-mono text-gray-400 text-xs">{c.rfc || '—'}</td>
                  <td className="px-6 py-4 text-gray-400 text-xs truncate max-w-xs">{c.address || '—'}</td>
                  <td className="px-6 py-4">
                    <ChevronRight size={16} className="text-gray-600" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
