import { useState, useRef, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { Plus, Trash2, Scissors, ChevronRight, BarChart2, Layers } from 'lucide-react'
import clsx from 'clsx'

const fmt = (n: number) => Number(n).toFixed(3)
const COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#f97316','#84cc16','#ec4899','#14b8a6']

// ─── Canvas de visualización de cortes ───────────────────────
function CutCanvas({ sheets, stockW, stockH }: { sheets: any[]; stockW: number; stockH: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [currentSheet, setCurrentSheet] = useState(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !sheets.length) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const sheet = sheets[currentSheet]
    const padding = 20
    const maxW = canvas.width - padding * 2
    const maxH = canvas.height - padding * 2
    const scale = Math.min(maxW / stockW, maxH / stockH)

    const drawW = stockW * scale
    const drawH = stockH * scale
    const offsetX = padding + (maxW - drawW) / 2
    const offsetY = padding + (maxH - drawH) / 2

    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Fondo tablero (madera)
    const gradient = ctx.createLinearGradient(offsetX, offsetY, offsetX + drawW, offsetY + drawH)
    gradient.addColorStop(0, '#92400e')
    gradient.addColorStop(0.5, '#b45309')
    gradient.addColorStop(1, '#92400e')
    ctx.fillStyle = gradient
    ctx.fillRect(offsetX, offsetY, drawW, drawH)

    // Vetas de madera
    ctx.strokeStyle = 'rgba(0,0,0,0.1)'
    ctx.lineWidth = 1
    for (let y = 0; y < drawH; y += 12) {
      ctx.beginPath()
      ctx.moveTo(offsetX, offsetY + y)
      ctx.lineTo(offsetX + drawW, offsetY + y + Math.sin(y * 0.1) * 3)
      ctx.stroke()
    }

    // Borde tablero
    ctx.strokeStyle = '#78350f'
    ctx.lineWidth = 2
    ctx.strokeRect(offsetX, offsetY, drawW, drawH)

    // Piezas
    const labelCount: Record<string, number> = {}
    sheet.pieces?.forEach((piece: any, idx: number) => {
      const color = COLORS[idx % COLORS.length]
      const px = offsetX + piece.x * scale
      const py = offsetY + piece.y * scale
      const pw = piece.width * scale
      const ph = piece.height * scale

      // Sombra
      ctx.shadowColor = 'rgba(0,0,0,0.4)'
      ctx.shadowBlur = 6
      ctx.shadowOffsetX = 2
      ctx.shadowOffsetY = 2

      // Fondo pieza
      ctx.fillStyle = color + 'dd'
      ctx.fillRect(px + 2, py + 2, pw - 4, ph - 4)

      // Sin sombra para texto y borde
      ctx.shadowColor = 'transparent'
      ctx.shadowBlur = 0
      ctx.shadowOffsetX = 0
      ctx.shadowOffsetY = 0

      // Borde pieza
      ctx.strokeStyle = color
      ctx.lineWidth = 1.5
      ctx.strokeRect(px + 2, py + 2, pw - 4, ph - 4)

      // Etiqueta
      if (pw > 30 && ph > 20) {
        ctx.fillStyle = 'white'
        ctx.font = `bold ${Math.min(12, pw / 4)}px monospace`
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'

        const label = piece.rotated ? `↻${piece.label}` : piece.label
        ctx.fillText(label, px + pw / 2, py + ph / 2 - 6)

        ctx.font = `${Math.min(9, pw / 5)}px monospace`
        ctx.fillStyle = 'rgba(255,255,255,0.8)'
        ctx.fillText(`${piece.width}×${piece.height}`, px + pw / 2, py + ph / 2 + 8)
      }
    })

    // Dimensiones
    ctx.fillStyle = '#9ca3af'
    ctx.font = '11px monospace'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'top'
    ctx.fillText(`${stockW}m`, offsetX + drawW / 2, offsetY + drawH + 6)
    ctx.textAlign = 'right'
    ctx.textBaseline = 'middle'
    ctx.fillText(`${stockH}m`, offsetX - 6, offsetY + drawH / 2)

  }, [sheets, currentSheet, stockW, stockH])

  return (
    <div className="space-y-3">
      <div className="bg-gray-950 rounded-xl p-2 flex justify-center">
        <canvas ref={canvasRef} width={600} height={400} className="max-w-full" />
      </div>
      {sheets.length > 1 && (
        <div className="flex items-center justify-center gap-2">
          {sheets.map((_: any, i: number) => (
            <button key={i} onClick={() => setCurrentSheet(i)}
              className={clsx('w-8 h-8 rounded-lg text-xs font-medium transition-colors', {
                'bg-blue-600 text-white': i === currentSheet,
                'bg-gray-800 text-gray-400 hover:bg-gray-700': i !== currentSheet,
              })}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Resultado de cálculo ─────────────────────────────────────
function CutResult({ result, stockW, stockH, onClose }: {
  result: any; stockW: number; stockH: number; onClose: () => void
}) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <Scissors size={18} className="text-blue-400" />
          Resultado del cálculo
        </h2>
        <Button variant="ghost" size="sm" onClick={onClose}>← Volver</Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="text-center">
          <p className="text-3xl font-bold text-blue-400">{result.hojas}</p>
          <p className="text-xs text-gray-500 mt-1">Tableros necesarios</p>
        </Card>
        <Card className="text-center">
          <p className="text-3xl font-bold text-green-400">{result.eficiencia}</p>
          <p className="text-xs text-gray-500 mt-1">Eficiencia</p>
        </Card>
        <Card className="text-center">
          <p className="text-3xl font-bold text-yellow-400">{result.desperdicio}</p>
          <p className="text-xs text-gray-500 mt-1">Desperdicio</p>
        </Card>
      </div>

      {/* Canvas */}
      <Card>
        <h3 className="text-sm font-medium text-gray-400 mb-4 flex items-center gap-2">
          <Layers size={14} />
          Distribución de cortes
        </h3>
        <CutCanvas sheets={result.layout || []} stockW={stockW} stockH={stockH} />
      </Card>

      {/* Resumen por hoja */}
      <Card>
        <h3 className="text-sm font-medium text-gray-400 mb-4">Detalle por tablero</h3>
        <div className="space-y-4">
          {result.resumen?.map((s: any) => (
            <div key={s.hoja} className="bg-gray-800 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium">Tablero {s.hoja}</span>
                <div className="flex gap-4 text-xs text-gray-500">
                  <span>{s.piezas} piezas</span>
                  <span>{s.areaUsada} m² usados</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {s.piezasDetalle?.map((p: any, i: number) => (
                  <div key={i} className="flex items-center gap-1.5 bg-gray-700 rounded-lg px-2 py-1">
                    <div className="w-2 h-2 rounded-sm" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="text-xs font-medium">{p.etiqueta}</span>
                    <span className="text-xs text-gray-500">{p.ancho}×{p.alto}</span>
                    {p.rotada && <span className="text-xs text-yellow-400">↻</span>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}

// ─── Formulario nueva hoja de corte ──────────────────────────
function NewCutSheet({ onBack }: { onBack: () => void }) {
  const qc = useQueryClient()
  const [name, setName] = useState('')
  const [stockW, setStockW] = useState(1.22)
  const [stockH, setStockH] = useState(2.44)
  const [kerf, setKerf] = useState(0.003)
  const [pieces, setPieces] = useState([{ label: '', width: 0.5, height: 0.5, quantity: 1, grain: false }])
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  const create = useMutation({
    mutationFn: (data: any) => api.post('/cuts', data),
  })

  const calculate = useMutation({
    mutationFn: (id: string) => api.post(`/cuts/${id}/calcular`),
    onSuccess: (res) => setResult(res.data),
    onError: (err: any) => setError(err.response?.data?.error?.message || 'Error al calcular'),
  })

  const addPiece = () => setPieces([...pieces, { label: '', width: 0.5, height: 0.5, quantity: 1, grain: false }])
  const removePiece = (i: number) => setPieces(pieces.filter((_, idx) => idx !== i))
  const updatePiece = (i: number, field: string, value: any) => {
    const updated = [...pieces]
    updated[i] = { ...updated[i], [field]: value }
    setPieces(updated)
  }

  const handleCalculate = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      const sheet = await create.mutateAsync({ name, stockWidth: stockW, stockHeight: stockH, kerf, pieces })
      await calculate.mutateAsync(sheet.data.cutSheet.id)
      qc.invalidateQueries({ queryKey: ['cuts'] })
    } catch (err: any) {
      setError(err.response?.data?.error?.message || 'Error')
    }
  }

  if (result) {
    return (
      <div className="p-6">
        <CutResult result={result} stockW={stockW} stockH={stockH} onClose={() => setResult(null)} />
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>← Volver</Button>
        <h1 className="text-xl font-bold">Nueva hoja de corte</h1>
      </div>

      <form onSubmit={handleCalculate} className="space-y-6">
        {/* Tablero */}
        <Card>
          <h2 className="text-sm font-medium text-gray-400 mb-4">Medidas del tablero</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="col-span-2">
              <label className="text-xs text-gray-500 mb-1 block">Nombre del proyecto</label>
              <input value={name} onChange={e => setName(e.target.value)} required placeholder="Ej: Gabinetes cocina Don José"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Ancho (m)</label>
              <input type="number" step="0.01" value={stockW} onChange={e => setStockW(Number(e.target.value))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Alto (m)</label>
              <input type="number" step="0.01" value={stockH} onChange={e => setStockH(Number(e.target.value))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Ancho de sierra - kerf (m)</label>
              <input type="number" step="0.001" value={kerf} onChange={e => setKerf(Number(e.target.value))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
              />
            </div>
            <div className="bg-gray-800 rounded-lg p-3 flex items-center gap-3">
              <div className="text-xs text-gray-500">
                <p>Tablero: <span className="text-white">{stockW} × {stockH} m</span></p>
                <p>Área: <span className="text-blue-400 font-medium">{(stockW * stockH).toFixed(4)} m²</span></p>
              </div>
            </div>
          </div>
        </Card>

        {/* Piezas */}
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-medium text-gray-400">Piezas a cortar</h2>
            <Button type="button" variant="secondary" size="sm" onClick={addPiece}>
              <Plus size={14} />Agregar pieza
            </Button>
          </div>

          <div className="space-y-3">
            {/* Header */}
            <div className="grid grid-cols-12 gap-2 text-xs text-gray-500 px-1">
              <div className="col-span-3">Etiqueta</div>
              <div className="col-span-2">Ancho (m)</div>
              <div className="col-span-2">Alto (m)</div>
              <div className="col-span-2">Cantidad</div>
              <div className="col-span-2">Veta</div>
              <div className="col-span-1" />
            </div>

            {pieces.map((piece, i) => (
              <div key={i} className="grid grid-cols-12 gap-2 items-center">
                <div className="col-span-3">
                  <input value={piece.label} onChange={e => updatePiece(i, 'label', e.target.value)}
                    required placeholder={`Pieza ${i + 1}`}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <input type="number" step="0.01" min="0.01" value={piece.width}
                    onChange={e => updatePiece(i, 'width', Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <input type="number" step="0.01" min="0.01" value={piece.height}
                    onChange={e => updatePiece(i, 'height', Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <input type="number" min="1" step="1" value={piece.quantity}
                    onChange={e => updatePiece(i, 'quantity', Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div className="col-span-2 flex items-center justify-center">
                  <input type="checkbox" checked={piece.grain}
                    onChange={e => updatePiece(i, 'grain', e.target.checked)}
                    className="w-4 h-4 accent-blue-500"
                  />
                </div>
                <div className="col-span-1 flex justify-end">
                  {pieces.length > 1 && (
                    <button type="button" onClick={() => removePiece(i)}
                      className="text-gray-600 hover:text-red-400 transition-colors p-1">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Preview área total */}
          <div className="mt-4 pt-4 border-t border-gray-800 flex items-center justify-between text-sm">
            <span className="text-gray-500">Área total de piezas:</span>
            <span className="font-medium text-blue-400">
              {pieces.reduce((s, p) => s + p.width * p.height * p.quantity, 0).toFixed(4)} m²
            </span>
          </div>
        </Card>

        {error && <p className="text-sm text-red-400 bg-red-400/10 px-4 py-3 rounded-lg">{error}</p>}

        <div className="flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onBack}>Cancelar</Button>
          <Button type="submit" loading={create.isPending || calculate.isPending}>
            <Scissors size={16} />Calcular cortes
          </Button>
        </div>
      </form>
    </div>
  )
}

// ─── Lista de hojas guardadas ─────────────────────────────────
function CutList({ onNew, onView }: { onNew: () => void; onView: (c: any) => void }) {
  const { data, isLoading } = useQuery({
    queryKey: ['cuts'],
    queryFn: () => api.get('/cuts').then(r => r.data.data),
  })

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Scissors size={22} className="text-blue-400" />
            Optimizador de cortes
          </h1>
          <p className="text-gray-500 text-sm mt-1">Minimiza desperdicio de madera</p>
        </div>
        <Button onClick={onNew}><Plus size={16} />Nuevo cálculo</Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : !data?.length ? (
        <Card className="text-center py-16">
          <Scissors size={40} className="mx-auto mb-4 text-gray-700" />
          <p className="text-gray-500">No hay cálculos guardados</p>
          <Button className="mt-4" onClick={onNew}><Plus size={16} />Nuevo cálculo</Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {data.map((c: any) => {
            const lastResult = c.results?.[0]
            return (
              <button key={c.id} onClick={() => onView(c)}
                className="text-left bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-blue-500/50 transition-all group">
                <div className="flex items-start justify-between mb-3">
                  <div className="p-2 bg-blue-600/10 rounded-lg">
                    <Scissors size={18} className="text-blue-400" />
                  </div>
                  <ChevronRight size={16} className="text-gray-600 group-hover:text-blue-400 transition-colors" />
                </div>
                <h3 className="font-medium mb-1">{c.name}</h3>
                <p className="text-xs text-gray-500 mb-3">
                  {Number(c.stockWidth)}×{Number(c.stockHeight)}m · {c.pieces?.length} tipos de piezas
                </p>
                {lastResult ? (
                  <div className="flex gap-4 text-xs">
                    <div>
                      <p className="text-gray-500">Tableros</p>
                      <p className="font-bold text-white">{lastResult.sheets}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Eficiencia</p>
                      <p className="font-bold text-green-400">{(Number(lastResult.efficiency) * 100).toFixed(1)}%</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Desperdicio</p>
                      <p className="font-bold text-yellow-400">{Number(lastResult.waste).toFixed(3)}m²</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-gray-600">Sin calcular</p>
                )}
                <p className="text-xs text-gray-600 mt-3">{new Date(c.createdAt).toLocaleDateString('es-MX')}</p>
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ─── Controlador principal ────────────────────────────────────
export default function CutsPage() {
  const [view, setView] = useState<'list' | 'new'>('list')
  const [selected, setSelected] = useState<any>(null)

  if (view === 'new') return <NewCutSheet onBack={() => setView('list')} />
  return <CutList onNew={() => setView('new')} onView={setSelected} />
}
