import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Input, Select } from '../../components/ui/Input'
import { Card } from '../../components/ui/Card'
import {
  Plus, FileText, CheckCircle, XCircle, ArrowRight,
  ChevronDown, ChevronUp, Trash2, Search
} from 'lucide-react'
import clsx from 'clsx'

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  DRAFT:     { label: 'Borrador',   color: 'bg-gray-500/20 text-gray-400' },
  SENT:      { label: 'Enviada',    color: 'bg-blue-500/20 text-blue-400' },
  APPROVED:  { label: 'Aprobada',   color: 'bg-green-500/20 text-green-400' },
  REJECTED:  { label: 'Rechazada',  color: 'bg-red-500/20 text-red-400' },
  EXPIRED:   { label: 'Expirada',   color: 'bg-orange-500/20 text-orange-400' },
  CONVERTED: { label: 'Convertida', color: 'bg-purple-500/20 text-purple-400' },
}

const UNITS = ['M2','M3','KG','LITER','LINEAR_M','FEET','INCH','PIECE']
const fmt = (n: number) => '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 2 })

// ─── Lista de cotizaciones ────────────────────────────────────
function QuotationList({ onNew, onSelect }: { onNew: () => void; onSelect: (q: any) => void }) {
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['quotations', status],
    queryFn: () => api.get('/quotations', { params: { status: status || undefined, limit: 50 } }).then(r => r.data),
  })

  const quotations = (data?.data || []).filter((q: any) =>
    !search || q.code.toLowerCase().includes(search.toLowerCase()) ||
    q.user?.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Cotizaciones</h1>
          <p className="text-gray-500 text-sm mt-1">{data?.meta?.total || 0} cotizaciones</p>
        </div>
        <Button onClick={onNew}><Plus size={16} />Nueva cotización</Button>
      </div>

      {/* Filtros */}
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            placeholder="Buscar por código..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500"
          />
        </div>
        <select
          value={status}
          onChange={e => setStatus(e.target.value)}
          className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
        >
          <option value="">Todos los estados</option>
          {Object.entries(STATUS_LABELS).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
      </div>

      {/* Tabla */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : quotations.length === 0 ? (
          <div className="text-center py-16 text-gray-500">
            <FileText size={32} className="mx-auto mb-3 opacity-30" />
            <p>No hay cotizaciones</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                <th className="text-left px-6 py-3">Código</th>
                <th className="text-left px-6 py-3">Creador</th>
                <th className="text-right px-6 py-3">Total</th>
                <th className="text-center px-6 py-3">Estado</th>
                <th className="text-left px-6 py-3">Fecha</th>
                <th className="px-6 py-3" />
              </tr>
            </thead>
            <tbody>
              {quotations.map((q: any) => {
                const s = STATUS_LABELS[q.status]
                return (
                  <tr key={q.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                    <td className="px-6 py-4 font-mono font-medium text-blue-400">{q.code}</td>
                    <td className="px-6 py-4 text-gray-300">{q.user?.name}</td>
                    <td className="px-6 py-4 text-right font-medium">{fmt(q.total)}</td>
                    <td className="px-6 py-4 text-center">
                      <span className={clsx('text-xs px-2.5 py-1 rounded-full font-medium', s.color)}>{s.label}</span>
                    </td>
                    <td className="px-6 py-4 text-gray-500">
                      {new Date(q.createdAt).toLocaleDateString('es-MX')}
                    </td>
                    <td className="px-6 py-4">
                      <Button variant="ghost" size="sm" onClick={() => onSelect(q)}>
                        <ArrowRight size={14} />
                      </Button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

// ─── Detalle de cotización ────────────────────────────────────
function QuotationDetail({ quotation, onBack }: { quotation: any; onBack: () => void }) {
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['quotation', quotation.id],
    queryFn: () => api.get(`/quotations/${quotation.id}`).then(r => r.data.quotation),
  })

  const updateStatus = useMutation({
    mutationFn: (status: string) => api.patch(`/quotations/${quotation.id}/status`, { status }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['quotation', quotation.id] }); qc.invalidateQueries({ queryKey: ['quotations'] }) },
  })

  const convert = useMutation({
    mutationFn: () => api.post(`/quotations/${quotation.id}/convert`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['quotation', quotation.id] }); qc.invalidateQueries({ queryKey: ['quotations'] }) },
  })

  const q = data
  if (isLoading || !q) return (
    <div className="flex items-center justify-center h-full">
      <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const s = STATUS_LABELS[q.status]

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>← Volver</Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold font-mono">{q.code}</h1>
            <span className={clsx('text-xs px-2.5 py-1 rounded-full font-medium', s.color)}>{s.label}</span>
          </div>
          <p className="text-gray-500 text-sm mt-1">
            Creada por {q.user?.name} · {new Date(q.createdAt).toLocaleString('es-MX')}
          </p>
        </div>

        {/* Acciones según estado */}
        <div className="flex gap-2">
          {q.status === 'DRAFT' && (
            <Button variant="secondary" size="sm" loading={updateStatus.isPending}
              onClick={() => updateStatus.mutate('SENT')}>
              Marcar enviada
            </Button>
          )}
          {q.status === 'SENT' && <>
            <Button variant="danger" size="sm" loading={updateStatus.isPending}
              onClick={() => updateStatus.mutate('REJECTED')}>
              <XCircle size={14} />Rechazar
            </Button>
            <Button size="sm" loading={updateStatus.isPending}
              onClick={() => updateStatus.mutate('APPROVED')}>
              <CheckCircle size={14} />Aprobar
            </Button>
          </>}
          {q.status === 'APPROVED' && !q.ticket && (
            <Button size="sm" loading={convert.isPending}
              onClick={() => convert.mutate()}>
              <ArrowRight size={14} />Convertir a venta
            </Button>
          )}
          {q.ticket && (
            <div className="text-sm text-purple-400 bg-purple-400/10 px-3 py-2 rounded-lg">
              Ticket: <span className="font-mono font-bold">{q.ticket.code}</span>
            </div>
          )}
        </div>
      </div>

      {/* Items */}
      <Card>
        <h2 className="text-sm font-medium text-gray-400 mb-4">Productos</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-gray-500 text-xs uppercase border-b border-gray-800">
              <th className="text-left pb-3">Producto</th>
              <th className="text-right pb-3">Cant.</th>
              <th className="text-right pb-3">Precio</th>
              <th className="text-right pb-3">Desc.</th>
              <th className="text-right pb-3">Subtotal</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {q.items?.map((item: any) => (
              <tr key={item.id}>
                <td className="py-3">
                  <p className="font-medium">{item.product?.name}</p>
                  <p className="text-xs text-gray-500">{item.product?.sku} · {item.unit}</p>
                </td>
                <td className="py-3 text-right">{Number(item.quantity)}</td>
                <td className="py-3 text-right">{fmt(item.unitPrice)}</td>
                <td className="py-3 text-right text-yellow-400">
                  {Number(item.discount) > 0 ? `-${(Number(item.discount) * 100).toFixed(0)}%` : '—'}
                </td>
                <td className="py-3 text-right font-medium">{fmt(item.subtotal)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totales */}
        <div className="border-t border-gray-800 mt-4 pt-4 space-y-2 text-sm">
          <div className="flex justify-between text-gray-400">
            <span>Subtotal</span>
            <span>{fmt(q.subtotal)}</span>
          </div>
          {q.applyTax && (
            <div className="flex justify-between text-gray-400">
              <span>IVA ({(Number(q.taxRate) * 100).toFixed(0)}%)</span>
              <span>{fmt(q.tax)}</span>
            </div>
          )}
          <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-800">
            <span>Total</span>
            <span className="text-blue-400">{fmt(q.total)}</span>
          </div>
        </div>
      </Card>

      {q.notes && (
        <Card>
          <h2 className="text-sm font-medium text-gray-400 mb-2">Notas</h2>
          <p className="text-sm text-gray-300">{q.notes}</p>
        </Card>
      )}
    </div>
  )
}

// ─── Formulario nueva cotización ─────────────────────────────
function NewQuotation({ onBack }: { onBack: () => void }) {
  const qc = useQueryClient()
  const [items, setItems] = useState([{ productId: '', quantity: 1, unitPrice: 0, discount: 0, unit: 'PIECE', description: '' }])
  const [applyTax, setApplyTax] = useState(false)
  const [notes, setNotes] = useState('')
  const [error, setError] = useState('')

  const { data: products } = useQuery({
    queryKey: ['products-list'],
    queryFn: () => api.get('/products', { params: { limit: 100 } }).then(r => r.data.data),
  })

  const create = useMutation({
    mutationFn: (data: any) => api.post('/quotations', data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['quotations'] }); onBack() },
    onError: (err: any) => setError(err.response?.data?.error?.message || 'Error al crear cotización'),
  })

  const addItem = () => setItems([...items, { productId: '', quantity: 1, unitPrice: 0, discount: 0, unit: 'PIECE', description: '' }])
  const removeItem = (i: number) => setItems(items.filter((_, idx) => idx !== i))
  const updateItem = (i: number, field: string, value: any) => {
    const updated = [...items]
    updated[i] = { ...updated[i], [field]: value }
    if (field === 'productId') {
      const prod = products?.find((p: any) => p.id === value)
      if (prod) { updated[i].unitPrice = Number(prod.price); updated[i].unit = prod.unit }
    }
    setItems(updated)
  }

  const subtotal = items.reduce((s, i) => s + i.quantity * i.unitPrice * (1 - i.discount), 0)
  const tax = applyTax ? subtotal * 0.16 : 0
  const total = subtotal + tax

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    create.mutate({ notes, applyTax, taxRate: 0.16, items })
  }

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>← Volver</Button>
        <h1 className="text-xl font-bold">Nueva cotización</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Items */}
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-medium text-gray-400">Productos</h2>
            <Button type="button" variant="secondary" size="sm" onClick={addItem}>
              <Plus size={14} />Agregar línea
            </Button>
          </div>

          <div className="space-y-3">
            {items.map((item, i) => (
              <div key={i} className="grid grid-cols-12 gap-2 items-end">
                <div className="col-span-4">
                  {i === 0 && <label className="text-xs text-gray-500 mb-1 block">Producto</label>}
                  <select
                    value={item.productId}
                    onChange={e => updateItem(i, 'productId', e.target.value)}
                    required
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  >
                    <option value="">Seleccionar...</option>
                    {(products || []).map((p: any) => (
                      <option key={p.id} value={p.id}>{p.name} ({p.sku})</option>
                    ))}
                  </select>
                </div>
                <div className="col-span-2">
                  {i === 0 && <label className="text-xs text-gray-500 mb-1 block">Cantidad</label>}
                  <input type="number" min="0.01" step="0.01" value={item.quantity}
                    onChange={e => updateItem(i, 'quantity', Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  {i === 0 && <label className="text-xs text-gray-500 mb-1 block">Precio</label>}
                  <input type="number" min="0" step="0.01" value={item.unitPrice}
                    onChange={e => updateItem(i, 'unitPrice', Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  {i === 0 && <label className="text-xs text-gray-500 mb-1 block">Desc. (0-1)</label>}
                  <input type="number" min="0" max="1" step="0.01" value={item.discount}
                    onChange={e => updateItem(i, 'discount', Number(e.target.value))}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div className="col-span-1">
                  {i === 0 && <label className="text-xs text-gray-500 mb-1 block">Unidad</label>}
                  <select value={item.unit} onChange={e => updateItem(i, 'unit', e.target.value)}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-2 py-2 text-xs text-white outline-none focus:border-blue-500"
                  >
                    {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                  </select>
                </div>
                <div className="col-span-1 flex justify-end">
                  {items.length > 1 && (
                    <button type="button" onClick={() => removeItem(i)}
                      className="text-gray-600 hover:text-red-400 transition-colors p-2">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Opciones */}
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Notas</label>
              <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3}
                placeholder="Notas para el cliente..."
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500 resize-none"
              />
            </div>
            <div className="space-y-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={applyTax} onChange={e => setApplyTax(e.target.checked)}
                  className="w-4 h-4 rounded accent-blue-500"
                />
                <span className="text-sm text-gray-300">Aplicar IVA 16%</span>
              </label>

              {/* Preview totales */}
              <div className="bg-gray-800 rounded-lg p-4 space-y-2 text-sm">
                <div className="flex justify-between text-gray-400">
                  <span>Subtotal</span><span>{fmt(subtotal)}</span>
                </div>
                {applyTax && (
                  <div className="flex justify-between text-gray-400">
                    <span>IVA 16%</span><span>{fmt(tax)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-base pt-2 border-t border-gray-700">
                  <span>Total</span>
                  <span className="text-blue-400">{fmt(total)}</span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {error && <p className="text-sm text-red-400 bg-red-400/10 px-4 py-3 rounded-lg">{error}</p>}

        <div className="flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onBack}>Cancelar</Button>
          <Button type="submit" loading={create.isPending}>
            <FileText size={16} />Crear cotización
          </Button>
        </div>
      </form>
    </div>
  )
}

// ─── Controlador principal ────────────────────────────────────
export default function QuotationsPage() {
  const [view, setView] = useState<'list' | 'new' | 'detail'>('list')
  const [selected, setSelected] = useState<any>(null)

  if (view === 'new') return <NewQuotation onBack={() => setView('list')} />
  if (view === 'detail' && selected) return <QuotationDetail quotation={selected} onBack={() => setView('list')} />
  return <QuotationList onNew={() => setView('new')} onSelect={(q) => { setSelected(q); setView('detail') }} />
}
