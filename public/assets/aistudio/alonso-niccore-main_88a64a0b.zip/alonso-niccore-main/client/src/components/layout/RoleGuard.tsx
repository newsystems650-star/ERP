import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';

interface RoleGuardProps {
  allowedRoles: string[];
}

export const RoleGuard = ({ allowedRoles }: RoleGuardProps) => {
  const { token, user } = useAuthStore();
  const location = useLocation();

  // 1. ¿No hay token? A la calle (Login). 
  // Guardamos de dónde venía para regresarlo ahí si se loguea con éxito.
  if (!token || !user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 2. ¿Tiene token pero no tiene el rol necesario? Rebote instantáneo.
  if (!allowedRoles.includes(user.role)) {
    console.warn(`[SEGURIDAD] Intento de intrusión. Rol: ${user.role}`);
    
    // Lo mandamos a su zona permitida
    return user.role === 'ADMIN' 
      ? <Navigate to="/dashboard" replace /> 
      : <Navigate to="/woodentries" replace />;
  }

  // 3. Acceso Autorizado: Renderizamos la vista hija
  return <Outlet />;
};
