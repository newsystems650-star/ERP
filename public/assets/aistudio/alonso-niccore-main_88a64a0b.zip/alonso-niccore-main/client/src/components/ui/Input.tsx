import clsx from 'clsx'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
}

export function Input({ label, error, className, ...props }: InputProps) {
  return (
    <div className="space-y-1">
      {label && <label className="text-sm text-gray-400">{label}</label>}
      <input
        {...props}
        className={clsx(
          'w-full bg-gray-800 border rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 outline-none transition-colors',
          error ? 'border-red-500 focus:border-red-400' : 'border-gray-700 focus:border-blue-500',
          className
        )}
      />
      {error && <p className="text-xs text-red-400">{error}</p>}
    </div>
  )
}

export function Select({ label, error, className, children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string; error?: string }) {
  return (
    <div className="space-y-1">
      {label && <label className="text-sm text-gray-400">{label}</label>}
      <select
        {...props}
        className={clsx(
          'w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-blue-500',
          className
        )}
      >
        {children}
      </select>
      {error && <p className="text-xs text-red-400">{error}</p>}
    </div>
  )
}
