import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import {
  LayoutDashboard, Package, ClipboardList, FileText,
  Users, TrendingUp, Scissors, DollarSign, Truck,
  LogOut, Menu, X, ChevronRight, AlertTriangle
} from 'lucide-react'
import clsx from 'clsx'

const nav = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/tickets', icon: ClipboardList, label: 'Tickets' },
  { to: '/cotizaciones', icon: FileText, label: 'Cotizaciones' },
  { to: '/productos', icon: Package, label: 'Productos' },
  { to: '/clientes', icon: Users, label: 'Clientes' },
  { to: '/inventario', icon: AlertTriangle, label: 'Inventario' },
  { to: '/cortes', icon: Scissors, label: 'Cortes' },
  { to: '/contabilidad', icon: DollarSign, label: 'Contabilidad' },
  { to: '/logistica', icon: Truck, label: 'Logística' },
  { to: '/reportes', icon: TrendingUp, label: 'Reportes' },
  { to: '/madera', icon: Package, label: 'Madera' },
]

export default function Layout() {
  const [open, setOpen] = useState(true)
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()

  const handleLogout = () => { logout(); navigate('/login') }

  return (
    <div className="flex h-screen bg-gray-950 text-white overflow-hidden">
      {/* Sidebar */}
      <aside className={clsx(
        'flex flex-col bg-gray-900 border-r border-gray-800 transition-all duration-300',
        open ? 'w-56' : 'w-16'
      )}>
        {/* Logo */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-gray-800">
          {open && <span className="font-bold text-blue-400 text-lg">NicCore</span>}
          <button onClick={() => setOpen(!open)} className="text-gray-400 hover:text-white">
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 space-y-1 overflow-y-auto">
          {nav.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} className={({ isActive }) => clsx(
              'flex items-center gap-3 px-4 py-2.5 text-sm transition-colors',
              isActive
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:bg-gray-800 hover:text-white'
            )}>
              <Icon size={18} className="shrink-0" />
              {open && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User */}
        <div className="border-t border-gray-800 p-4">
          {open && (
            <div className="mb-3">
              <p className="text-sm font-medium truncate">{user?.name}</p>
              <p className="text-xs text-gray-500">{user?.role}</p>
            </div>
          )}
          <button onClick={handleLogout} className="flex items-center gap-2 text-sm text-gray-400 hover:text-red-400 transition-colors">
            <LogOut size={16} />
            {open && 'Salir'}
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  )
}
