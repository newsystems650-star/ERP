import clsx from 'clsx'

export function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={clsx('bg-gray-900 border border-gray-800 rounded-xl p-6', className)}>
      {children}
    </div>
  )
}

export function StatCard({ label, value, icon: Icon, color = 'blue', sub }: {
  label: string; value: string | number; icon: any; color?: string; sub?: string
}) {
  const colors: Record<string, string> = {
    blue: 'text-blue-400 bg-blue-400/10',
    green: 'text-green-400 bg-green-400/10',
    yellow: 'text-yellow-400 bg-yellow-400/10',
    red: 'text-red-400 bg-red-400/10',
    purple: 'text-purple-400 bg-purple-400/10',
  }
  return (
    <Card>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500">{label}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
          {sub && <p className="text-xs text-gray-500 mt-1">{sub}</p>}
        </div>
        <div className={clsx('p-3 rounded-lg', colors[color])}>
          <Icon size={20} />
        </div>
      </div>
    </Card>
  )
}
