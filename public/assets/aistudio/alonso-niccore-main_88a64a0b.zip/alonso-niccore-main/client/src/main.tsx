import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom/client';

type Health = {
  status: string;
  uptime: number;
  memoryMB: number;
  activeNodes: number;
  eventCount: number;
  persistedBreadcrumbs: number;
  silenceMs: number;
  timestamp: string;
};

function formatDuration(totalSeconds: number): string {
  const seconds = Math.max(0, Math.floor(totalSeconds));
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainder = seconds % 60;
  if (days > 0) return `${days}d ${hours}h ${minutes}m`;
  if (hours > 0) return `${hours}h ${minutes}m ${remainder}s`;
  if (minutes > 0) return `${minutes}m ${remainder}s`;
  return `${remainder}s`;
}

function App() {
  const [health, setHealth] = useState<Health | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    const refresh = async () => {
      try {
        const response = await fetch('/api/health', { cache: 'no-store' });
        if (!response.ok) throw new Error(`API respondió HTTP ${response.status}`);
        const data = await response.json() as Health;
        if (!mounted) return;
        if (data.status !== 'ok') throw new Error('API reportó un estado no saludable');
        setHealth(data);
        setError(null);
      } catch (cause) {
        if (!mounted) return;
        setHealth(null);
        setError(cause instanceof Error ? cause.message : 'No se pudo consultar la API');
      }
    };

    void refresh();
    const timer = window.setInterval(() => void refresh(), 5000);
    return () => {
      mounted = false;
      window.clearInterval(timer);
    };
  }, []);

  const metricCard = (label: string, value: string | number, detail: string) => (
    <section key={label} style={{ background: '#111827', border: '1px solid #273449', borderRadius: 14, padding: 18, minWidth: 0 }}>
      <div style={{ color: '#9ca3af', fontSize: 13, marginBottom: 10 }}>{label}</div>
      <div style={{ color: '#f9fafb', fontSize: 27, fontWeight: 700, overflowWrap: 'anywhere' }}>{value}</div>
      <div style={{ color: '#9ca3af', fontSize: 12, marginTop: 8 }}>{detail}</div>
    </section>
  );

  const silence = !health
    ? 'Sin datos'
    : health.silenceMs < 0
      ? 'Sin eventos'
      : health.silenceMs < 1000
        ? 'Hace menos de 1 s'
        : `Hace ${Math.floor(health.silenceMs / 1000)} s`;

  return (
    <main style={{ minHeight: '100vh', boxSizing: 'border-box', padding: '28px clamp(16px, 4vw, 48px)', fontFamily: 'system-ui, sans-serif', background: '#080d18', color: '#f9fafb' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <header style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 16, marginBottom: 30 }}>
          <div>
            <div style={{ color: '#38bdf8', fontSize: 12, fontWeight: 700, letterSpacing: 3 }}>NICCORE / CONTROL CENTER</div>
            <h1 style={{ margin: '8px 0', fontSize: 'clamp(28px, 5vw, 42px)' }}>Estado del sistema</h1>
            <p style={{ color: '#9ca3af', margin: 0 }}>Métricas leídas de la API. Sin valores simulados.</p>
          </div>
          <div role="status" style={{ display: 'flex', alignItems: 'center', gap: 9, border: `1px solid ${health ? '#166534' : '#7f1d1d'}`, borderRadius: 999, padding: '10px 14px', background: health ? '#052e16' : '#450a0a' }}>
            <span aria-hidden="true" style={{ width: 9, height: 9, borderRadius: '50%', background: health ? '#4ade80' : '#f87171' }} />
            <span>{health ? 'API conectada' : 'API sin verificar'}</span>
          </div>
        </header>

        {!health && (
          <section role="alert" style={{ border: '1px solid #7f1d1d', background: '#1f1115', color: '#fecaca', padding: 16, borderRadius: 12, marginBottom: 20 }}>
            <strong>No hay métricas actuales.</strong>
            <p style={{ marginBottom: 0 }}>{error ?? 'Esperando la primera respuesta de la API.'} Comprueba que el servicio esté iniciado y que /api/health responda.</p>
          </section>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 220px), 1fr))', gap: 14 }}>
          {metricCard('Tiempo activo de API', health ? formatDuration(health.uptime) : '—', 'Tiempo del proceso actual')}
          {metricCard('Memoria Node.js', health ? `${health.memoryMB} MB` : '—', 'Heap usado, no RAM total del host')}
          {metricCard('Nodos activos', health ? health.activeNodes : '—', 'Nodos con telemetría reciente')}
          {metricCard('Eventos registrados', health ? health.eventCount.toLocaleString() : '—', 'Registros recuperados y añadidos por EventStore')}
          {metricCard('Breadcrumbs', health ? health.persistedBreadcrumbs.toLocaleString() : '—', 'Eventos LOGISTICS_NODE_BREADCRUMB')}
          {metricCard('Último evento', silence, health ? `Medido ${new Date(health.timestamp).toLocaleTimeString()}` : 'Sin lectura')}
        </div>

        <footer style={{ marginTop: 26, borderTop: '1px solid #273449', paddingTop: 16, color: '#9ca3af', fontSize: 12, display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', gap: 8 }}>
          <span>Actualización automática cada 5 segundos.</span>
          <span>{health ? `Última lectura: ${new Date(health.timestamp).toLocaleString()}` : 'Última lectura: ninguna'}</span>
        </footer>
      </div>
    </main>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
