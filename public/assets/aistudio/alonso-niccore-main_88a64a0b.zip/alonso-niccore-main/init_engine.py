import os

# Definición de la estructura de carpetas
folders = [
    "src/core/ai",
    "src/core/tenant",
    "src/modules/wood-inventory",
    "src/interfaces/http/controllers",
    "infrastructure/database"
]

# 1. Crear carpetas
for folder in folders:
    os.makedirs(folder, exist_ok=True)
    print(f"✅ Carpeta creada: {folder}")

# 2. Crear binding.gyp (Raíz)
with open("binding.gyp", "w") as f:
    f.write('''{
  "targets": [
    {
      "target_name": "vortex_engine",
      "sources": [ "src/core/ai/cppBridge.cpp" ],
      "include_dirs": [ "<!@(node -p \\"require('node-addon-api').include\\")" ],
      "dependencies": [ "<!(node -p \\"require('node-addon-api').gyp\\")" ],
      "cflags!": [ "-fno-exceptions" ],
      "cflags_cc!": [ "-fno-exceptions" ],
      "defines": [ "NAPI_DISABLE_CPP_EXCEPTIONS" ]
    }
  ]
}''')

# 3. Crear el Motor C++ (cppBridge.cpp)
with open("src/core/ai/cppBridge.cpp", "w") as f:
    f.write('''#include <napi.h>

Napi::Value CalculateWood(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    
    double width = info[0].As<Napi::Number>().DoubleValue();
    double thickness = info[1].As<Napi::Number>().DoubleValue();
    double length = info[2].As<Napi::Number>().DoubleValue();
    int pieces = info[3].As<Napi::Number>().Int32Value();
    double costPerFoot = info[4].As<Napi::Number>().DoubleValue();
    double margin = info[5].As<Napi::Number>().DoubleValue();

    // Lógica Inyectada de Alto Valor
    double feetPerPiece = (width * thickness * length) / 144.0;
    double totalFeet = feetPerPiece * pieces;
    double costTotal = totalFeet * costPerFoot;
    double pricePerPiece = (costTotal / pieces) * (1 + (margin / 100.0));
     double profitTotal = (pricePerPiece * pieces) - costTotal;

    Napi::Object res = Napi::Object::New(env);
    res.Set("feetPerPiece", feetPerPiece);
    res.Set("totalFeet", totalFeet);
    res.Set("pricePerPiece", pricePerPiece);
    res.Set("profitTotal", profitTotal);
    return res;
}

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports.Set(Napi::String::New(env, "calculate"), Napi::Function::New(env, CalculateWood));
    return exports;
}

NODE_API_MODULE(vortex_engine, Init)''')

# 4. Crear el servicio de TS que consume el motor
with open("src/modules/wood-inventory/wood.service.ts", "w") as f:
    f.write('''const vortex = require('../../../build/Release/vortex_engine');

export class WoodService {
    static calculate(data: any) {
        // Ejecución en el Kernel C++
        return vortex.calculate(
            data.widthCm, 
            data.thicknessCm, 
            data.lengthCm, 
            data.totalPieces,
            data.costPerFoot,
            data.marginPercent
        );
    }
}''')

# 5. Crear el controlador HTTP
with open("src/interfaces/http/controllers/wood.controller.ts", "w") as f:
    f.write('''import { WoodService } from '../../../modules/wood-inventory/wood.service';

export const getPreview = (req: any, res: any) => {
    try {
        const result = WoodService.calculate(req.body);
        res.json({ status: 'success', calculations: result });
    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
};''')

print("\\n🚀 ESTRUCTURA GENERADA.")
print("Próximos pasos:\\n1. npm install node-addon-api\\n2. npx node-gyp rebuild\\n3. ¡A correr motores!")
