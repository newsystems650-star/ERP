FROM alpine:3.21 AS builder
RUN apk add --no-cache build-base sqlite-dev
WORKDIR /build
COPY src/native/niccore_engine.cpp ./
RUN g++ -std=c++17 -O2 -Wall -Wextra -Wpedantic -o niccore_engine niccore_engine.cpp -lsqlite3

FROM alpine:3.21
RUN apk add --no-cache sqlite-libs libstdc++
WORKDIR /app
COPY --from=builder /build/niccore_engine /usr/local/bin/niccore_engine
ENV BUNKER_DB=/app/data/niccore_bunker.db
ENTRYPOINT ["/usr/local/bin/niccore_engine"]
