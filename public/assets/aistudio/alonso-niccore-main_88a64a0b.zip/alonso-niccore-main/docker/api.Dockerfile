FROM node:20-alpine
RUN apk add --no-cache libc6-compat
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
# Generamos el cliente sin validar la URL en el build
RUN npx prisma generate
EXPOSE 3000
CMD ["npm", "run", "start:backend"]
