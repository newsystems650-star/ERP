FROM python:3.11-slim
WORKDIR /app
COPY src/brain/ .
CMD ["python", "sentinel.py"]
