# NIC-OS Integration TODO (Alonso Approved)

## Refined Plan Steps

### 1. [x] Create TODO.md & constitution.md
### 2. Update prisma/schema.prisma (RootAuthority/JsonContract/MicroNode/FinSplit/ReputationScore + migrate)
### 3. package.json: + grpc/zod/stripe/or-tools-node + npm i
### 4. src/core/auth.service.ts: + rootVerify (150y hard-timestamp)
### 5. src/core/contracts.service.ts (new): Zod JSON states (OPEN/LOCKED/EXECUTING), penal 10-30%
### 6. src/modules/fintech/ (new): nicc-oportunidad (Stripe préstamos LOCKED-only), sniper-arbitrage (OR-Tools)
### 7. src/brain/sentinel.py: + chained SHA256 fraud/reputación (scikit)
### 8. src/native/niccore_engine.cpp + protos/: gRPC (mlock-safe, OR-Tools routing/cubicaje/ROI)
### 9. docker-compose.yml/prod.yml: gRPC ports, healthchecks
### 10. src/core/orchestrator.service.ts: Integrate Meta + contracts
### 11. Tests: convoy sim + npm run dev
### 12. gh pr create blackboxai/nic-os-constitution

### 2. [x] Update prisma/schema.prisma (models added)

### 3. [x] package.json + npm i
### 4. [x] auth.service.ts + rootVerify
### 5. [x] contracts.service.ts (Zod + chained SHA256)

### 6. [x] fintech/ nicc-oportunidad + sniper-arbitrage (Stripe/gRPC)

Progress: 6/12
Next: sentinel.py + scikit fraud.

