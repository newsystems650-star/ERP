#!/data/data/com.termux/files/usr/bin/bash
# NicCore Node Emisor V2
# Dependencias: pkg install termux-api netcat openssl jq
# Permisos: chmod 600 ~/.nicnode_secret && chmod +x nicnode.sh

NODE_ID="ZARCO_01"
SECRET="$(cat ~/.nicnode_secret)"
DEST_IP="TU_IP_PUBLICA_O_DDNS"
DEST_PORT="41234"
TRIP_ID="$(uuidgen)"
INTERVALO=3

echo "[NicNode] Nodo: $NODE_ID | Trip: $TRIP_ID"

while true; do
    RAW=$(termux-location -p gps -r once 2>/dev/null)
    if [ -z "$RAW" ]; then sleep $INTERVALO; continue; fi

    LAT=$(echo "$RAW" | jq -r '.latitude')
    LON=$(echo "$RAW" | jq -r '.longitude')
    VEL=$(echo "$RAW" | jq -r '.speed // 0' | awk '{printf "%.1f", $1 * 3.6}')
    TS=$(date +%s)

    CUERPO="${NODE_ID}|${LAT}|${LON}|${VEL}|${TS}|${TRIP_ID}"
    FIRMA=$(printf '%s' "$CUERPO" | openssl dgst -sha256 -hmac "$SECRET" | awk '{print $2}')

    printf '%s' "${CUERPO}|${FIRMA}" | nc -u -w1 "$DEST_IP" "$DEST_PORT"
    echo "[$(date '+%H:%M:%S')] TX → $CUERPO"
    sleep $INTERVALO
done
