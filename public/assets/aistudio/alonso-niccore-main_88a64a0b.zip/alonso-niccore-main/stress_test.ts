// stress_test.ts
import { WoodInventoryService } from './src/modules/wood-inventory/wood.service';
import { WoodPhysicalParams } from './src/modules/wood-inventory/types';

async function runStressTest() {
    console.log("🔥 INICIANDO PRUEBA DE ESTRÉS DEL MOTOR VORTEX (C++) 🔥");
    
    const TOTAL_REQUESTS = 1000;
    const CONCURRENCY = 50; // Mandaremos bloques de 50 cálculos simultáneos

    // Datos físicos de prueba (El Tensor que espera C++)
    const testData: WoodPhysicalParams = {
        widthMm: 152.4,       // 6 pulgadas
        thicknessMm: 50.8,    // 2 pulgadas
        lengthMm: 2438.4,     // 8 pies
        totalPieces: 100,
        baseHumidity: 15.0,   // Capa Impredecible
        shrinkageFactor: 0.025,
        costPerFoot: 1.20,
        marginPercent: 35.0
    };

    const start = Date.now();
    let successCount = 0;
    let failCount = 0;

    console.log(`Bombardeando el Cerebro con ${TOTAL_REQUESTS} operaciones pesadas...`);

    for (let i = 0; i < TOTAL_REQUESTS; i += CONCURRENCY) {
        const batch = [];
        for (let j = 0; j < CONCURRENCY; j++) {
            batch.push(
                WoodInventoryService.executeFullSale(testData)
                    .then(() => successCount++)
                    .catch((err) => {
                        console.error("Fallo:", err.message);
                        failCount++;
                    })
            );
        }
        // Esperamos a que el lote termine antes de mandar el siguiente
        await Promise.all(batch);
        process.stdout.write(`...${i + CONCURRENCY} `);
    }

    const end = Date.now();
    const durationSec = (end - start) / 1000;

    console.log("\n\n🛑 === REPORTE DE SOBERANÍA === 🛑");
    console.log(`Tiempo total:   ${durationSec} segundos`);
    console.log(`✅ Éxitos:      ${successCount}`);
    console.log(`❌ Fallos:      ${failCount}`);
    console.log(`⚡ Rendimiento:  ${(TOTAL_REQUESTS / durationSec).toFixed(2)} transacciones/segundo`);
    console.log("===================================");
    
    process.exit(0);
}

runStressTest();
