#!/bin/bash
# Generar par llaves USB para Nic-Scanner firma
# Run: ./usb_key_gen.sh && chmod 600 /home/alonso/usb_key.bin

KEYFILE="/home/alonso/usb_key.bin"
openssl rand -hex 32 | xxd -r -p > $KEYFILE
echo "Llave USB generada: $KEYFILE (256-bit random)"
ls -la $KEYFILE
