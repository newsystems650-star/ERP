import { tenantStorage } from './src/core/tenant/tenantContext';
import { WoodInventoryService } from './src/modules/wood-inventory/wood.service';

const context = {
    tenantId: 'NICCORE-PRO-001',
    userId: 'ALONSO-STAFF-ENGINEER'
};

tenantStorage.run(context, async () => {
    console.log("🚀 INICIANDO ECOSISTEMA...");
    
    const input = {
        widthCm: 30, thicknessCm: 2.5, lengthCm: 250,
        totalPieces: 140, costPerFoot: 18, marginPercent: 30
    };

    try {
        const start = process.hrtime.bigint();
        const result = await WoodInventoryService.executeFullSale(input);
        const end = process.hrtime.bigint();

        console.log("\n--- ✅ FLUJO COMPLETO FINALIZADO ---");
        console.log("📦 Stock Procesado: " + result.data.totalFeet.toFixed(2) + " pies");
        console.log("🆔 Event ID: " + result.auditId);
        console.log("⏱️  Latencia de lógica: " + (Number(end - start) / 1000000) + " ms");
    } catch (err) {
        console.error("❌ Error en el flujo:", err);
    }
});
