# NICCORE Runtime V1

First vertical slice: persistent tasks, bounded execution, registered handlers, audit events, and recovery. Reuse the existing EventBus, EventStore, Express entry point, and health endpoint. Keep changes on feat/niccore-runtime-v1 and do not merge until build/tests pass.
