# 🔧 SETUP: Blindaje Total — Paso a Paso

**Tiempo estimado:** 2-3 horas
**Requisitos:** Node.js 20+, g++, OpenSSL dev headers, Docker

---

## PASO 1: Compilar nic_scanner.cpp

```bash
# Instalar dependencias (si no están)
sudo apt-get install -y libssl-dev build-essential

# Compilar
g++ -O3 -std=c++17 -o bin/nic_scanner src/core/nic_scanner.cpp -lssl -lcrypto

# Verificar
./bin/nic_scanner &
# Deberías ver:
# [nic_scanner] Iniciado. Socket: /tmp/nic_scanner.sock
# [nic_scanner] Tick: API=512KB Engine=256KB Sentinel=64KB | RAM=45.2% ✓
```

---

## PASO 2: Instalar dependencias de Forecast

```bash
npm install
# Las deps ya están en package.json
```

---

## PASO 3: Migración Prisma (Sensores + Eventos)

```bash
# Generar migrate
npx prisma migrate dev --name sensor_fusion_and_events

# Verificar que creó:
# - SensorReadings table
# - EventLog table
# - ReputationHistory table
```

---

## PASO 4: Integrar Forecast en src/index.ts

```typescript
import { startForecastScheduler } from './core/ai/forecast';
import { handleCentralDowntime } from './core/mesh/mesh.router';

app.listen(3000, async () => {
  console.log('✅ API escuchando en :3000');
  startForecastScheduler();
  await handleCentralDowntime();
});
```

---

## PASO 5: Prueba End-to-End

### Terminal 1: Ejecutar nic_scanner
```bash
./bin/nic_scanner
```

### Terminal 2: Ejecutar servidor
```bash
npm run dev
```

### Terminal 3: Inyectar datos de prueba
```bash
curl -X POST http://localhost:3000/api/rutas/test-anomaly \
  -H "Content-Type: application/json" \
  -d '{
    "nodeId": "TEST_NODE_001",
    "tripId": "trip-abc123",
    "lat": 19.432,
    "lon": -99.133,
    "velocity": 120
  }'
```

---

## PASO 6: Deploy Docker

```bash
docker-compose -f docker-compose.optimized.yml up -d

# Verificar logs
docker-compose logs -f api
```

---

## 🎯 CHECKLIST FINAL

- [ ] nic_scanner compila sin errores
- [ ] Prisma migrations executadas
- [ ] forecast.ts integrado en index.ts
- [ ] Mesh router escuchando en :50051
- [ ] Redis streams funcionan
- [ ] EventLog tabla poblándose
- [ ] Docker build exitoso
- [ ] Cero deps externas de IA/ML

---

## 🚨 TROUBLESHOOTING

### Error: "EADDRINUSE port 50051"
```bash
# Cambiar puerto en mesh.router.ts
# meshManager = new MeshTopologyManager(50052);
```

### Error: "Prisma migration pending"
```bash
npx prisma migrate dev --name fix
```