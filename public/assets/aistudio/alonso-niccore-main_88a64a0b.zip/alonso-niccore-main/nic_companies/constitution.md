# NIC COMPANIES - CONSTITUCIÓN

## Misión
Construir un ecosistema tecnológico para la reparación y gestión de dispositivos móviles.

## Visión
Ser la plataforma de referencia para talleres de reparación en Latinoamérica.

## Valores
- Profesionalismo
- Legalidad
- Transparencia
- Calidad
- Innovación
