import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function fix() {
  await prisma.user.upsert({
    where: { email: 'admin@niccore.com' },
    update: { id: 'admin-dev', tenantId: 'niccore-master' },
    create: {
      id: 'admin-dev',
      tenantId: 'niccore-master',
      name: 'Alonso Root',
      email: 'admin@niccore.com',
      password: 'password123',
      role: 'ADMIN'
    }
  });
  console.log("✅ Usuario maestro sincronizado: admin-dev");
  process.exit(0);
}
fix();
