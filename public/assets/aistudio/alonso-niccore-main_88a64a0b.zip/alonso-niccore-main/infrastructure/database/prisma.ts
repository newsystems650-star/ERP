import { PrismaClient } from '@prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'
import { PrismaLibSql } from '@prisma/adapter-libsql'
import { createClient } from '@libsql/client'
import pg from 'pg'

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL })
const pgAdapter = new PrismaPg(pool)

const libsql = createClient({ url: 'file:./prisma/niccore_bunker.db' })
const sqliteAdapter = new PrismaLibSql(libsql)

const adapter = process.env.BUNKER_MODE === 'true' ? sqliteAdapter : pgAdapter

export const prisma = new PrismaClient({ adapter })

export default prisma

import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };

export const prisma =
    globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== 'production') {
    globalForPrisma.prisma = prisma;
}
