const vortex = require('./build/Release/vortex_engine');

// Datos de prueba (tu calculadora de madera)
const data = {
    width: 30,
    thickness: 2.5,
    length: 250,
    pieces: 140,
    cost: 18,
    margin: 30
};

console.log("--- ⚡ ENCENDIENDO MOTORES VORTEX ---");

const start = process.hrtime.bigint();

// Llamada al motor de metal
const result = vortex.calculate(
    data.width, 
    data.thickness, 
    data.length, 
    data.pieces, 
    data.cost, 
    data.margin
);

const end = process.hrtime.bigint();
const nanoseconds = Number(end - start);

console.log("✅ RESULTADO:", result);
console.log(`⏱️  TIEMPO: ${nanoseconds} nanosegundos (${nanoseconds / 1000000} ms)`);

if (nanoseconds < 1000000) {
    console.log("\\n🔥 NIVEL DIOS: El cálculo fue tan rápido que Node.js casi no pudo medirlo.");
}
