import fs from 'fs';
import path from 'path';

console.log("🔍 INICIANDO HEALTH-CHECK DE ARQUITECTURA...");

const criticalPaths = [
  './binding.gyp',
  './build/Release/vortex_engine.node',
  './src/core/tenant/tenantContext.ts',
  './src/core/event-store/eventStore.ts',
  './src/core/event-store/eventBus.ts',
  './src/modules/wood-inventory/wood.service.ts',
  './src/modules/wood-inventory/wood.projection.ts'
];

let allOk = true;

criticalPaths.forEach(p => {
  if (fs.existsSync(p)) {
    console.log("✅ OK: " + p);
  } else {
    console.log("❌ ERROR: No se encuentra " + p);
    allOk = false;
  }
});

if (allOk) {
  try {
    const vortex = require('./build/Release/vortex_engine');
    console.log("🔥 MOTOR C++: Vinculado y respondiendo.");
    console.log("\n🚀 SISTEMA LISTO PARA OPERACIONES DE ALTO VALOR.");
  } catch (e) {
    console.log("⚠️ MOTOR C++: Archivo existe pero no se puede cargar. Revisa 'npx node-gyp rebuild'.");
  }
} else {
  console.log("\n🛑 ARQUITECTURA INCOMPLETA: Revisa los archivos faltantes.");
}
