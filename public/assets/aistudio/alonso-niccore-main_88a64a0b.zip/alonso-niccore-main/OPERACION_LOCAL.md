# NICCORE: arranque local verificable

Esta guía arranca el primer recorrido funcional: API Express, endpoint de salud, registro persistente de eventos y monitor Sentinel. No significa que todos los módulos de negocio, base de datos y motores nativos estén ya validados.

## Requisitos

- Docker Engine con Docker Compose v2.
- Acceso al repositorio y espacio para construir la imagen de Node.
- No necesitas crear un archivo `.env` para iniciar el prototipo; Compose tiene valores de desarrollo predeterminados.

## Arrancar

Desde la raíz del repositorio:

```sh
docker compose up --build -d
```

Abre el Control Center en `http://127.0.0.1:5173`. Muestra solo métricas recibidas de la API y se actualiza cada cinco segundos.

Verifica que los servicios estén sanos:

```sh
docker compose ps
```

Comprueba el endpoint básico:

```sh
curl -fsS http://127.0.0.1:3000/health
```

Comprueba las métricas reales del proceso y del EventStore:

```sh
curl -fsS http://127.0.0.1:3000/api/health
```

Consulta los registros si un servicio no arranca:

```sh
docker compose logs --tail=150 api sentinel
```

Ejecuta las pruebas del núcleo en un entorno con Node.js 20 o superior:

```sh
npm ci && npm test
```

## Perfil de producción (requiere secretos propios)

No publiques el perfil de producción con los valores de ejemplo. Crea un archivo local ignorado por Git y sustituye todos los marcadores:

```sh
cp .env.prod.example .env.prod
```

Valida la configuración antes de iniciar contenedores:

```sh
docker compose --env-file .env.prod -f docker-compose.prod.yml config --quiet
```

Arranca el perfil de producción:

```sh
docker compose --env-file .env.prod -f docker-compose.prod.yml up --build -d
```

El Control Center se sirve por `http://127.0.0.1:8080`; la API no publica su puerto HTTP directamente. El perfil usa PostgreSQL y Redis internos. **Esto sigue siendo un despliegue por validar**: no se han ejecutado migraciones de negocio ni pruebas en tu servidor. No subas `.env.prod` a Git.

## Inicializador nativo SQLite

El motor C++ actual es un **inicializador de esquema de una sola ejecución**, no un daemon. Se mantiene fuera del arranque predeterminado para no fingir que es un servicio permanente. Para construirlo y crear/verificar su base SQLite persistente:

```sh
docker compose --profile native-engine run --rm engine
```

La base se guarda en el volumen `shared-bunker`. El inicializador crea las tablas `Company`, `Job` y `BrainAudit`; no migra ni modifica la base de PostgreSQL.

## Telemetría UDP

El receptor UDP está **deshabilitado por defecto**. No lo habilites hasta configurar claves por nodo.

1. Copia `.env.example` a `.env` y cambia la contraseña local si corresponde.
2. Define `NICCORE_UDP_ENABLED=true`.
3. Define `NIC_NODE_KEYS_B64` como Base64 de un objeto JSON cuyas claves sean IDs de nodo y cuyos valores sean secretos aleatorios de al menos 16 caracteres.
4. Reconstruye y reinicia con `docker compose up --build -d api sentinel`.

No guardes secretos reales en Git ni los pegues en incidencias o conversaciones. Los puertos del prototipo se publican en loopback por defecto; si necesitas recibir paquetes desde otros equipos, configura deliberadamente la exposición de red después de proteger y probar el receptor.

## Persistencia y límites

- El EventStore conserva eventos en un volumen Docker llamado `niccore-events`; los registros sobreviven a la recreación del contenedor.
- No ejecutes `docker compose down -v` si necesitas conservar datos: esa opción elimina volúmenes.
- El endpoint `/health` comprueba que responde la API. `/api/health` añade métricas del proceso y del registro de eventos.
- La telemetría UDP solo genera eventos si llega un paquete válido con HMAC, ID de nodo configurado y marca temporal dentro de la ventana de replay.
- Esta configuración no ejecuta migraciones de Prisma ni valida todos los módulos TypeScript/C++ del repositorio. No debe anunciarse como producción hasta completar esas pruebas y revisar autenticación, secretos y persistencia de negocio.
