-- CreateEnum
CREATE TYPE "ExpenseType" AS ENUM ('SALARY', 'SUPPLIER', 'RENT', 'UTILITIES', 'MAINTENANCE', 'TAXES', 'OTHER');

-- CreateEnum
CREATE TYPE "PayPeriod" AS ENUM ('WEEKLY', 'BIWEEKLY', 'MONTHLY');

-- CreateTable
CREATE TABLE "expenses" (
    "id" TEXT NOT NULL,
    "type" "ExpenseType" NOT NULL,
    "category" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "amount" DECIMAL(12,4) NOT NULL,
    "tax" DECIMAL(12,4) NOT NULL DEFAULT 0,
    "total" DECIMAL(12,4) NOT NULL,
    "reference" TEXT,
    "date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "expenses_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "employees" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "position" TEXT NOT NULL,
    "salary" DECIMAL(12,4) NOT NULL,
    "payPeriod" "PayPeriod" NOT NULL DEFAULT 'BIWEEKLY',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "startDate" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "employees_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "payrolls" (
    "id" TEXT NOT NULL,
    "periodStart" TIMESTAMP(3) NOT NULL,
    "periodEnd" TIMESTAMP(3) NOT NULL,
    "baseSalary" DECIMAL(12,4) NOT NULL,
    "bonuses" DECIMAL(12,4) NOT NULL DEFAULT 0,
    "deductions" DECIMAL(12,4) NOT NULL DEFAULT 0,
    "total" DECIMAL(12,4) NOT NULL,
    "notes" TEXT,
    "paid" BOOLEAN NOT NULL DEFAULT false,
    "paidAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "employeeId" TEXT NOT NULL,

    CONSTRAINT "payrolls_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cut_sheets" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "stockWidth" DECIMAL(10,4) NOT NULL,
    "stockHeight" DECIMAL(10,4) NOT NULL,
    "stockQty" INTEGER NOT NULL DEFAULT 1,
    "kerf" DECIMAL(6,4) NOT NULL DEFAULT 0.003,
    "efficiency" DECIMAL(5,4),
    "waste" DECIMAL(10,4),
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "cut_sheets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cut_pieces" (
    "id" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "width" DECIMAL(10,4) NOT NULL,
    "height" DECIMAL(10,4) NOT NULL,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "grain" BOOLEAN NOT NULL DEFAULT false,
    "cutSheetId" TEXT NOT NULL,

    CONSTRAINT "cut_pieces_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cut_results" (
    "id" TEXT NOT NULL,
    "layout" JSONB NOT NULL,
    "efficiency" DECIMAL(5,4) NOT NULL,
    "waste" DECIMAL(10,4) NOT NULL,
    "sheets" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "cutSheetId" TEXT NOT NULL,

    CONSTRAINT "cut_results_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "expenses" ADD CONSTRAINT "expenses_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "payrolls" ADD CONSTRAINT "payrolls_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "employees"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cut_sheets" ADD CONSTRAINT "cut_sheets_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cut_pieces" ADD CONSTRAINT "cut_pieces_cutSheetId_fkey" FOREIGN KEY ("cutSheetId") REFERENCES "cut_sheets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cut_results" ADD CONSTRAINT "cut_results_cutSheetId_fkey" FOREIGN KEY ("cutSheetId") REFERENCES "cut_sheets"("id") ON DELETE CASCADE ON UPDATE CASCADE;
