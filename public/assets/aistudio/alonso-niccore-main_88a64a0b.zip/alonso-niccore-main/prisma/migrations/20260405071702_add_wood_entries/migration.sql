-- CreateEnum
CREATE TYPE "WoodClass" AS ENUM ('PRIMERA', 'SEGUNDA', 'TERCERA', 'ESPECIAL');

-- CreateTable
CREATE TABLE "wood_entries" (
    "id" TEXT NOT NULL,
    "entryCode" TEXT NOT NULL,
    "woodType" TEXT NOT NULL,
    "woodClass" "WoodClass" NOT NULL,
    "supplierId" TEXT,
    "widthCm" DECIMAL(8,2) NOT NULL,
    "lengthCm" DECIMAL(8,2) NOT NULL,
    "thicknessCm" DECIMAL(8,2) NOT NULL,
    "widthInch" DECIMAL(8,4) NOT NULL,
    "lengthFeet" DECIMAL(8,4) NOT NULL,
    "thicknessInch" DECIMAL(8,4) NOT NULL,
    "totalPieces" INTEGER NOT NULL,
    "totalFeet" DECIMAL(12,4) NOT NULL,
    "totalM3" DECIMAL(12,6) NOT NULL,
    "costPerFoot" DECIMAL(10,4) NOT NULL,
    "totalCost" DECIMAL(12,4) NOT NULL,
    "marginPercent" DECIMAL(5,2) NOT NULL,
    "pricePerFoot" DECIMAL(10,4) NOT NULL,
    "pricePerPiece" DECIMAL(10,4) NOT NULL,
    "pricePerM3" DECIMAL(10,4) NOT NULL,
    "pricePerM2" DECIMAL(10,4),
    "pricePerInch" DECIMAL(10,4),
    "profitPerFoot" DECIMAL(10,4) NOT NULL,
    "profitPerPiece" DECIMAL(10,4) NOT NULL,
    "profitTotal" DECIMAL(12,4) NOT NULL,
    "notes" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT NOT NULL,
    "productId" TEXT,

    CONSTRAINT "wood_entries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "wood_strips" (
    "id" TEXT NOT NULL,
    "widthCm" DECIMAL(6,2) NOT NULL,
    "piecesPerPlan" INTEGER NOT NULL,
    "totalPieces" INTEGER NOT NULL,
    "pricePerPiece" DECIMAL(10,4) NOT NULL,
    "woodEntryId" TEXT NOT NULL,

    CONSTRAINT "wood_strips_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "wood_entries_entryCode_key" ON "wood_entries"("entryCode");

-- AddForeignKey
ALTER TABLE "wood_entries" ADD CONSTRAINT "wood_entries_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "suppliers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "wood_entries" ADD CONSTRAINT "wood_entries_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "wood_entries" ADD CONSTRAINT "wood_entries_productId_fkey" FOREIGN KEY ("productId") REFERENCES "products"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "wood_strips" ADD CONSTRAINT "wood_strips_woodEntryId_fkey" FOREIGN KEY ("woodEntryId") REFERENCES "wood_entries"("id") ON DELETE CASCADE ON UPDATE CASCADE;
