{
        "file": "src/native/niccore_engine.cpp",
        "filename": "niccore_engine.cpp",
        "hash": "ba205060a6fd85f4cf4c7155744ff1dc9e43646a1d9d031d01773ac2159dab49",
        "size": 1654,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
