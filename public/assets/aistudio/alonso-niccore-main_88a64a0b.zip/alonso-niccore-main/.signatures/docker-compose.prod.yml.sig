{
        "file": "docker-compose.prod.yml",
        "filename": "docker-compose.prod.yml",
        "hash": "fa8374c08f0628ed63a98555c323e706c6f5e7b8b70e8a8f53626e70921e0c0f",
        "size": 1158,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
