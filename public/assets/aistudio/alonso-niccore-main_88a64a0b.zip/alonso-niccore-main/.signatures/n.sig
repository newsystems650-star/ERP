{
        "file": "n",
        "filename": "n",
        "hash": "f6845a0b0a76699c128bb961cd5f3cc21077b140a2b4e54f0f987410c5e85194",
        "size": 980,
        "modified": "2026-08-01 05:02:55.127540905 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
