{
        "file": "src/brain/test_motor_calculo.py",
        "filename": "test_motor_calculo.py",
        "hash": "bdbb2a39219f921fc53a8f505a7861dd366fec59b0f1eae2aa91f4a0256663b4",
        "size": 1516,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
