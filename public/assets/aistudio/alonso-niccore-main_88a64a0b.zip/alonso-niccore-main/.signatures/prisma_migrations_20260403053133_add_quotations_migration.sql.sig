{
        "file": "prisma/migrations/20260403053133_add_quotations/migration.sql",
        "filename": "migration.sql",
        "hash": "800c745b922cef2e30147bb2ff03d3a62e26f7d459619080b1467da57e3f9762",
        "size": 2312,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
