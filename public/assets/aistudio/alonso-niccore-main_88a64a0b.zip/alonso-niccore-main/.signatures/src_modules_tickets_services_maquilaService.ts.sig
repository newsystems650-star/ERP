{
        "file": "src/modules/tickets/services/maquilaService.ts",
        "filename": "maquilaService.ts",
        "hash": "ddeac91bfd7b76f47b18cc7db4ba679334dfe2a82ae166f6003cb4b055107282",
        "size": 819,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
