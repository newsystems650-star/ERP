{
        "file": "client/eslint.config.js",
        "filename": "eslint.config.js",
        "hash": "4efe97b16d1200fac0eaf07aa00930a8668b1f96a0be1891ace8c1e712ff0ccb",
        "size": 616,
        "modified": "2026-07-31 05:15:34.986803331 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
