{
        "file": "src/core/nic_editor_core.cpp",
        "filename": "nic_editor_core.cpp",
        "hash": "93e168945895110451296f096c1ab42c4b3bdbf010059c25c4ea0eb1607b8dde",
        "size": 230,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
