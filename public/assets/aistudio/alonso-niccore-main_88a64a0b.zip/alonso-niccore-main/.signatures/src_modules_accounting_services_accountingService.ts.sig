{
        "file": "src/modules/accounting/services/accountingService.ts",
        "filename": "accountingService.ts",
        "hash": "172b58cd6497962da03b4bd2d37f6415029d7abaf0b81dfdb7875ca33190555d",
        "size": 5555,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
