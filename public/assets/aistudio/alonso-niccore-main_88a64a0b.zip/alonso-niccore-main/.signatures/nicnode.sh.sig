{
        "file": "nicnode.sh",
        "filename": "nicnode.sh",
        "hash": "0998ff322104f493a358f91caaed14db45d785dc94994eba437fb7dc8815bb32",
        "size": 992,
        "modified": "2026-07-31 05:15:34.992803903 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
