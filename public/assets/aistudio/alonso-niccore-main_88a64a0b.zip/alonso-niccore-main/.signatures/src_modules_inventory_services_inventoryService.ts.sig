{
        "file": "src/modules/inventory/services/inventoryService.ts",
        "filename": "inventoryService.ts",
        "hash": "98e8de182a721087136b63fb36e1807c6243b94eb00b766611598b2c797ccd09",
        "size": 1434,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
