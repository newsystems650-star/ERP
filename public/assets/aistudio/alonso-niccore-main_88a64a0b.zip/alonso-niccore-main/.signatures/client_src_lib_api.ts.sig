{
        "file": "client/src/lib/api.ts",
        "filename": "api.ts",
        "hash": "8e794b7eac6edd0883cab92df4412a29605390a87d909ccd535aabc4c6f9e3af",
        "size": 564,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
