{
        "file": "src/core/contracts.service.ts",
        "filename": "contracts.service.ts",
        "hash": "a06f51875f35c95ffc41f46f9fa4ff9ff2eb26105ec7726a6d09c34aa734d09c",
        "size": 1697,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
