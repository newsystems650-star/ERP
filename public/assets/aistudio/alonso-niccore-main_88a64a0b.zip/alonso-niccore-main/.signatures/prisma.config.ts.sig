{
        "file": "prisma.config.ts",
        "filename": "prisma.config.ts",
        "hash": "23a2df65cea8a1fae5a543d04953996d560ed8ff84ebe798ed3a5672103e47b7",
        "size": 185,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
