{
        "file": "signature_system.sh",
        "filename": "signature_system.sh",
        "hash": "00eba62707b6fd912b3c40b9b6515c32f3cfc141ca2cdd3f1eba1a45cf8da4a9",
        "size": 5362,
        "modified": "2026-08-01 07:33:07.929360837 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
