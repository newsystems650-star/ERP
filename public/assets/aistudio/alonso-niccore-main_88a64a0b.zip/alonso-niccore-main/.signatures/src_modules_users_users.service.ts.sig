{
        "file": "src/modules/users/users.service.ts",
        "filename": "users.service.ts",
        "hash": "5dfe1241ac48cba1bc79d5383a229650caabc099b162a8e631615ca5130bb706",
        "size": 208,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
