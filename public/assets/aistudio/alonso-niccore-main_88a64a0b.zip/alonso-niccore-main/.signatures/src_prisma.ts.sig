{
        "file": "src/prisma.ts",
        "filename": "prisma.ts",
        "hash": "420319b87f90722840ddb3de2ddcceea63e89619cc6692090038199368a03bf8",
        "size": 90,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
