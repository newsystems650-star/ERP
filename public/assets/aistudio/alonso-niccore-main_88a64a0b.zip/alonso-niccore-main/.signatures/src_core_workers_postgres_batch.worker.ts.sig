{
        "file": "src/core/workers/postgres_batch.worker.ts",
        "filename": "postgres_batch.worker.ts",
        "hash": "c135ef18f545e454899ece7824d852f0281a0b448f80645ae5e578d9bbfcd5d5",
        "size": 2051,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
