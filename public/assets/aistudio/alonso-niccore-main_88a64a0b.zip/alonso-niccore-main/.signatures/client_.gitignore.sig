{
        "file": "client/.gitignore",
        "filename": ".gitignore",
        "hash": "fe718e7babb14f3cbad2d97f08889b9ce5215ed3fe0e43b2b8cfbfb3b9b844e8",
        "size": 253,
        "modified": "2026-07-31 05:15:34.986803331 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
