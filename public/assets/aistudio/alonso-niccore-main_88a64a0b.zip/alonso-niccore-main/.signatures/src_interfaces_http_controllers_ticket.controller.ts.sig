{
        "file": "src/interfaces/http/controllers/ticket.controller.ts",
        "filename": "ticket.controller.ts",
        "hash": "5cdd3ce3810bb4920535c47eba6492afe587620697368f18d06960232c8804e2",
        "size": 708,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
