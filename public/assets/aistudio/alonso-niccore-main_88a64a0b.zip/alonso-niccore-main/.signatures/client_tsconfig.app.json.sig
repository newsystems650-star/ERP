{
        "file": "client/tsconfig.app.json",
        "filename": "tsconfig.app.json",
        "hash": "aa9e68711a716c499b5730aa6664cab7e6a2cb65e9924252cefe2135a4724112",
        "size": 732,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
