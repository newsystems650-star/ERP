{
        "file": "src/modules/tickets/validators/ticketValidator.ts",
        "filename": "ticketValidator.ts",
        "hash": "722db79f744e7d34d0ff08ff346498ab99eaae6541d201f7a7cd34491f06cd85",
        "size": 528,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
