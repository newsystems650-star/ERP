{
        "file": "src/shared/contracts/wood_test.contract.ts",
        "filename": "wood_test.contract.ts",
        "hash": "cb3a71e555196ced9bf7917366b978813f2e05471fa9274df993367a518295e7",
        "size": 472,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
