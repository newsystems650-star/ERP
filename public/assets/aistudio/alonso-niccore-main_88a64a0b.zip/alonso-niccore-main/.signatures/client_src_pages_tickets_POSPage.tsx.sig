{
        "file": "client/src/pages/tickets/POSPage.tsx",
        "filename": "POSPage.tsx",
        "hash": "a6d58377463df9da9ed1018c66ec006d8637dc7905fe750a86df8aa0576e0903",
        "size": 14147,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
