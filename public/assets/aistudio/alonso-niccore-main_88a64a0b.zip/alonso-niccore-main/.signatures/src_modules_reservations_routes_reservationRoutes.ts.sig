{
        "file": "src/modules/reservations/routes/reservationRoutes.ts",
        "filename": "reservationRoutes.ts",
        "hash": "7c00cec77684eb0884230f5cbaea9a0a0f6a7556ba00a1e9050a1d6c08190005",
        "size": 715,
        "modified": "2026-07-31 05:15:35.004805046 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
