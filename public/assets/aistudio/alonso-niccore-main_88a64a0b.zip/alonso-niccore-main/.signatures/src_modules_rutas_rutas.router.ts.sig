{
        "file": "src/modules/rutas/rutas.router.ts",
        "filename": "rutas.router.ts",
        "hash": "566ed6a214d83d62c283a3184fabc2ed96efa7082f580816f508d1e7c0d53b39",
        "size": 1645,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
