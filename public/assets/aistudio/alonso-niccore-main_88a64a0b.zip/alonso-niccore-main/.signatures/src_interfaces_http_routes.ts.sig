{
        "file": "src/interfaces/http/routes.ts",
        "filename": "routes.ts",
        "hash": "cd7b1a623ee0edd0ff32585b96e5ef175670bb931a40027aa1262ec49811f53f",
        "size": 343,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
