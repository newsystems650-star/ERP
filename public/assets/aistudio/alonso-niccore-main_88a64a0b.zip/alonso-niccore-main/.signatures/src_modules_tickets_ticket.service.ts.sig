{
        "file": "src/modules/tickets/ticket.service.ts",
        "filename": "ticket.service.ts",
        "hash": "77960cd4aaff062cbcc4e093430a4ec7da6aa1a58216fe29dfa7ca5a0c4b5176",
        "size": 1896,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
