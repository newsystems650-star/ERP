{
        "file": "src/core/projections/map.projection.ts",
        "filename": "map.projection.ts",
        "hash": "6ceab3d0b4c1f486ea306b7e8069bfdeb00e886231de4c9f1cf964006c66061c",
        "size": 2543,
        "modified": "2026-08-01 05:50:48.960070963 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
