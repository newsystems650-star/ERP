{
        "file": "src/core/orchestrator.service.ts",
        "filename": "orchestrator.service.ts",
        "hash": "98f2d20eb7a2cba10dad135fc075ffc36255940c0a75aa46f1a54ef213ed0ecf",
        "size": 1301,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
