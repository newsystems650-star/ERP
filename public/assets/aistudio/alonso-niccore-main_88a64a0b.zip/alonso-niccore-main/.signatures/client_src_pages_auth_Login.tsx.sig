{
        "file": "client/src/pages/auth/Login.tsx",
        "filename": "Login.tsx",
        "hash": "3d8ce2a66b9662cb6b38bd68aef1a35bd4ae5cb66dd82c81a33653f67dac4cc0",
        "size": 2959,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
