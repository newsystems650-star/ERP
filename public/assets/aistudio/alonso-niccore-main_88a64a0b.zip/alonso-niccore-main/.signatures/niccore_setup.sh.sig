{
        "file": "niccore_setup.sh",
        "filename": "niccore_setup.sh",
        "hash": "3ec71419b2538607a94a52d1acaf2cadadf14ad413ee4e097080a33b5ab4e3ae",
        "size": 56510,
        "modified": "2026-07-31 05:15:34.992803903 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
