{
        "file": "src/shared/contracts/product_nature.ts",
        "filename": "product_nature.ts",
        "hash": "899524d9ea2630c76c4da1b8552d31c2580ff1cdafe5a8f32d9cd089fd1af520",
        "size": 1383,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
