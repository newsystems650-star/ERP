{
        "file": "src/core/event-store/eventBus.ts",
        "filename": "eventBus.ts",
        "hash": "9af6fe0c4f9594e4c9269d3ad5134bb67d8112d3af421e6ec518fbc3950f4e36",
        "size": 720,
        "modified": "2026-08-01 05:52:34.881196371 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
