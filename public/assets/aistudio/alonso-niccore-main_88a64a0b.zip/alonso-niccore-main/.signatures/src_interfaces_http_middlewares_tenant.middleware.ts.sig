{
        "file": "src/interfaces/http/middlewares/tenant.middleware.ts",
        "filename": "tenant.middleware.ts",
        "hash": "ce1257a387b85b7affdec2178a74bc220be13b2e4884442a1ab45661e00fd2c5",
        "size": 373,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
