{
        "file": "client/src/modules/auth/auth.controller.ts",
        "filename": "auth.controller.ts",
        "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "size": 0,
        "modified": "2026-08-01 06:40:29.527787027 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
