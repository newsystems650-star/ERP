{
        "file": "src/core/supervisor/engine.supervisor.ts",
        "filename": "engine.supervisor.ts",
        "hash": "d9810f47f3e55b7572e91d604363b130b4803afa40993d9c967dc5cd715e8f99",
        "size": 1968,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
