{
        "file": "docker/sentinel.Dockerfile",
        "filename": "sentinel.Dockerfile",
        "hash": "42f5c163aa1448efe0f1928bb42e9ef6f95c0f9b73952930eabd265f23682bc5",
        "size": 346,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
