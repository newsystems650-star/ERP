{
        "file": "client/src/main.tsx",
        "filename": "main.tsx",
        "hash": "c395be8842fb209f321deba0a584a80553a8be3b75ca2124e2584b431b22b201",
        "size": 742,
        "modified": "2026-08-01 06:02:41.244639713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
