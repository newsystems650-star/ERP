{
        "file": "src/modules/quotations/routes/quotationRoutes.ts",
        "filename": "quotationRoutes.ts",
        "hash": "1bbbc76663d30e4036a244c5954b2cef817397066fde7dc2c35a136f2af3c926",
        "size": 1536,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
