{
        "file": "src/modules/woodentries/routes/woodEntryRoutes.ts",
        "filename": "woodEntryRoutes.ts",
        "hash": "a1e57ab80331710aa55569f8e73c6de91798c4735a47ec41e73e60d876398f47",
        "size": 1232,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
