{
        "file": "src/core/auth.service.ts",
        "filename": "auth.service.ts",
        "hash": "8a51b3466cc501b97a6f0095f5ff2470f1c5024acbc94ff7a41ecfc94527d46e",
        "size": 1143,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
