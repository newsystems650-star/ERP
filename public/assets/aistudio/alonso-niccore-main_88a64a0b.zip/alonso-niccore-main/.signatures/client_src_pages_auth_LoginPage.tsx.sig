{
        "file": "client/src/pages/auth/LoginPage.tsx",
        "filename": "LoginPage.tsx",
        "hash": "0583679da992067029aceb57cb4b24a0b6c96c64a0baa688953f0e80dc0cdc67",
        "size": 2184,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
