{
        "file": "src/modules/tickets/tickets.routes.ts",
        "filename": "tickets.routes.ts",
        "hash": "e2a3aa76e4f198b946a9c6de7c2364e7f1a2003b8e8cd5aa86a3530ac121d1a3",
        "size": 211,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
