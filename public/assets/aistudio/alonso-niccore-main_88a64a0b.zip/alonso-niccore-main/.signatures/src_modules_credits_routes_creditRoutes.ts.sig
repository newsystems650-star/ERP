{
        "file": "src/modules/credits/routes/creditRoutes.ts",
        "filename": "creditRoutes.ts",
        "hash": "fc31d590c01bce59f8ab4cb49a0ecdfe09ef19b7d100088097a019dc7375bfba",
        "size": 1499,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
