{
        "file": "prisma/schema.prisma",
        "filename": "schema.prisma",
        "hash": "38759daf5a6cb29447536f933d6ba7180def7cdef056d5422d1afff8c516a552",
        "size": 14422,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
