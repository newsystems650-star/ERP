{
        "file": "src/modules/wood-inventory/wood.projection.ts",
        "filename": "wood.projection.ts",
        "hash": "df18b84b385f4203bf8e2153c41fcdd9cf20a0d17410e40d6fe75e0a86921ad3",
        "size": 805,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
