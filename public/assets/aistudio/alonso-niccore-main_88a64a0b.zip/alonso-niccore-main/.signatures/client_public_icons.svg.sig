{
        "file": "client/public/icons.svg",
        "filename": "icons.svg",
        "hash": "b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a",
        "size": 5031,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
