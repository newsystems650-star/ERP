{
        "file": "src/infrastructure/guardian/businessGuard.ts",
        "filename": "businessGuard.ts",
        "hash": "334d77c5af469e313558927caa82d9598d5b9b0c7df51da26a87874ad480b0dd",
        "size": 4512,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
