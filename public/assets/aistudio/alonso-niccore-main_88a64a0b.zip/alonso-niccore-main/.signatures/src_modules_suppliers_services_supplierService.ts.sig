{
        "file": "src/modules/suppliers/services/supplierService.ts",
        "filename": "supplierService.ts",
        "hash": "cb6d8832f78f17f6bde23775e8e2e839273ed7755d29a8f3b75e1f58b0c75abe",
        "size": 778,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
