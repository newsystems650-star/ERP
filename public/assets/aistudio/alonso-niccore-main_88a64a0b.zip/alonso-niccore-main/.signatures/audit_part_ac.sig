{
        "file": "audit_part_ac",
        "filename": "audit_part_ac",
        "hash": "eb1d971b9fb7351cdc0da19d9cebdd2a4329c71204620a76cac76e81202bd2bf",
        "size": 13330,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
