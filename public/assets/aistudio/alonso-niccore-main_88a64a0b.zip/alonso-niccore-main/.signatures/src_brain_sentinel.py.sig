{
        "file": "src/brain/sentinel.py",
        "filename": "sentinel.py",
        "hash": "0bff38b9c8932062814b03a97aee44cfbe587aa5a152ac3429772d9e5a5c4ab9",
        "size": 3209,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
