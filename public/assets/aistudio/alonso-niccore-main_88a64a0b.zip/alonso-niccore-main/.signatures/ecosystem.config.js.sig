{
        "file": "ecosystem.config.js",
        "filename": "ecosystem.config.js",
        "hash": "2909b4baacec50f7972907d145b5ec9e6bfaa1c522adcba77511aded06e396f5",
        "size": 822,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
