{
        "file": "src/modules/invoices/routes/invoiceRoutes.ts",
        "filename": "invoiceRoutes.ts",
        "hash": "c89a288fa44b05b0bb38ef978dba3cc3b6e2d1385af29b338073c41b75a6dd34",
        "size": 2411,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
