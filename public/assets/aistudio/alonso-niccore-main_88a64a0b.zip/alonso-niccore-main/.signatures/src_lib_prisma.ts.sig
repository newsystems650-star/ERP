{
        "file": "src/lib/prisma.ts",
        "filename": "prisma.ts",
        "hash": "de47c8af050a143c6948d7684f05a52f5396026ca8b4277f221780dd186da227",
        "size": 281,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
