{
        "file": "docker/api.Dockerfile",
        "filename": "api.Dockerfile",
        "hash": "48642b9ed164e049a37736e3e69b9e2a797c3edc9b4bc96761cbd2682bb09ddf",
        "size": 232,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
