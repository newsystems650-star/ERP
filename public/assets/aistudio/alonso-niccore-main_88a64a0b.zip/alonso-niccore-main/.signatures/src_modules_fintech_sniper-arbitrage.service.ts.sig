{
        "file": "src/modules/fintech/sniper-arbitrage.service.ts",
        "filename": "sniper-arbitrage.service.ts",
        "hash": "ed4c77a3cacc19873c9ce8c23b438935e2e1ed3866cdce55f6d3ae2f7907325a",
        "size": 1191,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
