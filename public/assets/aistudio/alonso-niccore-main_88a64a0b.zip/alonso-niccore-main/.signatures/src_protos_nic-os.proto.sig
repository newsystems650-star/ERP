{
        "file": "src/protos/nic-os.proto",
        "filename": "nic-os.proto",
        "hash": "99f97c7795b44401f529b4de9fba2b4937cb0a316db7e15d2c84e90393d80187",
        "size": 663,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
