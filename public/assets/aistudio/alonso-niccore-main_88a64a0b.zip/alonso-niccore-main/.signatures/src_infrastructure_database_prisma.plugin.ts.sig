{
        "file": "src/infrastructure/database/prisma.plugin.ts",
        "filename": "prisma.plugin.ts",
        "hash": "0c362c7ced6b4686d8f49f94c9203ce9ddcef2f1eb2eb488f392b6a72bd511ae",
        "size": 395,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
