{
        "file": "src/shared/errors/AppError.ts",
        "filename": "AppError.ts",
        "hash": "118ea91fecacc35ede1071d2d560ce0b31340f29b6c17689094e27d9284269fc",
        "size": 1083,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
