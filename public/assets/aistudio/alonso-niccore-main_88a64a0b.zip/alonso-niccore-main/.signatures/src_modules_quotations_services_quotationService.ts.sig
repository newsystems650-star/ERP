{
        "file": "src/modules/quotations/services/quotationService.ts",
        "filename": "quotationService.ts",
        "hash": "a2455b32a59aa265563e4f58ea8643f76028fd8bf58528b65c4ebece5e1567c5",
        "size": 4895,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
