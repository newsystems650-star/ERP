{
        "file": "src/modules/woodentries/services/woodEntryService.ts",
        "filename": "woodEntryService.ts",
        "hash": "dc18ac73c4cbb9edba978b89200bbdd12bb4624cc64433b6c9f28d7c6313fa1d",
        "size": 8396,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
