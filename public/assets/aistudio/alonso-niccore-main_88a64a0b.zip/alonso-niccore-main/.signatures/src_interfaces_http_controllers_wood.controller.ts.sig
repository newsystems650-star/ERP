{
        "file": "src/interfaces/http/controllers/wood.controller.ts",
        "filename": "wood.controller.ts",
        "hash": "78e2e75086e5a1d166e182f49807277a56249b319b6b0d837534a6fe23b1cf00",
        "size": 421,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
