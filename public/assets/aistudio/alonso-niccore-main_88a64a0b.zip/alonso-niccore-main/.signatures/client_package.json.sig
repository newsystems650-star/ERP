{
        "file": "client/package.json",
        "filename": "package.json",
        "hash": "d7cf260fdfcf989229cbcc24a86546f3b88525d9afa7803352e511489db97ac5",
        "size": 324,
        "modified": "2026-08-01 05:54:44.659575334 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
