{
        "file": "src/modules/woodentries/services/equivalenceTable.ts",
        "filename": "equivalenceTable.ts",
        "hash": "848d6c8af39e0f1396efbb95274405fcfa5b7f4d946936c24bfe2b1dd4eb848a",
        "size": 2191,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
