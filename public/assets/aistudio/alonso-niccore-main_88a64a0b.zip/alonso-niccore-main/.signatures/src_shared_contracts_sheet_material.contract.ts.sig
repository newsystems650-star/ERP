{
        "file": "src/shared/contracts/sheet_material.contract.ts",
        "filename": "sheet_material.contract.ts",
        "hash": "195d44051d8d349a3f66717f408f95f39bc14e746bf68ae8cadb67685c6c5c04",
        "size": 471,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
