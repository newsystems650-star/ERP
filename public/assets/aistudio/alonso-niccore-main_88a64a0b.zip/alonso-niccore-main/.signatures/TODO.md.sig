{
        "file": "TODO.md",
        "filename": "TODO.md",
        "hash": "4c84cd85c5e33b4414807322627a60d93af332f6dbbbe2c560e41d2dfacee16e",
        "size": 1259,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
