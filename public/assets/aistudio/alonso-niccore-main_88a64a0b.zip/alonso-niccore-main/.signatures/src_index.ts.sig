{
        "file": "src/index.ts",
        "filename": "index.ts",
        "hash": "d3ea87b9b41243cadd27d9af4b108aa277d5b3bbca13eea2f2e8248dd767e9df",
        "size": 785,
        "modified": "2026-08-01 05:54:30.562425532 +0000",
        "signature_date": "2026-08-01T07:33:40+00:00"
    }
