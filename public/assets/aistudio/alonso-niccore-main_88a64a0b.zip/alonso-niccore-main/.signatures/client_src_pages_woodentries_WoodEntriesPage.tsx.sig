{
        "file": "client/src/pages/woodentries/WoodEntriesPage.tsx",
        "filename": "WoodEntriesPage.tsx",
        "hash": "9cd7a71be48615336cad4814ea064c6ff6dcc168c16c5e35d39cefd228517a9d",
        "size": 15622,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
