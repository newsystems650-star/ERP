{
        "file": "veredicto.md",
        "filename": "veredicto.md",
        "hash": "f9342c94a029a32256d27180284e646c8b695065f0268b4cafa8496cdfd484c5",
        "size": 5052,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
