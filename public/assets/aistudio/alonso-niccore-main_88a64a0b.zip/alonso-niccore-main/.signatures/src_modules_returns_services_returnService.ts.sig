{
        "file": "src/modules/returns/services/returnService.ts",
        "filename": "returnService.ts",
        "hash": "5b39a16e5e91faaecea1424230c3c4380484943e80233063e2295b736368ae91",
        "size": 4131,
        "modified": "2026-07-31 05:15:35.004805046 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
