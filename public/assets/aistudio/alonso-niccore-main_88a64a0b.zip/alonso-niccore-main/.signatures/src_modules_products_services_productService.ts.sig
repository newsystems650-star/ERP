{
        "file": "src/modules/products/services/productService.ts",
        "filename": "productService.ts",
        "hash": "c48eaf05750c2039ab56df2f4e188ccb16e7d5e1356619723cd6390d801dad22",
        "size": 2538,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
