{
        "file": "client/src/pages/RutasHistoricas.tsx",
        "filename": "RutasHistoricas.tsx",
        "hash": "75eeea3a4f7a1ae1559b3ea17fd9d6aab3c693c4cf70da10cc2b69ea9fa2e6d0",
        "size": 7801,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
