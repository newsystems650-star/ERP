{
        "file": "src/prueba_cerebro.ts",
        "filename": "prueba_cerebro.ts",
        "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "size": 0,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
