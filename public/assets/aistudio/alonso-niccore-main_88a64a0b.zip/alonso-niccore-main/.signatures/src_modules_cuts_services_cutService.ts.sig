{
        "file": "src/modules/cuts/services/cutService.ts",
        "filename": "cutService.ts",
        "hash": "7e48b6efd8e983d1103081279d2e41e80fa304a7a9faf663b228f0df7fed52c8",
        "size": 6530,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
