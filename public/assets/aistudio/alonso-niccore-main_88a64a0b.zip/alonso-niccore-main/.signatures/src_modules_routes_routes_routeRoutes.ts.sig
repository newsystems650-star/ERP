{
        "file": "src/modules/routes/routes/routeRoutes.ts",
        "filename": "routeRoutes.ts",
        "hash": "ef3530143670e2c559b86bf3f0d5716ac6dff404aa68318c2dde204b2938b423",
        "size": 562,
        "modified": "2026-07-31 05:15:35.004805046 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
