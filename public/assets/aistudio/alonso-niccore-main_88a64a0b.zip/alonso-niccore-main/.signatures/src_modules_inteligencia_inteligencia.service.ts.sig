{
        "file": "src/modules/inteligencia/inteligencia.service.ts",
        "filename": "inteligencia.service.ts",
        "hash": "ecb2810da06d039ed18a640d215f29b39c053c2bab066bf7237547b82d7351e5",
        "size": 3255,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
