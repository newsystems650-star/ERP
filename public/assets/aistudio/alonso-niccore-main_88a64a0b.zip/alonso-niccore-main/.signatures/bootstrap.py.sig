{
        "file": "bootstrap.py",
        "filename": "bootstrap.py",
        "hash": "561fd38922d50bdcd07b466357832ac6f6913eb9ef7ddf564531e477d8ac1f8e",
        "size": 13659,
        "modified": "2026-08-01 07:33:19.430483100 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
