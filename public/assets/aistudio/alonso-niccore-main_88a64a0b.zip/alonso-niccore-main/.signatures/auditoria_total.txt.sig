{
        "file": "auditoria_total.txt",
        "filename": "auditoria_total.txt",
        "hash": "a6900ebf9297b6c08192742732f0b053b4aa5577116326f4f089eb77c54d094d",
        "size": 118573,
        "modified": "2026-07-31 05:15:34.984803141 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
