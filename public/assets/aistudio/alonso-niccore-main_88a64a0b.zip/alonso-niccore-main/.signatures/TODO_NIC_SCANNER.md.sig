{
        "file": "TODO_NIC_SCANNER.md",
        "filename": "TODO_NIC_SCANNER.md",
        "hash": "19d34e3ebdd2025007a695fdcb0cb8df5975baef484a38d78eaa6ec3e7f78277",
        "size": 983,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
