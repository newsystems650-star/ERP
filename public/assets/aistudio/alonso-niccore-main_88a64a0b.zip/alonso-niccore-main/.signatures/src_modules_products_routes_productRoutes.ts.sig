{
        "file": "src/modules/products/routes/productRoutes.ts",
        "filename": "productRoutes.ts",
        "hash": "058fb1f03abba5d7b2277d8fe9c2797c1f697399f708b7288fd012b8ecfeec40",
        "size": 1366,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
