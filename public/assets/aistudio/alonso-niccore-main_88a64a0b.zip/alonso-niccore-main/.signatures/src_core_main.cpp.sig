{
        "file": "src/core/main.cpp",
        "filename": "main.cpp",
        "hash": "babd390a044f9c7210a6028dc75d269ee7e541d57ed15cec6d46dc22433d3ca2",
        "size": 2260,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
