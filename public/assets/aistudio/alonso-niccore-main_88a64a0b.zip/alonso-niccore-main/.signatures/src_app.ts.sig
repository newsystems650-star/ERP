{
        "file": "src/app.ts",
        "filename": "app.ts",
        "hash": "a1d81485a0990052193222069a65521815d3c5d4d7c9e047d12e9f209cdcb4a3",
        "size": 566,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
