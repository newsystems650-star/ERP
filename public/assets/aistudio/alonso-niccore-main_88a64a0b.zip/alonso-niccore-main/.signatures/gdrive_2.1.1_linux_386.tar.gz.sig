{
        "file": "gdrive_2.1.1_linux_386.tar.gz",
        "filename": "gdrive_2.1.1_linux_386.tar.gz",
        "hash": "de770d91e528a36d816d5617dd9593922e2c2b154a175fd1e89f196ea0381191",
        "size": 3826659,
        "modified": "2021-12-08 06:32:13.000000000 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
