{
        "file": "src/modules/products/validators/productValidator.ts",
        "filename": "productValidator.ts",
        "hash": "46aeaeb12ebc53fc74ef043d7b11725e7d48ce7dc991a7c17472a86c7d96c5c1",
        "size": 640,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
