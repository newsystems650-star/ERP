{
        "file": "client/index.html",
        "filename": "index.html",
        "hash": "95b3821bfa39fcd588550f18058ac7af833d50a1433a1cbcd4de6d222ba2dbea",
        "size": 285,
        "modified": "2026-08-01 06:02:41.232639586 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
