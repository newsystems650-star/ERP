{
        "file": "prisma/migrations/20260405064530_add_deliveries/migration.sql",
        "filename": "migration.sql",
        "hash": "e22703851164d729371786da6e8663b7faa0b1058fe769c4f05c437996c7e334",
        "size": 1205,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
