{
        "file": "client/src/components/ui/Card.tsx",
        "filename": "Card.tsx",
        "hash": "ec6aeb5a58408af0b3289a81c993a08a1d394426f4fb01c490fa36f98c4f100c",
        "size": 1132,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
