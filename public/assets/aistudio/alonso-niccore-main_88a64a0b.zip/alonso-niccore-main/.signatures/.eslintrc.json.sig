{
        "file": ".eslintrc.json",
        "filename": ".eslintrc.json",
        "hash": "e90b6d691e82ace915eadf01c0f98a3d79d4250517f24c61499d5f8cbe2de49c",
        "size": 127,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
