{
        "file": "package.json",
        "filename": "package.json",
        "hash": "9349a8adaf922a803a51c6ac0eb3668e8fbfb6e8da650546e3f78002e5303ffa",
        "size": 2912,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
