{
        "file": "fix-user.ts",
        "filename": "fix-user.ts",
        "hash": "64401b822a3ce5be0d61e6d7ac8eac571f25182f5797aed4841e4c1051bf478c",
        "size": 524,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
