{
        "file": "src/brain/requirements.txt",
        "filename": "requirements.txt",
        "hash": "0c6b38155777a3e442052c6b81de9c3bbb2d349e5881b361cddd8b750faaa396",
        "size": 35,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
