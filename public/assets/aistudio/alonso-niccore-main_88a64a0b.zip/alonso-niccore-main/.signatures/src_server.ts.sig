{
        "file": "src/server.ts",
        "filename": "server.ts",
        "hash": "fdd12fa10810740620311bf3623e73ece71b2f5165c204400b28e59964ddf110",
        "size": 821,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
