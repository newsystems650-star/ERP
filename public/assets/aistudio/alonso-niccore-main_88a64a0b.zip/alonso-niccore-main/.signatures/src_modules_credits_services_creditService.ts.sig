{
        "file": "src/modules/credits/services/creditService.ts",
        "filename": "creditService.ts",
        "hash": "f91e66302de2a32c2f9230c0af2268aa86c986cab099adfab5bfb3c8c4524e35",
        "size": 3747,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
