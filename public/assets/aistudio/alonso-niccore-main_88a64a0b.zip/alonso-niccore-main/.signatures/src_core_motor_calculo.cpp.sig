{
        "file": "src/core/motor_calculo.cpp",
        "filename": "motor_calculo.cpp",
        "hash": "00c9c0f8c7a0b0e3369910aa5025c3b13f59786241948ae0e7d7614e3e52addf",
        "size": 2478,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
