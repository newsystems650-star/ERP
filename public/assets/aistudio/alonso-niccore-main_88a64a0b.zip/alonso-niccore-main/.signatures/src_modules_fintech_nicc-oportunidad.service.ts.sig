{
        "file": "src/modules/fintech/nicc-oportunidad.service.ts",
        "filename": "nicc-oportunidad.service.ts",
        "hash": "759e62c6c27d3394daf2fafee8bb1d6a35764075c3f5c81cf6dd16315e289373",
        "size": 1149,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
