{
        "file": "init.sh",
        "filename": "init.sh",
        "hash": "5027f04cd55ebadb78657edda7b4b1f50c7be8e0733eed71e4bcdab817ece5cc",
        "size": 469,
        "modified": "2026-07-31 05:15:34.992803903 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
