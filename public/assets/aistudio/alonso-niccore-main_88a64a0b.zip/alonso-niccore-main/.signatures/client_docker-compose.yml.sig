{
        "file": "client/docker-compose.yml",
        "filename": "docker-compose.yml",
        "hash": "dd53ebd4084cdc78a298fc27bcf9bb217324bedbf9db8a907dcd2ed5f12f51d6",
        "size": 247,
        "modified": "2026-08-01 06:41:12.658245419 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
