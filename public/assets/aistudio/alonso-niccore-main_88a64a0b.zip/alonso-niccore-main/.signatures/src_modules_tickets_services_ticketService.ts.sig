{
        "file": "src/modules/tickets/services/ticketService.ts",
        "filename": "ticketService.ts",
        "hash": "249c78171b85295e6f3366670ca541f7af3114e0716dba4e364938fc6ff0026f",
        "size": 913,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
