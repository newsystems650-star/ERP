{
        "file": "src/modules/dashboard/services/dashboardService.ts",
        "filename": "dashboardService.ts",
        "hash": "97be44a3512e292bc36cd2735d4d4686f7ab5ce5f1f0aa9bc5e54d49c956e50d",
        "size": 3335,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
