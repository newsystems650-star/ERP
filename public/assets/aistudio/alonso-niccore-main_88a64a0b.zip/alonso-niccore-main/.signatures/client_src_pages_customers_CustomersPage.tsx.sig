{
        "file": "client/src/pages/customers/CustomersPage.tsx",
        "filename": "CustomersPage.tsx",
        "hash": "a7a6486de97eb0a0d7bbf5d539304538276dad8eeb5ac0e97a716754cb01f5ed",
        "size": 11129,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
