{
        "file": "docker/engine.Dockerfile",
        "filename": "engine.Dockerfile",
        "hash": "db9e33bbe0248198474f03d0e01aa9fbd90c3427937a53dec2b39097999bebac",
        "size": 415,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
