{
        "file": "src/infrastructure/monitor/telegram.ts",
        "filename": "telegram.ts",
        "hash": "c9b1ae2fd0b0d1971402bba8bc4c3cb77f0ace2ba0a6df553066cb30256ba209",
        "size": 2109,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
