{
        "file": "prisma/migrations/20260403055607_add_customers_credits_payments/migration.sql",
        "filename": "migration.sql",
        "hash": "38c483bcb58499d77f417b9f922403ccf5a113ba4fc3ae5791e0ff49f8baf4ce",
        "size": 2715,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
