{
        "file": "bin/niccore_engine",
        "filename": "niccore_engine",
        "hash": "c888d5897e9ed4f6a62c679509f1daf0afa59f4cb45b7d04a8ebe49f9b77b3f3",
        "size": 18200,
        "modified": "2026-08-01 05:36:56.004220850 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
