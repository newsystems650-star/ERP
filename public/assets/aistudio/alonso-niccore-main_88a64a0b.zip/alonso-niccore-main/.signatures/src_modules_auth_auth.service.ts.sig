{
        "file": "src/modules/auth/auth.service.ts",
        "filename": "auth.service.ts",
        "hash": "7d4bea4b9d2d8ebf4bab10666321ae10732b7070c18f167b7fb0c63b36ca6f28",
        "size": 203,
        "modified": "2026-08-01 07:30:48.168875176 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
