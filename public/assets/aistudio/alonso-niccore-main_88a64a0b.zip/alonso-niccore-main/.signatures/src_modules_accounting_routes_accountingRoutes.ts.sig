{
        "file": "src/modules/accounting/routes/accountingRoutes.ts",
        "filename": "accountingRoutes.ts",
        "hash": "dcdb2183ff8559dc1678acd272abb06a7e87e430024f1f5b17351864c4b4203a",
        "size": 2814,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
