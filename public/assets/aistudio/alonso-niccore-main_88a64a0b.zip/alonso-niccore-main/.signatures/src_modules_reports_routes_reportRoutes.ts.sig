{
        "file": "src/modules/reports/routes/reportRoutes.ts",
        "filename": "reportRoutes.ts",
        "hash": "626428bd7baa8bba6b2cc5b4af99f76ee97b343c310a4e1b0f28cf5826b517bc",
        "size": 1420,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
