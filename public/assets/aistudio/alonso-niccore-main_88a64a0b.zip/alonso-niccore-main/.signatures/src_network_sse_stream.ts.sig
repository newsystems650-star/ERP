{
        "file": "src/network/sse_stream.ts",
        "filename": "sse_stream.ts",
        "hash": "06d3c996faaf6835d7ab8bc73dc41862f8d616f9612c864571720e12420bd039",
        "size": 608,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
