{
        "file": "client/src/components/layout/Layout.tsx",
        "filename": "Layout.tsx",
        "hash": "903e265ac1e4fc5160d1ca7cc4b684ac4164ace7301231332c7e637a467e7004",
        "size": 3177,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
