{
        "file": "client/niccore.html",
        "filename": "niccore.html",
        "hash": "f29f4d1d996ddef3f2b1ea458cab29c8b86e34af5a41b15940ac84169e66787e",
        "size": 536,
        "modified": "2026-08-01 06:32:32.973712359 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
