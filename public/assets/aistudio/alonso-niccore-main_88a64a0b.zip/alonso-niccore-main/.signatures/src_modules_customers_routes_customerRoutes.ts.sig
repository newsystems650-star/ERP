{
        "file": "src/modules/customers/routes/customerRoutes.ts",
        "filename": "customerRoutes.ts",
        "hash": "def8eaaf0aa51aa25603adb726dd627ef807540cd1f1b4de09d7ae66980f7600",
        "size": 1264,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
