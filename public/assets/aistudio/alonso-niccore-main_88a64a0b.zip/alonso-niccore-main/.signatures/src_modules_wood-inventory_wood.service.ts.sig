{
        "file": "src/modules/wood-inventory/wood.service.ts",
        "filename": "wood.service.ts",
        "hash": "18e65bfcebab728a25b002ad631c0736e4c29764b431ee9d8f0257838baacd65",
        "size": 1079,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
