{
        "file": "eslint.config.mjs",
        "filename": "eslint.config.mjs",
        "hash": "bcda2970738377aaec2829cf043ccf7c3680b33e62108ddfa2a9f03b32e3bbf9",
        "size": 533,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
