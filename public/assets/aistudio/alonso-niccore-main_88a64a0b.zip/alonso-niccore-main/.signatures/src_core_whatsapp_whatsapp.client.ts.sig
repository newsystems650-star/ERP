{
        "file": "src/core/whatsapp/whatsapp.client.ts",
        "filename": "whatsapp.client.ts",
        "hash": "0ab09dfe5ed49078200168e4212a154150c45d8e0eb2851a69577ea9f95bbbe6",
        "size": 2142,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
