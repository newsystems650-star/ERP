{
        "file": "src/modules/rutas/rutas.service.ts",
        "filename": "rutas.service.ts",
        "hash": "9a631ab4fa640120922cd0e32fe2da711e41981f49a96c372cb172ba6039fa2d",
        "size": 3472,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
