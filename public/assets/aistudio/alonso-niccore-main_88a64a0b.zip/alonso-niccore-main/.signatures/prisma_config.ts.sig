{
        "file": "prisma/config.ts",
        "filename": "config.ts",
        "hash": "b6b4fb945ab5fa10815df858410755fb17d0fd767141591aeccd062dfccaa824",
        "size": 135,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
