{
        "file": "src/core/nic_scanner.cpp",
        "filename": "nic_scanner.cpp",
        "hash": "d8ce131d9a812eb9502054edd99a3f83f34d227db3a492d0474f170768148257",
        "size": 224,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
