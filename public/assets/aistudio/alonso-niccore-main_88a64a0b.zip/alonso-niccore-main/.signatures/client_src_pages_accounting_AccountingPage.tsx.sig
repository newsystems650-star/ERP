{
        "file": "client/src/pages/accounting/AccountingPage.tsx",
        "filename": "AccountingPage.tsx",
        "hash": "3f136d7712dd5ccfcde7fadcf959f9aa185b01f9530a3d262334b4650773cfd5",
        "size": 12897,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
