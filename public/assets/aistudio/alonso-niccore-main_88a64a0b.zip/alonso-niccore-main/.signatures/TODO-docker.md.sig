{
        "file": "TODO-docker.md",
        "filename": "TODO-docker.md",
        "hash": "7d3152da66dbd63bbbba8ce5c689f110d100ab85c5baf818da6c3ede8b4e59be",
        "size": 541,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
