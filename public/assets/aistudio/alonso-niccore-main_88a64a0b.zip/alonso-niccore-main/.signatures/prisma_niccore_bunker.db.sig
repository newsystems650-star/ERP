{
        "file": "prisma/niccore_bunker.db",
        "filename": "niccore_bunker.db",
        "hash": "c9f71fee15de36a1f70397d71b3e9417fe1a41cab94899dcf2cdb612c52666d1",
        "size": 24576,
        "modified": "2026-08-01 05:36:15.084786120 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
