{
        "file": "tsconfig.json",
        "filename": "tsconfig.json",
        "hash": "eda45584b28ed1e5185bf97d378d560d39aac6d7eb0b78243adbf6c72afdd08a",
        "size": 435,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
