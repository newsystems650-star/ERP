{
        "file": "<parameter name="absolute_path">TODO.md</parameter>",
        "filename": "parameter>",
        "hash": "b7cff66ba016bd7aa145b39bebdefd349beaaacd8a7a9b9a90d8c1b55acb773c",
        "size": 822,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
