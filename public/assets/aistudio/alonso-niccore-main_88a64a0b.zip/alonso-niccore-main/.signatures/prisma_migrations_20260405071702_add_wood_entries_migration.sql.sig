{
        "file": "prisma/migrations/20260405071702_add_wood_entries/migration.sql",
        "filename": "migration.sql",
        "hash": "8384efcb47421ef2160e5f0adb19f498a52a78c969b79ada0badf51edbdf696d",
        "size": 2499,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
