{
        "file": "src/modules/reports/services/reportService.ts",
        "filename": "reportService.ts",
        "hash": "2d3459d7e7804ea1b9bd2b21bd1f4cd4cea5cbe53eb7aafb80e4ecca1eca24bc",
        "size": 6085,
        "modified": "2026-07-31 05:15:35.004805046 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
