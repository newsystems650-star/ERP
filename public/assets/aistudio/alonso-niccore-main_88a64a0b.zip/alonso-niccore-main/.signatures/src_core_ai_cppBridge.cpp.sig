{
        "file": "src/core/ai/cppBridge.cpp",
        "filename": "cppBridge.cpp",
        "hash": "6d161421e8c4de0c85fc61c17b98da522ea7ff37210f497d4838efa1c3bbda55",
        "size": 1270,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
