{
        "file": "nic_companies/constitution.md",
        "filename": "constitution.md",
        "hash": "43aa4eee4da8aafe85ca0fe89980412633a1570dad3c7ac769099249f10016f8",
        "size": 312,
        "modified": "2026-08-01 07:26:58.664435511 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
