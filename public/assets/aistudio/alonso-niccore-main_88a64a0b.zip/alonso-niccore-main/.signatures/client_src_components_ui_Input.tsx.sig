{
        "file": "client/src/components/ui/Input.tsx",
        "filename": "Input.tsx",
        "hash": "2d4814973ad447cd8e6cf638a49f9cbe96f94734a30c5bb06f723c0549b41d5a",
        "size": 1358,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
