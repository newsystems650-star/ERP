{
        "file": "src/modules/tickets/tickets.service.ts",
        "filename": "tickets.service.ts",
        "hash": "579286042d45e8a91e90ce78873145ca8daa875805c2a2c6ea5c77ff7dd904b2",
        "size": 346,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
