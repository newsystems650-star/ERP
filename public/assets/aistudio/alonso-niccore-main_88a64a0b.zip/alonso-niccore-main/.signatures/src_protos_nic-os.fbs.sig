{
        "file": "src/protos/nic-os.fbs",
        "filename": "nic-os.fbs",
        "hash": "09e9efed610644598f723af21b6db764f597b6eacb5298cac4a24354197269ce",
        "size": 446,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
