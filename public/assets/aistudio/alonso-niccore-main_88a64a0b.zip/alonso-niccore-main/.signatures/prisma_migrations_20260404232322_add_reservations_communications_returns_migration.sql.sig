{
        "file": "prisma/migrations/20260404232322_add_reservations_communications_returns/migration.sql",
        "filename": "migration.sql",
        "hash": "2f506e2667d8e63f69e59b047fc05be1a48661a65aadfa903006f3067e5f3dad",
        "size": 3754,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
