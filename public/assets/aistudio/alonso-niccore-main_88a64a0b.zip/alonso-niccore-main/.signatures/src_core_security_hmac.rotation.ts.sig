{
        "file": "src/core/security/hmac.rotation.ts",
        "filename": "hmac.rotation.ts",
        "hash": "a3e070cbcc273c264201d4b18888b25a36d291ca0113f9b635d73379859f7da8",
        "size": 1933,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
