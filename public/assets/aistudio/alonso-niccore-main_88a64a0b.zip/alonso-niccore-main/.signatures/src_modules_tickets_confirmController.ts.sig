{
        "file": "src/modules/tickets/confirmController.ts",
        "filename": "confirmController.ts",
        "hash": "d67c6fadc2adb83ccaffbadc711d57205744836a091e6ee9d3197d4756ac7f7d",
        "size": 996,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
