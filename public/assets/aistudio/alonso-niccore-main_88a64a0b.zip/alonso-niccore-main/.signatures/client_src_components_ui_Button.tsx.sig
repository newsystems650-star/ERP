{
        "file": "client/src/components/ui/Button.tsx",
        "filename": "Button.tsx",
        "hash": "8df787de982b40f0cb1eb4ca54f6e02634bb266037e00120fe10a7a138aef9ff",
        "size": 1139,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
