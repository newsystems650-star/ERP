{
        "file": "src/modules/invoices/services/invoiceService.ts",
        "filename": "invoiceService.ts",
        "hash": "18c7c17f9071f73642a3b75794b9b5a90117a9d7f8888aa33a689d0cc348f35c",
        "size": 7340,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
