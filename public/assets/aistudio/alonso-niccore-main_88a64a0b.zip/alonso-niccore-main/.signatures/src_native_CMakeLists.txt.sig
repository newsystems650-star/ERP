{
        "file": "src/native/CMakeLists.txt",
        "filename": "CMakeLists.txt",
        "hash": "2a7777f9c8840269f13e5825937270f69b82309c65c7040ffcc1a485795eb18c",
        "size": 350,
        "modified": "2026-08-01 05:34:38.745762887 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
