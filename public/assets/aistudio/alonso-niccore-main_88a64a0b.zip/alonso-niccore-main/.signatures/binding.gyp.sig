{
        "file": "binding.gyp",
        "filename": "binding.gyp",
        "hash": "3e19a2ec4a797e839e31fc47d7b8801774b71813c855ac64d09977fc92941efb",
        "size": 411,
        "modified": "2026-07-31 05:15:34.984803141 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
