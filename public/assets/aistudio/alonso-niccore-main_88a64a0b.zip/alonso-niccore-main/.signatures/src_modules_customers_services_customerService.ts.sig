{
        "file": "src/modules/customers/services/customerService.ts",
        "filename": "customerService.ts",
        "hash": "53040e335a8d1f0e8525d25593b06e0f0dff2016a237434f0a5c098277a2e688",
        "size": 1991,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
