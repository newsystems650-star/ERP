{
        "file": "client/src/pages/Dashboard/index.tsx",
        "filename": "index.tsx",
        "hash": "19ca47ffe859b4949619763b2718bb15a1bbd154610182b277e64e8747cc6d6e",
        "size": 63,
        "modified": "2026-08-01 07:31:02.727029930 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
