{
        "file": "stress_test.ts",
        "filename": "stress_test.ts",
        "hash": "bbe31ea3c7323fff228800a0742a4fa5ee95485d5a5e47baa62b0acc2e1e6698",
        "size": 2111,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
