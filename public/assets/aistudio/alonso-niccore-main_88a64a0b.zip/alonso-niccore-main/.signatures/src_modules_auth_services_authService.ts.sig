{
        "file": "src/modules/auth/services/authService.ts",
        "filename": "authService.ts",
        "hash": "a8fd33ce23cc42a6aa76cb24b79096c9ee56c36896718e7eb776170409ee7d77",
        "size": 1632,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
