{
        "file": "prisma/migrations/20260403104705_add_accounting_cuts/migration.sql",
        "filename": "migration.sql",
        "hash": "70eb24f381d440804f1718f0fbecc201128c9e7f933167e0d523573b17824f5c",
        "size": 3886,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
