{
        "file": ".env",
        "filename": ".env",
        "hash": "87590ac3de546ed0a4a320ede4056c9bce0725b73b273e59fb7358f5ed25c82e",
        "size": 188,
        "modified": "2026-08-01 05:30:42.222250727 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
