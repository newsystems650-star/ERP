{
        "file": "client/src/App.tsx",
        "filename": "App.tsx",
        "hash": "d764eb17cf18fc3553030c474f4959ff29f5b0c13a0a29fef20885540ebc5a89",
        "size": 728,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
