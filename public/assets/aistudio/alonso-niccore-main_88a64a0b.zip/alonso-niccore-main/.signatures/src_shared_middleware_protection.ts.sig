{
        "file": "src/shared/middleware/protection.ts",
        "filename": "protection.ts",
        "hash": "aa71f4c7149fc0eea57d8ab7dbfcd575b53eb4e0fb02641afdf442d44d466cda",
        "size": 1923,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
