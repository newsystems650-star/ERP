{
        "file": "README.md",
        "filename": "README.md",
        "hash": "21aa183f1019c41bd224e4e43578c584fb0e0a6affaa3cb8a601c240abce8e7f",
        "size": 27,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
