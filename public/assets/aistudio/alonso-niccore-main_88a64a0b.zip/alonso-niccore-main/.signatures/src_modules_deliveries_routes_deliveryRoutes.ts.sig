{
        "file": "src/modules/deliveries/routes/deliveryRoutes.ts",
        "filename": "deliveryRoutes.ts",
        "hash": "867b755f4d5770a5e5fc78f602e7c3494044c424fb4387cac187db150b615343",
        "size": 2518,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
