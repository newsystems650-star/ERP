{
        "file": "src/shared/middleware/errorHandler.ts",
        "filename": "errorHandler.ts",
        "hash": "26f4f77ce4353adaba119b35513cbc4566521b9e147f70d1f4ede729c0b64601",
        "size": 716,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
