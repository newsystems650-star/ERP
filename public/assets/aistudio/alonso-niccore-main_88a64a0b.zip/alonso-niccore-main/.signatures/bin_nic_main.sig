{
        "file": "bin/nic_main",
        "filename": "nic_main",
        "hash": "b9b1500170fe31e44714c73bf424b41e38c8b6fafb91a5851324ed3488295bf6",
        "size": 17512,
        "modified": "2026-08-01 05:36:58.194244119 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
