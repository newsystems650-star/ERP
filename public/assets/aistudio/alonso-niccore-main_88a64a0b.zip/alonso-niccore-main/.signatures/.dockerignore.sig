{
        "file": ".dockerignore",
        "filename": ".dockerignore",
        "hash": "16efadbe54d63c7615f707e90cf8a38af8e4aab4d70564eab9ebfff75f27adea",
        "size": 72,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
