{
        "file": "client/src/pages/cuts/CutsPage.tsx",
        "filename": "CutsPage.tsx",
        "hash": "d149bd1ad54d1e38a483ce030f043f682ff4381e1777d87eeaa5d7ef3f0aeed1",
        "size": 20474,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
