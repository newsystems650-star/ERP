{
        "file": "src/core/purifier/online-contract.ts",
        "filename": "online-contract.ts",
        "hash": "ca032c926ffff06f930eb29fb775af971b458196523732badc540b7ba55c1f9a",
        "size": 305,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
