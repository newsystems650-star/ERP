{
        "file": "client/public/favicon.svg",
        "filename": "favicon.svg",
        "hash": "61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66",
        "size": 9522,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
