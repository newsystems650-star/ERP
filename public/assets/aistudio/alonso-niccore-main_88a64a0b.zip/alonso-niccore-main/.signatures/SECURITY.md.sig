{
        "file": "SECURITY.md",
        "filename": "SECURITY.md",
        "hash": "ba9643955bfcb04524a6fe5a8c2929b54abc2e67bb3480ce806e742d506e4dc9",
        "size": 619,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
