{
        "file": "client/tsconfig.json",
        "filename": "tsconfig.json",
        "hash": "770b4140bbb581e2dfd9ea9946ffc9c75a1d86ba7d2db5f77c83e37cbdf9d808",
        "size": 119,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
