{
        "file": "src/modules/inteligencia/inteligencia.router.ts",
        "filename": "inteligencia.router.ts",
        "hash": "5112a37ed54b503dec58bb43db81575a4ea19437d7da726e829704ac991f7b0d",
        "size": 1182,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
