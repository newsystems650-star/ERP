{
        "file": "temporal",
        "filename": "temporal",
        "hash": "a4400a97c2418680d7a1a1258d5c9887e30b0d9d7d75bf08ab5db877d735dc69",
        "size": 145,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
