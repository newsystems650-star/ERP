{
        "file": "src/modules/users/services/userService.ts",
        "filename": "userService.ts",
        "hash": "86fcc5619a49fb6aafca58aa22eefb1b4217a70cb83a698b5517f050511a7873",
        "size": 2075,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
