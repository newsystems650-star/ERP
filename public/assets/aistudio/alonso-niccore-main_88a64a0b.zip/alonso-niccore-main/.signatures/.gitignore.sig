{
        "file": ".gitignore",
        "filename": ".gitignore",
        "hash": "e7e9480ef39d784b93b46c77997ecd3470a20ccafa53f19f4b97cdecd294b281",
        "size": 527,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
