{
        "file": "client/src/store/authStore.ts",
        "filename": "authStore.ts",
        "hash": "2b2aeac592080c8292ca35286ce609d98ea041d7f6edcfb5014b32146af6b4e8",
        "size": 939,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
