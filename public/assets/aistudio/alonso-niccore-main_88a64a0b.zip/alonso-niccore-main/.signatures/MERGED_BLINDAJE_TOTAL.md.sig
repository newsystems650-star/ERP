{
        "file": "MERGED_BLINDAJE_TOTAL.md",
        "filename": "MERGED_BLINDAJE_TOTAL.md",
        "hash": "4dd8b945c749ee0dbba056b3b0ebc67bab9b84e54b0cb2a7719773adbb086543",
        "size": 1638,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
