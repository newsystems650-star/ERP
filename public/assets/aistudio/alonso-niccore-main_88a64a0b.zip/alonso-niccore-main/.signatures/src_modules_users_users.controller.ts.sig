{
        "file": "src/modules/users/users.controller.ts",
        "filename": "users.controller.ts",
        "hash": "206b34de56e7791a719fea99964383d67bbab98e16cc1811b74343d186b1665a",
        "size": 350,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
