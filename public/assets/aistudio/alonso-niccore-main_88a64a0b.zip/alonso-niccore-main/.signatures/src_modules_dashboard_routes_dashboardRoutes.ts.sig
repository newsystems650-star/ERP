{
        "file": "src/modules/dashboard/routes/dashboardRoutes.ts",
        "filename": "dashboardRoutes.ts",
        "hash": "d4a71d6091b5a8e126ed8da81ce6d3175a2b250dee866c3f46cb09514a5c4333",
        "size": 369,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
