{
        "file": "src/services/wood_calculator.service.ts",
        "filename": "wood_calculator.service.ts",
        "hash": "c073677d03f024cbe351b3cad58cc1ba40651f52b946560093d27432359f732f",
        "size": 1331,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
