{
        "file": "client/src/components/layout/RoleGuard.tsx",
        "filename": "RoleGuard.tsx",
        "hash": "028a13a5b164b7db9f2362249416206b6bb276fc75fcc530f90452e65145805f",
        "size": 991,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
