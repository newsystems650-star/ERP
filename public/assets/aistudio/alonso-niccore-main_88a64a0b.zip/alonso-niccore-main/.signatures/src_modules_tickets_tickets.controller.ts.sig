{
        "file": "src/modules/tickets/tickets.controller.ts",
        "filename": "tickets.controller.ts",
        "hash": "b96b9435f02ad072a2fa25c940c537902f13f43aa3ddf45f5ccb411fcd1cddac",
        "size": 356,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
