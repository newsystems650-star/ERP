{
        "file": "src/core/tenant/tenantContext.ts",
        "filename": "tenantContext.ts",
        "hash": "0fd89159fba4e337c826e57dcebdb6c64bead8dd2cf0d196a7d3ebbdb9993519",
        "size": 358,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
