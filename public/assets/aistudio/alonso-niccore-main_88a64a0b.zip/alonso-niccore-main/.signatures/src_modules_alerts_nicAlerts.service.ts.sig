{
        "file": "src/modules/alerts/nicAlerts.service.ts",
        "filename": "nicAlerts.service.ts",
        "hash": "f571a0f24fb237548473c6e871f1e521752a16239bfe600fd5659f3d3a5a462e",
        "size": 2936,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
