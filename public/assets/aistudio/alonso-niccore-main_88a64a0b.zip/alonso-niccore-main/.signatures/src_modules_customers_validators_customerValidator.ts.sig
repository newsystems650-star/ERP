{
        "file": "src/modules/customers/validators/customerValidator.ts",
        "filename": "customerValidator.ts",
        "hash": "73febb99121a6e941bbe761b85cb683a3116e6cdcca5ad6b8c0a272fa1639ffb",
        "size": 409,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
