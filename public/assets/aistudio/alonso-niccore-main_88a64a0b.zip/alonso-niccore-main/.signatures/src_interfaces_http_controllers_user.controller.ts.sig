{
        "file": "src/interfaces/http/controllers/user.controller.ts",
        "filename": "user.controller.ts",
        "hash": "eb541be8cc2930d6ff8cb3f5798ba8b8f5132170c952499af408a5f800e10691",
        "size": 678,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
