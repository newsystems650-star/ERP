{
        "file": "audit_part_ae",
        "filename": "audit_part_ae",
        "hash": "13ce87d85fd13979cabcecbdd6ac351789a9a6e42f9e17a0ff49fe465a7da778",
        "size": 8610,
        "modified": "2026-07-31 05:15:34.984803141 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
