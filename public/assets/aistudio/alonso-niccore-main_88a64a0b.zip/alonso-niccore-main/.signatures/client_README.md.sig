{
        "file": "client/README.md",
        "filename": "README.md",
        "hash": "8dc9e0ee2281acb3324624fbe6eb7e1377cc626f616ea4dc90e3a90ae094374d",
        "size": 2425,
        "modified": "2026-07-31 05:15:34.986803331 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
