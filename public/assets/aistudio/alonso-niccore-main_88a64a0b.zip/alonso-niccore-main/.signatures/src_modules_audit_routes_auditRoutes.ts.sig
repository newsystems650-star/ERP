{
        "file": "src/modules/audit/routes/auditRoutes.ts",
        "filename": "auditRoutes.ts",
        "hash": "1e903fc57d80951daf30595d0188b9650f313a5363755eaeb93ac43bab8957e8",
        "size": 1335,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
