{
        "file": "audit_part_ab",
        "filename": "audit_part_ab",
        "hash": "723a54eede2f35bee0d3a41932a73a26024bc3943416d09b79c21a76d527009b",
        "size": 13226,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
