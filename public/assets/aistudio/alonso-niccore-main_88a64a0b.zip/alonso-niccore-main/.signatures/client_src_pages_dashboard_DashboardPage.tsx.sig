{
        "file": "client/src/pages/dashboard/DashboardPage.tsx",
        "filename": "DashboardPage.tsx",
        "hash": "0d1834b1b5f6788bc3872ac9a5c6b757204328258702d1859355883f7df4f105",
        "size": 5217,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
