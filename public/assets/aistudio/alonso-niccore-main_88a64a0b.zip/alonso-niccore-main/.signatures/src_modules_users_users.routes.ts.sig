{
        "file": "src/modules/users/users.routes.ts",
        "filename": "users.routes.ts",
        "hash": "01be7387f587956f0685f306eb0b0e4e1f8f6a664d0531ff4b0cb5e89c634b62",
        "size": 201,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
