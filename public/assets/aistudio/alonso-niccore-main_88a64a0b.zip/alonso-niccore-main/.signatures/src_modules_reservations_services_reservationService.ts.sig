{
        "file": "src/modules/reservations/services/reservationService.ts",
        "filename": "reservationService.ts",
        "hash": "a968a8072f961c8207e7a89709cdd83eda611daadf1d406c2ca57facc276cc9b",
        "size": 2674,
        "modified": "2026-07-31 05:15:35.004805046 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
