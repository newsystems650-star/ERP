{
        "file": "src/modules/communications/services/communicationService.ts",
        "filename": "communicationService.ts",
        "hash": "3d532dd05406d726f572c279fd919a07181c0535bd9b10e517fea1919536cc95",
        "size": 2768,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
