{
        "file": "src/native/wood_engine.cpp",
        "filename": "wood_engine.cpp",
        "hash": "11d568a6d00d43ead3f900e664fa1f6c51e502c1a9ca67c1fe504b68a0dafa4c",
        "size": 1084,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
