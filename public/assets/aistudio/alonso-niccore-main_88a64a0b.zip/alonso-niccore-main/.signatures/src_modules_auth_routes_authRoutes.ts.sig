{
        "file": "src/modules/auth/routes/authRoutes.ts",
        "filename": "authRoutes.ts",
        "hash": "8ae8f59b122c6e103f3bfa68b9b8c4168b28930bdf6ba92699fc1d41304231ee",
        "size": 994,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
