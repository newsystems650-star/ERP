{
        "file": "src/core/event-store/eventStore.ts",
        "filename": "eventStore.ts",
        "hash": "18e7ba2f799d26d53f3412b599dc422120b3f6417a33db049449567245c60568",
        "size": 982,
        "modified": "2026-08-01 05:56:46.637871520 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
