{
        "file": "src/core/ingestion/udp_receiver.ts",
        "filename": "udp_receiver.ts",
        "hash": "5ee340b4284c9806fb9f97ba392d490da1abaf71c8369b3e6b7738bc830e52f4",
        "size": 3618,
        "modified": "2026-07-31 05:15:34.995804189 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
