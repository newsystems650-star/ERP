{
        "file": "src/modules/alerts/alerts.scheduler.ts",
        "filename": "alerts.scheduler.ts",
        "hash": "397545b3d0136587393e7f49ea81e4d8fa582ac024a1cc09bbf9b2869cc05f83",
        "size": 993,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
