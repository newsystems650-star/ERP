{
        "file": "ignicion-total.ts",
        "filename": "ignicion-total.ts",
        "hash": "4c8b175ca56fa4a416ecd1dea9e9fd504230e55d8fb247fca0c7c9085d68beb4",
        "size": 1047,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
