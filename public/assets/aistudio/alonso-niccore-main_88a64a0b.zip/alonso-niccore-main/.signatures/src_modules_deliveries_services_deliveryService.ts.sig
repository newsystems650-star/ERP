{
        "file": "src/modules/deliveries/services/deliveryService.ts",
        "filename": "deliveryService.ts",
        "hash": "ecaac930913dca2ad12a027793221bcf59413d7aaa6423323488fe545f1dd1d9",
        "size": 6895,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
