{
        "file": "src/modules/tickets/routes/ticketRoutes.ts",
        "filename": "ticketRoutes.ts",
        "hash": "734bbe2debc0563f2c246acd2be6fd57df0a444b3b894a90b64f0ff401482e96",
        "size": 239,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
