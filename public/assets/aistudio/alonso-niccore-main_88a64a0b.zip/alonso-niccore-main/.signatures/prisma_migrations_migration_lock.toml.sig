{
        "file": "prisma/migrations/migration_lock.toml",
        "filename": "migration_lock.toml",
        "hash": "99836963713b4f5b269ad49af0ed3d7b0b2e336115c2f92dc9ac683d139d0900",
        "size": 128,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
