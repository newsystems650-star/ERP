{
        "file": "src/infrastructure/guardian/scheduler.ts",
        "filename": "scheduler.ts",
        "hash": "76421ea53e5d737197adc834f77ad2ad07987c281ae5cbed67d05e7f100ee7d8",
        "size": 1082,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
