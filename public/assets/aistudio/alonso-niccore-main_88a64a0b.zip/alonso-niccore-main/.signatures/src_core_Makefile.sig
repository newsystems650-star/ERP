{
        "file": "src/core/Makefile",
        "filename": "Makefile",
        "hash": "864a66a13772140a81f362d26365a511877c4f72f5fd3112b1d2a5d6d1f9883f",
        "size": 592,
        "modified": "2026-08-01 05:35:23.590239186 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
