{
        "file": "src/modules/cuts/routes/cutRoutes.ts",
        "filename": "cutRoutes.ts",
        "hash": "0b8acc9a59a5ff0c92d5ff4cf3127aa280d11224512552c928cf9c8ed43bdba9",
        "size": 1286,
        "modified": "2026-07-31 05:15:35.002804856 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
