{
        "file": "src/core/ingestion/rate.limiter.ts",
        "filename": "rate.limiter.ts",
        "hash": "bd5d62f4f97a56297fad7280a962dd140f6c7ca8a3d40460be94e5271d25267d",
        "size": 1459,
        "modified": "2026-07-31 05:15:34.995804189 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
