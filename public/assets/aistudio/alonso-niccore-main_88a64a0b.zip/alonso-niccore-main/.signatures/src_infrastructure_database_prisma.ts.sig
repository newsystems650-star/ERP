{
        "file": "src/infrastructure/database/prisma.ts",
        "filename": "prisma.ts",
        "hash": "f21702ba6380d8fcb9a9e265f8305fbf28eba2b678c3e0ce63a1e046ced50b9f",
        "size": 878,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
