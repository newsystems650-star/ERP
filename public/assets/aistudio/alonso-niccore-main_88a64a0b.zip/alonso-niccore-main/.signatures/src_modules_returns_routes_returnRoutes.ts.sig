{
        "file": "src/modules/returns/routes/returnRoutes.ts",
        "filename": "returnRoutes.ts",
        "hash": "32b717316e2cac38466ca0359184285218904afddba729c119d22c3d6ccb73bd",
        "size": 1327,
        "modified": "2026-07-31 05:15:35.004805046 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
