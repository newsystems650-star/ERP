{
        "file": "src/modules/users/user.service.ts",
        "filename": "user.service.ts",
        "hash": "f11cc49b4229a697d9c9017144ec37b4288f8aa83da590d1b790d6e48c457f71",
        "size": 652,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
