{
        "file": "src/modules/wood-inventory/types.ts",
        "filename": "types.ts",
        "hash": "e414374a85136fccaae4fc31908678e244b62c51d0140ef7edb9868aab4032d9",
        "size": 424,
        "modified": "2026-07-31 05:15:35.006805237 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
