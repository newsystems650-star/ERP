{
        "file": "src/core/security/auth.service.ts",
        "filename": "auth.service.ts",
        "hash": "12ea6b0eb11b0bb4188476aed3bd33e9bd2338f55b3c7c528a4bd913bb874cf5",
        "size": 570,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
