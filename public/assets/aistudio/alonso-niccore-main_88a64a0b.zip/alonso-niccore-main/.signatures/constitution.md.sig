{
        "file": "constitution.md",
        "filename": "constitution.md",
        "hash": "1e5a82e803796a80017ac5e87344738b55236f4b1180a300bf91452c9442e48e",
        "size": 847,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
