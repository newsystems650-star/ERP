{
        "file": "src/core/json.hpp",
        "filename": "json.hpp",
        "hash": "665fa14b8af3837966949e8eb0052d583e2ac105d3438baba9951785512cf921",
        "size": 907858,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
