{
        "file": "src/modules/quotations/validators/quotationValidator.ts",
        "filename": "quotationValidator.ts",
        "hash": "05a1d5a0a9523e6ca51bdd41e48fd3a5c54e36b582b07baadc7a3df18f96cfc3",
        "size": 643,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
