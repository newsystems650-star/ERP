{
        "file": "test-motor.js",
        "filename": "test-motor.js",
        "hash": "5bed31aa78b921bbb95be57977b4b12ee6a1b8c975a33553b0120bde8d14a29e",
        "size": 412,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
