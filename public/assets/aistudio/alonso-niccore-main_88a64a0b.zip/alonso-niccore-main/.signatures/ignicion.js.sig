{
        "file": "ignicion.js",
        "filename": "ignicion.js",
        "hash": "eaf7c2258b176d2f36227db913e24415ea0708b8ad1633c71d9cdc862a92fe32",
        "size": 831,
        "modified": "2026-07-31 05:15:34.992803903 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
