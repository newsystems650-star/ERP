{
        "file": "docker-compose.full.yml",
        "filename": "docker-compose.full.yml",
        "hash": "92991623857b7f13d9982a9231785643da59067ec605c0d640a8558b6711f6a9",
        "size": 1875,
        "modified": "2026-08-01 06:47:04.533985364 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
