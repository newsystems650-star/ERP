{
        "file": "audit_part_ad",
        "filename": "audit_part_ad",
        "hash": "abd14fe09d64fb0a876c12bba7bae46ada97e5e843d7df0821c733037f77f827",
        "size": 12933,
        "modified": "2026-07-31 05:15:34.984803141 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
