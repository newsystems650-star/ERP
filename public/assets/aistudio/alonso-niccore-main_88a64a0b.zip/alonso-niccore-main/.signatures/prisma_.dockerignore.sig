{
        "file": "prisma/.dockerignore",
        "filename": ".dockerignore",
        "hash": "a7370d7d063193f49c98c262593019193a6eb0a43bab35708f9b6e99fd38d080",
        "size": 42,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
