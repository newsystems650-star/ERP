{
        "file": "client/src/App.css",
        "filename": "App.css",
        "hash": "6e25a776d3e8102da5bacb3cb99f4a5fc662a2e01e6143140671a556d28c3d5c",
        "size": 2891,
        "modified": "2026-07-31 05:15:34.989803617 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
