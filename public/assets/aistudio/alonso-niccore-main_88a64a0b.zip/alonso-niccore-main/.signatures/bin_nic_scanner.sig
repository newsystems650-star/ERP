{
        "file": "bin/nic_scanner",
        "filename": "nic_scanner",
        "hash": "29450df37628a7eaca1150ff1f93973e16b6dd6ce28a1ea02b74091e60c4a5d9",
        "size": 16432,
        "modified": "2026-08-01 05:36:57.047231932 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
