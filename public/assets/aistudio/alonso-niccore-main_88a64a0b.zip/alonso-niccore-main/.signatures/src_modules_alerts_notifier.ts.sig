{
        "file": "src/modules/alerts/notifier.ts",
        "filename": "notifier.ts",
        "hash": "6058e041e789b0a421afbe46ef13fccb7e3bdb31c86554fc62350216819f1494",
        "size": 1424,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
