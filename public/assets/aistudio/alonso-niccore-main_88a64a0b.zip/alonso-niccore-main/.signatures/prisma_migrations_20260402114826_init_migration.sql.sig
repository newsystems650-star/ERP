{
        "file": "prisma/migrations/20260402114826_init/migration.sql",
        "filename": "migration.sql",
        "hash": "dad388d96f140508d85f138dfa8ef0800e7b860b2e98c5411bc515cc4fc33777",
        "size": 3936,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
