{
        "file": "src/infrastructure/logger/index.ts",
        "filename": "index.ts",
        "hash": "c84b79eb072d112e7d95e498a2318106a7eb889ac2241d6905349fd5e5b2f872",
        "size": 1552,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
