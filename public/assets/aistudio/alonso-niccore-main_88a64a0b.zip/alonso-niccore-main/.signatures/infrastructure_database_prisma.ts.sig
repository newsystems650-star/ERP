{
        "file": "infrastructure/database/prisma.ts",
        "filename": "prisma.ts",
        "hash": "b36138267eabd61c673e3c03f29805943551c02ef08bb07ace0c080158d7458c",
        "size": 881,
        "modified": "2026-07-31 05:15:34.992803903 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
