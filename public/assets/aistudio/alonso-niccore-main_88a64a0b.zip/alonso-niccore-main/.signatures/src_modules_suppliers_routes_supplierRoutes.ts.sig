{
        "file": "src/modules/suppliers/routes/supplierRoutes.ts",
        "filename": "supplierRoutes.ts",
        "hash": "ffe675bec2c99bb379df9918d82362e2a1f9d7eed231fa6aed49b0c531e8675a",
        "size": 1024,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
