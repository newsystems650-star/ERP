{
        "file": "bin/wood_engine",
        "filename": "wood_engine",
        "hash": "933b0b1d9c63d707c2ef37189720db70a3a7b7e22e6b9230a31d3996941a333f",
        "size": 17312,
        "modified": "2026-08-01 05:36:56.533226471 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
