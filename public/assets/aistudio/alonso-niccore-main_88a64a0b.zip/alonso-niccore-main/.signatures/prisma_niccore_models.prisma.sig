{
        "file": "prisma/niccore_models.prisma",
        "filename": "niccore_models.prisma",
        "hash": "e1655e5e8a9e121e8614399c33efbb5588d1513747cf01371429e3119a3ae49b",
        "size": 2754,
        "modified": "2026-07-31 05:15:34.994804094 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
