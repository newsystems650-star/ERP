{
        "file": "dropbox.py",
        "filename": "dropbox.py",
        "hash": "4c2319d6bad065b92ec6f5da2d90bae750214573bc127e6442b036dd72a973ca",
        "size": 61390,
        "modified": "2001-09-09 01:46:40.000000000 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
