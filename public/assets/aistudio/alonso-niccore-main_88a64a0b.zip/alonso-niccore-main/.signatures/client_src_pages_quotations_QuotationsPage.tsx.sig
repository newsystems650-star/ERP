{
        "file": "client/src/pages/quotations/QuotationsPage.tsx",
        "filename": "QuotationsPage.tsx",
        "hash": "dcdb5f166741b2e8c37911696d6ee32002d97a9fca9869333a6ac42658db8582",
        "size": 20011,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
