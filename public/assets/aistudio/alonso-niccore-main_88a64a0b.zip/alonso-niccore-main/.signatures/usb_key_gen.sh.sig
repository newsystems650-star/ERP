{
        "file": "usb_key_gen.sh",
        "filename": "usb_key_gen.sh",
        "hash": "079d9fdaa17dac52a5baac368fdc4bb2110c05dd7856f4821ad8616607eb41f9",
        "size": 271,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
