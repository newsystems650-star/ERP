{
        "file": "src/modules/routes/services/routeService.ts",
        "filename": "routeService.ts",
        "hash": "8590a4b186bcf520575b2c82b1da041f24852389940b82294a37d58b553d7854",
        "size": 3712,
        "modified": "2026-07-31 05:15:35.004805046 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
