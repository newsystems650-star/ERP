{
        "file": "client/src/pages/driver/DriverPage.tsx",
        "filename": "DriverPage.tsx",
        "hash": "4fa2204d029939d59ab2fdcef6f81fbbe9ea3c6b7e086fbca8b6356552429d24",
        "size": 12786,
        "modified": "2026-07-31 05:15:34.990803713 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
