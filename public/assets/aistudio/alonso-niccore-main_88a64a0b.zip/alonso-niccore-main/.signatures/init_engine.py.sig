{
        "file": "init_engine.py",
        "filename": "init_engine.py",
        "hash": "af7716cfe583fea4b2b1da696fbcad474d4de4e6de0e6e8d41dba40537db9e57",
        "size": 3393,
        "modified": "2026-07-31 05:15:34.992803903 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
