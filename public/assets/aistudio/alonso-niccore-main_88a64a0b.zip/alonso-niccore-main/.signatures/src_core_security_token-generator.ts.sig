{
        "file": "src/core/security/token-generator.ts",
        "filename": "token-generator.ts",
        "hash": "23ab9c29fef044f12329791dfc4b130fc4a23e9a008089402304c6ce6897cd2d",
        "size": 605,
        "modified": "2026-07-31 05:15:34.999804570 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
