{
        "file": "client/src/pages/products/ProductsPage.tsx",
        "filename": "ProductsPage.tsx",
        "hash": "4b7beba14fc28abde927d7b763f6f4cf9a86f72063030c97294910da7ead525b",
        "size": 11557,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
