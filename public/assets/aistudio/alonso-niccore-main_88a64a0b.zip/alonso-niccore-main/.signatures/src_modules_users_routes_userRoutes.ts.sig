{
        "file": "src/modules/users/routes/userRoutes.ts",
        "filename": "userRoutes.ts",
        "hash": "1c1bd284a9ab43131b56289047b31b4ce79c2c32d3f151cefe6c7828450c6c3c",
        "size": 1521,
        "modified": "2026-07-31 05:15:35.005805142 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
