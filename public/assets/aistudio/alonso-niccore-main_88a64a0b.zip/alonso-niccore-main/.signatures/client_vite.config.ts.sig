{
        "file": "client/vite.config.ts",
        "filename": "vite.config.ts",
        "hash": "825bba7f68f5cfa0b48d71b97bea4f5c662868cfb3916e5e4db7323837bc0671",
        "size": 283,
        "modified": "2026-08-01 06:02:41.252639798 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
