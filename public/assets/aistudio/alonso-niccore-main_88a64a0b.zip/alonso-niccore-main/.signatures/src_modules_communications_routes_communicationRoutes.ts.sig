{
        "file": "src/modules/communications/routes/communicationRoutes.ts",
        "filename": "communicationRoutes.ts",
        "hash": "0ae03cc2efb2e7ae32e60611ca160edc92e0e60b5f989817b5d00b2e588e8534",
        "size": 1186,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
