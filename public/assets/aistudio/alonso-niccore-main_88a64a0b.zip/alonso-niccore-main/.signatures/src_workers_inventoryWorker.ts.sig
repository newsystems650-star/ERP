{
        "file": "src/workers/inventoryWorker.ts",
        "filename": "inventoryWorker.ts",
        "hash": "9a4fae2445085684681836846092af80c06531c3df4ba7d7052807bda0ee2b76",
        "size": 1475,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:36+00:00"
    }
