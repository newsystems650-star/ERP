{
        "file": "src/infrastructure/cache/redis.ts",
        "filename": "redis.ts",
        "hash": "db896a32d48363de33b09a84004409ea1e643662201ea60bb1a57f29fdf6120f",
        "size": 421,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
