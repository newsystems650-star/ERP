{
        "file": "src/modules/inventory/routes/inventoryRoutes.ts",
        "filename": "inventoryRoutes.ts",
        "hash": "79c5ce550201e38550536f806b740596bd04d953815b11bb5d3880b43dfe67aa",
        "size": 607,
        "modified": "2026-07-31 05:15:35.003804951 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
