{
        "file": "bin/nic_editor",
        "filename": "nic_editor",
        "hash": "8703f2b799cc153994636c9cdc03d4ba97563172c6cb5ada294bae7c563819ab",
        "size": 16392,
        "modified": "2026-08-01 05:36:57.577237564 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
