{
        "file": "src/infrastructure/guardian/errorTracker.ts",
        "filename": "errorTracker.ts",
        "hash": "4328977367a804c729cad106ed7ad08fc8b6b793a73d8bbed7f50c7ece77e2d5",
        "size": 3694,
        "modified": "2026-07-31 05:15:35.000804665 +0000",
        "signature_date": "2026-08-01T07:33:34+00:00"
    }
