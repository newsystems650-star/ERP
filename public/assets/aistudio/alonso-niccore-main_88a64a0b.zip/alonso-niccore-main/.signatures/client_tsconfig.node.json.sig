{
        "file": "client/tsconfig.node.json",
        "filename": "tsconfig.node.json",
        "hash": "c3dd0fb522feba3596713f51b95bd53d781d845d24aedbfa2ac093d8b39c5120",
        "size": 653,
        "modified": "2026-07-31 05:15:34.991803808 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
