{
        "file": "prisma/migrations/20260404134424_add_invoices_suppliers/migration.sql",
        "filename": "migration.sql",
        "hash": "7e4942121d0986fa7ace5c2003d2610389f6c102934afc773088a82bebd10eab",
        "size": 2843,
        "modified": "2026-07-31 05:15:34.993803998 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
