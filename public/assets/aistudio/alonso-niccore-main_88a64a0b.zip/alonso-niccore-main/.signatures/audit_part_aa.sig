{
        "file": "audit_part_aa",
        "filename": "audit_part_aa",
        "hash": "d98d0983bed108f2b20c015be762ded3fb920242f6dd6b986851a421f36154b6",
        "size": 11442,
        "modified": "2026-07-31 05:15:34.983803046 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
