{
        "file": "docker-compose.yml.bak",
        "filename": "docker-compose.yml.bak",
        "hash": "881da001f26601e489ae622cfa80468b74fef7f084b24fe299817303d0cfc577",
        "size": 2222,
        "modified": "2026-08-01 07:32:45.461122004 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
