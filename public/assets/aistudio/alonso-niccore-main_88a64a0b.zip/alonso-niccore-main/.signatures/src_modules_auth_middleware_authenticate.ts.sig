{
        "file": "src/modules/auth/middleware/authenticate.ts",
        "filename": "authenticate.ts",
        "hash": "3f774114752f71c79e9616cc8570c893ced4ff218b6cad6fe7c951426328d75b",
        "size": 1017,
        "modified": "2026-07-31 05:15:35.001804760 +0000",
        "signature_date": "2026-08-01T07:33:35+00:00"
    }
