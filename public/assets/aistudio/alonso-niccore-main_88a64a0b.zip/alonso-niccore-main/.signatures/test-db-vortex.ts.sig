{
        "file": "test-db-vortex.ts",
        "filename": "test-db-vortex.ts",
        "hash": "745c85418697289b88343b94c6888bd3c6d43c7c5220f6937df3dd4834d86c40",
        "size": 615,
        "modified": "2026-07-31 05:15:35.007805332 +0000",
        "signature_date": "2026-08-01T07:33:33+00:00"
    }
