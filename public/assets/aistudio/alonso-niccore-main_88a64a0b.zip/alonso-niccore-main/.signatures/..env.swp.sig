{
        "file": "..env.swp",
        "filename": "..env.swp",
        "hash": "f2fa3d79efbb724ac1c7901d626c7acaaa7a644da4d76ac9fedb853dded6348c",
        "size": 1024,
        "modified": "2026-07-31 05:36:44.021776111 +0000",
        "signature_date": "2026-08-01T07:33:37+00:00"
    }
