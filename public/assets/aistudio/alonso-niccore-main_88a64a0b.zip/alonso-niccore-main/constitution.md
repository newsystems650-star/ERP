# Constitución Técnica NIC-OS v1.0 (Alonso Root)

## Tridente Core
- **Vortex (C++)**: Rutas Empty-Leg (OR-Tools), cubicaje/ROI.
- **Sentinel (Py)**: Fraud SHA256 chained, reputación ML.
- **Bunker (TS)**: Orquestación, Bunker-Billing/Inventory.

## Soberanía
- Root: ALONSO (firma digital, 150y lock: Unix 1891392000).
- Anti-Bypass: Sentinel bloquea directos proveedores.

## Modelos Económicos
- **nicc-oportunidad**: Préstamos prendarios (Stripe, embargo auto >30d).
- **Sniper-Arbitrage**: Buy Durango/Sell CDMX (cost0 logistics).
- **Financial Split**: Sovereign (Alonso %), IA Evol, Ops, WarChest.

## Contratos JSON (Estados)
- OPEN → LOCKED (Sentinel hash) → EXECUTING.
- Penal: 10-30% auto si withdraw post-LOCK.

## Infra
- MicroNodos: MTY/Edomex/QRO (comisión storage).

*Integrado en Niccore. Despliegue Megalote ready.*

