import express from 'express';
import { tenantMiddleware } from './interfaces/http/middlewares/tenant.middleware';
import { processWoodSale } from './interfaces/http/controllers/wood.controller';
import { getUsers, createUser } from './interfaces/http/controllers/user.controller';
import { createTicket, getTickets } from './interfaces/http/controllers/ticket.controller';

// Legacy business routes. tenantMiddleware provides tenant context only; it is
// NOT authentication. Keep this entrypoint disabled until real auth is wired.
const app = express();
app.use(express.json());

// WOOD
app.post('/api/wood/calculate', tenantMiddleware, processWoodSale);

// USERS
app.get('/api/users', tenantMiddleware, getUsers);
app.post('/api/users/dev-create', tenantMiddleware, createUser);

// SALES
app.post('/api/tickets', tenantMiddleware, createTicket);
app.get('/api/tickets', tenantMiddleware, getTickets);

if (process.env.NICCORE_LEGACY_SERVER_ENABLED === 'true') {
  const port = Number(process.env.PORT || 3000);
  app.listen(port, '127.0.0.1', () => {
    console.log('[NICCORE] Legacy business API listening on loopback only.');
    console.warn('[NICCORE] Tenant context is not authentication; do not expose this server publicly.');
  });
}

export { app };
