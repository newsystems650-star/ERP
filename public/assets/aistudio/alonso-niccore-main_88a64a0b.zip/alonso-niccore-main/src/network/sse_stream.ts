import { Router, Request, Response } from 'express';
import { liveMapProjection } from '../core/projections/map.projection';

export const mapStreamRouter = Router();

mapStreamRouter.get('/stream/map', (req: Request, res: Response) => {
    res.setHeader('Content-Type',  'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection',    'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', process.env.CLIENT_ORIGIN ?? '*');
    res.flushHeaders();

    liveMapProjection.addClient(res);
    req.on('close', () => liveMapProjection.removeClient(res));
});
