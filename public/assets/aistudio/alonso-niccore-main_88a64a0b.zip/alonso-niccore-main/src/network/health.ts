import { Router, Request, Response } from 'express';
import { liveMapProjection } from '../core/projections/map.projection';
import { eventStore } from '../core/event-store/eventStore';

export const healthRouter = Router();

healthRouter.get('/health', (_req: Request, res: Response) => {
  const mem = process.memoryUsage();
  const lastEvent = eventStore.getLastEvent();
  const lastEventAt = lastEvent ? Date.parse(lastEvent.storedAt) : 0;
  const silenceMs = lastEventAt > 0 ? Math.max(0, Date.now() - lastEventAt) : -1;

  res.json({
    status: 'ok',
    uptime: Math.floor(process.uptime()),
    memoryMB: Math.round(mem.heapUsed / 1024 / 1024),
    activeNodes: Object.keys(liveMapProjection.getSnapshot()).length,
    eventCount: eventStore.getEventCount(),
    persistedBreadcrumbs: eventStore.getEventCountByType('LOGISTICS_NODE_BREADCRUMB'),
    silenceMs,
    timestamp: new Date().toISOString(),
  });
});
