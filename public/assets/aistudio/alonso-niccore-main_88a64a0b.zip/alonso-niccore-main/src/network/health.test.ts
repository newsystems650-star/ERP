import assert from 'node:assert/strict';
import { once } from 'node:events';
import express from 'express';
import test, { after } from 'node:test';
import { healthRouter } from './health';
import { liveMapProjection } from '../core/projections/map.projection';
import { eventStore } from '../core/event-store/eventStore';

after(() => {
  liveMapProjection.shutdown();
});

test('GET /api/health returns measured runtime and event metrics', async () => {
  const app = express();
  app.use('/api', healthRouter);
  const server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');

  try {
    const address = server.address();
    assert.ok(address && typeof address !== 'string');
    const response = await fetch(`http://127.0.0.1:${address.port}/api/health`);
    assert.equal(response.status, 200);

    const body = await response.json() as Record<string, unknown>;
    assert.equal(body.status, 'ok');
    assert.equal(body.eventCount, eventStore.getEventCount());
    assert.equal(
      body.persistedBreadcrumbs,
      eventStore.getEventCountByType('LOGISTICS_NODE_BREADCRUMB'),
    );
    assert.equal(typeof body.uptime, 'number');
    assert.equal(typeof body.memoryMB, 'number');
    assert.equal(typeof body.activeNodes, 'number');
    assert.equal(typeof body.silenceMs, 'number');
    assert.ok(typeof body.timestamp === 'string' && !Number.isNaN(Date.parse(body.timestamp)));
  } finally {
    await new Promise<void>((resolve, reject) => {
      server.close(error => error ? reject(error) : resolve());
    });
  }
});
