import { Router, Request, Response } from 'express';
import { taskRuntime } from '../core/runtime/taskRuntime';

export const tasksRouter = Router();

tasksRouter.post('/', (req: Request, res: Response) => {
  try {
    const { executor, input } = req.body ?? {};
    if (typeof executor !== 'string') {
      res.status(400).json({ error: 'executor must be a string' });
      return;
    }
    const task = taskRuntime.submit(executor, input);
    res.status(202).json({ task });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Task submission failed';
    const status = /Unknown executor/.test(message) ? 400 : 422;
    res.status(status).json({ error: message });
  }
});

tasksRouter.get('/', (_req: Request, res: Response) => {
  res.json({ tasks: taskRuntime.list(), runtime: taskRuntime.snapshot() });
});

tasksRouter.get('/:id', (req: Request, res: Response) => {
  const task = taskRuntime.get(req.params.id);
  if (!task) {
    res.status(404).json({ error: 'Task not found' });
    return;
  }
  res.json({ task });
});
