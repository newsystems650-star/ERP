import Fastify from 'fastify';
import { prismaPlugin } from './infrastructure/database/prisma.plugin';
import { errorHandler } from './shared/middleware/errorHandler';

export async function bootstrap() {
  const app = Fastify({ logger: false }); // Desactivamos logger nativo para usar el nuestro

  await app.register(prismaPlugin);
  app.setErrorHandler(errorHandler);

  // Registro directo para evitar errores de resolución de módulos
  await app.register(import('./modules/tickets/routes/ticketRoutes'), { 
    prefix: '/api/tickets' 
  });

  return app;
}
