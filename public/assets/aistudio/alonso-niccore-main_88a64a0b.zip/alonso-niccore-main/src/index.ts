import express from 'express';
import { healthRouter } from './network/health';
import { eventStore } from './core/event-store/eventStore';
import { TelemetryTunnel } from './core/ingestion/udp_receiver';
import { liveMapProjection } from './core/projections/map.projection';

const app = express();
app.use(express.json());
app.use('/api', healthRouter);

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

if (require.main === module) {
  eventStore.initialize();

  let telemetryTunnel: TelemetryTunnel | undefined;
  if (process.env.NICCORE_UDP_ENABLED === 'true') {
    telemetryTunnel = new TelemetryTunnel();
    telemetryTunnel.start();
    console.log('[NICCORE] UDP telemetry enabled on port 41234');
  } else {
    console.log('[NICCORE] UDP telemetry disabled; set NICCORE_UDP_ENABLED=true to enable it');
  }

  const PORT = Number(process.env.PORT || 3000);
  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[NICCORE] API listening on port ${PORT}`);
    console.log(`[NICCORE] Health: http://localhost:${PORT}/health`);
    console.log(`[NICCORE] Metrics: http://localhost:${PORT}/api/health`);
  });

  const shutdown = (signal: string) => {
    console.log(`[NICCORE] received ${signal}; shutting down`);
    liveMapProjection.shutdown();
    server.close(() => {
      if (telemetryTunnel) {
        void telemetryTunnel.stop().finally(() => process.exit(0));
      } else {
        process.exit(0);
      }
    });
  };
  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));
}

export { app };
