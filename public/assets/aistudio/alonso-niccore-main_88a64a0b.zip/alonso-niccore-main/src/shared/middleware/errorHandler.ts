import { Request, Response, NextFunction } from 'express'
import { AppError } from '../errors/AppError'
import { ZodError } from 'zod'

export function errorHandler(err: Error, req: Request, res: Response, next: NextFunction) {
  console.error('ERROR:', err.message)
  console.error('STACK:', err.stack)
  if (err instanceof ZodError) {
    return res.status(422).json({
      error: { code: 'VALIDATION_ERROR', message: 'Datos inválidos', details: err.errors }
    })
  }
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      error: { code: err.code, message: err.message }
    })
  }
  return res.status(500).json({
    error: { code: 'INTERNAL_ERROR', message: err.message }
  })
}
