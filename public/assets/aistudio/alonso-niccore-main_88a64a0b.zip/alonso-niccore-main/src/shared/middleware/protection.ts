import { Request, Response, NextFunction } from 'express'
import rateLimit from 'express-rate-limit'
import { isBunkerMode, trackUserError } from '../../infrastructure/guardian/errorTracker'
import { AuthRequest } from '../../modules/auth/middleware/authenticate'
import { logger } from '../../infrastructure/logger'

// Rate limiting general
export const generalRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 500,
  message: { error: { code: 'RATE_LIMIT', message: 'Demasiadas solicitudes. Intenta en 15 minutos.' } },
  standardHeaders: true,
  legacyHeaders: false,
})

// Rate limiting estricto para auth
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: { code: 'AUTH_RATE_LIMIT', message: 'Demasiados intentos de login. Intenta en 15 minutos.' } },
})

// Middleware modo búnker — logging extra detallado
export async function bunkerMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  const bunker = await isBunkerMode()

  if (bunker) {
    logger.warn('BUNKER_REQUEST', {
      method: req.method,
      path: req.path,
      userId: req.user?.id,
      ip: req.ip,
      body: req.method !== 'GET' ? req.body : undefined,
    })
  }

  next()
}

// Middleware para trackear errores de usuario en operaciones críticas
export function trackUserAction(module: string, action: string) {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    const originalJson = res.json.bind(res)

    res.json = function(data: any) {
      if (data?.error && req.user) {
        trackUserError({
          userId: req.user.id,
          userName: req.user.email,
          action,
          module,
          errorType: data.error.code || 'UNKNOWN',
          details: data.error.message || '',
          ip: req.ip,
        }).catch(console.error)
      }
      return originalJson(data)
    }

    next()
  }
}
