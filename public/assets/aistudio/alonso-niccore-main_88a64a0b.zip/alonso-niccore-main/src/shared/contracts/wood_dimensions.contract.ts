import { z } from 'zod';

export const WoodTableSchema = z.object({
  woodType: z.enum(['PINO', 'CEDRO', 'CAOBA', 'ENCINO', 'TZALAM']),
  quality: z.enum(['1_CLASE', '2_CLASE', '3_CLASE']),
  isTablon: z.boolean(), // true si es >= 1.5"
  dimensions: z.object({
    thickness: z.number(), // 3/4, 1, 1.5, 2
    width: z.number(),     // 4, 6, 8, 10, 12 o Variable
    length: z.number(),    // 8 o Variable
  }),
  quantity: z.number().int().positive()
});
