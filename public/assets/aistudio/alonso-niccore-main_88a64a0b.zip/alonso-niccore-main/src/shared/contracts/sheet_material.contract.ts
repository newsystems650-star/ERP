import { z } from 'zod';

export const SheetMaterialSchema = z.object({
  type: z.enum(['TRIPLAY', 'MDF', 'MELAMINA', 'OSB', 'EXIBIPANEL']),
  thickness: z.enum(['3', '5.5', '9', '12', '15', '18', '23', '25', '30']), // Grosor en mm
  width: z.number().default(122), // cm
  length: z.number().default(244), // cm
  requestedPieces: z.array(z.object({
    w: z.number(), // Ancho deseado
    l: z.number(), // Largo deseado
    qty: z.number().int().positive()
  }))
});
