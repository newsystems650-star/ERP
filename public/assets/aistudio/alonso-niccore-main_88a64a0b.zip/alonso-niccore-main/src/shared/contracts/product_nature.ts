// src/shared/contracts/product_nature.ts
export enum ProductNature {
  WOOD_SHEET = 'WOOD_SHEET',   // Hojas (Triplay/MDF)
  WOOD_LUMBER = 'WOOD_LUMBER', // Tablas/Tablones (Pies Tablares)
  HARDWARE = 'HARDWARE',       // Ferretería (Piezas/Litros)
  SERVICE = 'SERVICE'          // Maquila/Flete (Sin stock físico)
}

// src/modules/inventory/services/stockService.ts
export async function deductStock(productId: string, quantity: number, nature: ProductNature) {
  return await prisma.$transaction(async (tx) => {
    
    // Si es SERVICIO, no descontamos nada, solo registramos la venta
    if (nature === ProductNature.SERVICE) return;

    const stock = await tx.stock.findUnique({ where: { productId } });

    // LEY 2: NO GUARDAR BASURA - Validamos antes de descontar
    if (!stock || stock.quantity < quantity) {
      throw new InsufficientStockError(productId); 
    }

    // LEY 5: PURIFICACIÓN - Diferentes formas de descontar
    let newQuantity;
    if (nature === ProductNature.WOOD_LUMBER) {
      // Descuento exacto por Pies Tablares (C++ validó esto antes)
      newQuantity = Number(stock.quantity) - quantity;
    } else {
      // Descuento por piezas enteras
      newQuantity = Math.floor(Number(stock.quantity) - quantity);
    }

    return await tx.stock.update({
      where: { productId },
      data: { quantity: newQuantity }
    });
  });
}
