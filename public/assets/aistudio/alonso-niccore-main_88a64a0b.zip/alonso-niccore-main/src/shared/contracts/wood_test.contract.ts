import { z } from 'zod';

// LEY 5: Purificación de entrada para evitar 'any'
export const WoodTestSchema = z.object({
  type: z.literal('PINO_1RA'),
  thickness: z.number().default(1), // Grosor en pulgadas
  width: z.number().min(4).max(12),  // Ancho en pulgadas (estándar pino)
  length: z.number().default(8),    // Largo en pies (estándar pino)
  cost: z.number().positive()       // Inversión inicial
});

export type WoodTest = z.infer<typeof WoodTestSchema>;
