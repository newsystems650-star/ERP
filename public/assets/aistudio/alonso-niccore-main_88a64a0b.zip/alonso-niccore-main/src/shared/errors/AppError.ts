export class AppError extends Error {
  public readonly statusCode: number
  public readonly code: string
  constructor(message: string, statusCode = 400, code = 'APP_ERROR') {
    super(message)
    this.statusCode = statusCode
    this.code = code
    Object.setPrototypeOf(this, AppError.prototype)
  }
}
export class NotFoundError extends AppError {
  constructor(resource: string) { super(`${resource} no encontrado`, 404, 'NOT_FOUND') }
}
export class UnauthorizedError extends AppError {
  constructor(message = 'No autorizado') { super(message, 401, 'UNAUTHORIZED') }
}
export class ForbiddenError extends AppError {
  constructor(message = 'Acceso denegado') { super(message, 403, 'FORBIDDEN') }
}
export class ConflictError extends AppError {
  constructor(message: string) { super(message, 409, 'CONFLICT') }
}
export class InsufficientStockError extends AppError {
  constructor(product: string, available: number, requested: number) {
    super(`Stock insuficiente para "${product}". Disponible: ${available}, Solicitado: ${requested}`, 409, 'INSUFFICIENT_STOCK')
  }
}
