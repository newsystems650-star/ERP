import { Client, LocalAuth } from 'whatsapp-web.js';
import qrcode from 'qrcode-terminal';

class WhatsAppEngine {
    private client:       Client;
    private ready         = false;
    private readyPromise: Promise<void>;
    private resolveReady!: () => void;

    constructor() {
        this.readyPromise = new Promise((res) => { this.resolveReady = res; });
        this.client = new Client({
            authStrategy: new LocalAuth({ dataPath: '.wwebjs_auth' }),
            puppeteer: {
                headless: true,
                args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
            },
        });
        this.initialize();
    }

    private initialize(): void {
        this.client.on('qr', (qr) => {
            console.log('\n[WhatsApp] Escanea este QR:');
            qrcode.generate(qr, { small: true });
        });
        this.client.on('ready', () => {
            this.ready = true;
            this.resolveReady();
            console.log('[WhatsApp] ✅ Sesión activa.');
        });
        this.client.on('auth_failure', (msg) => {
            console.error('[WhatsApp] ❌ Auth failure:', msg);
        });
        this.client.on('disconnected', (reason) => {
            this.ready = false;
            console.warn('[WhatsApp] Desconectado:', reason);
            setTimeout(() => this.client.initialize(), 10_000);
        });
        this.client.initialize();
    }

    private formatNumber(telefono: string): string {
        return `${telefono.replace(/\D/g, '')}@c.us`;
    }

    public async send(telefono: string, mensaje: string): Promise<{ ok: boolean; error?: string }> {
        if (!this.ready) return { ok: false, error: 'Motor no listo.' };
        try {
            await this.client.sendMessage(this.formatNumber(telefono), mensaje);
            return { ok: true };
        } catch (e) {
            return { ok: false, error: String(e) };
        }
    }

    public async shutdown(): Promise<void> {
        await this.client.destroy();
        console.log('[WhatsApp] Motor detenido.');
    }
}

export const whatsappEngine = new WhatsAppEngine();
