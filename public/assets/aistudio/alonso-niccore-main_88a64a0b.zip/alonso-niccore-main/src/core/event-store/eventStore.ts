import fs from 'node:fs';
import path from 'node:path';
import { eventBus, EventBus } from './eventBus';

export interface StoredEvent {
  type: string;
  storedAt: string;
  [key: string]: any;
}

const SENSITIVE_KEY = /(password|token|secret|api[_-]?key|authorization|cookie)/i;

function redact(value: any): any {
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [
        key,
        SENSITIVE_KEY.test(key) ? '[REDACTED]' : redact(item),
      ]),
    );
  }
  return value;
}

/**
 * Append-only local event log. The JSONL file is the durable source;
 * the in-memory array is only a query cache.
 */
export class EventStore {
  private readonly events: StoredEvent[] = [];
  private readonly counts = new Map<string, number>();
  private lastEvent?: StoredEvent;
  private initialized = false;

  private indexEvent(event: StoredEvent): void {
    this.counts.set(event.type, (this.counts.get(event.type) ?? 0) + 1);
    this.lastEvent = event;
  }

  constructor(
    private readonly logPath: string = process.env.NICCORE_EVENT_LOG
      || path.join(process.cwd(), 'data', 'events.jsonl'),
    private readonly bus: EventBus = eventBus,
  ) {}

  initialize(): this {
    if (this.initialized) return this;

    fs.mkdirSync(path.dirname(this.logPath), { recursive: true });

    if (fs.existsSync(this.logPath)) {
      const lines = fs.readFileSync(this.logPath, 'utf8').split(/\r?\n/);
      lines.forEach((line, index) => {
        if (!line.trim()) return;
        let parsed: StoredEvent;
        try {
          parsed = JSON.parse(line) as StoredEvent;
        } catch {
          throw new Error(`NICCORE event log is invalid JSON at line ${index + 1}: ${this.logPath}`);
        }
        if (!parsed || typeof parsed.type !== 'string' || typeof parsed.storedAt !== 'string') {
          throw new Error(`NICCORE event log has an invalid record at line ${index + 1}: ${this.logPath}`);
        }
        this.events.push(parsed);
        this.indexEvent(parsed);
      });
    }

    this.bus.subscribe('*', (event: Record<string, any>) => this.store(event));
    this.initialized = true;
    console.log(`[EventStore] initialized | records=${this.events.length} | file=${this.logPath}`);
    return this;
  }

  store(event: Record<string, any>): StoredEvent {
    if (!this.initialized) {
      throw new Error('NICCORE EventStore must be initialized before storing events');
    }
    if (!event || typeof event.type !== 'string' || event.type.length === 0) {
      throw new TypeError('NICCORE events must include a non-empty string type');
    }

    const stored: StoredEvent = {
      ...redact(event),
      storedAt: new Date().toISOString(),
    };
    fs.appendFileSync(this.logPath, `${JSON.stringify(stored)}\n`, { encoding: 'utf8', flag: 'a' });
    this.events.push(stored);
    this.indexEvent(stored);
    return stored;
  }

  getEvents(): StoredEvent[] {
    return this.events.slice();
  }

  getEventsByType(type: string): StoredEvent[] {
    return this.events.filter(event => event.type === type);
  }

  getEventCount(): number {
    return this.events.length;
  }

  getEventCountByType(type: string): number {
    return this.counts.get(type) ?? 0;
  }

  getLastEvent(): StoredEvent | undefined {
    return this.lastEvent;
  }
}

export const eventStore = new EventStore();
