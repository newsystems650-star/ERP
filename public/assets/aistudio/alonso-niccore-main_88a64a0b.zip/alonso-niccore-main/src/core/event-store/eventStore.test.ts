import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { EventBus } from './eventBus';
import { EventStore } from './eventStore';

test('wildcard subscribers persist events and reload them after restart', () => {
  const directory = mkdtempSync(path.join(tmpdir(), 'niccore-events-'));
  const logPath = path.join(directory, 'events.jsonl');

  try {
    const bus = new EventBus();
    const store = new EventStore(logPath, bus).initialize();

    bus.publish({
      type: 'TEST_EVENT',
      payload: { ok: true, apiToken: 'do-not-store-this' },
      source: 'unit-test',
    });

    assert.equal(store.getEvents().length, 1);
    assert.equal(store.getEventsByType('TEST_EVENT').length, 1);
    assert.equal(store.getEventCount(), 1);
    assert.equal(store.getEventCountByType('TEST_EVENT'), 1);
    assert.equal(store.getLastEvent()?.type, 'TEST_EVENT');
    assert.equal(store.getEvents()[0].payload.ok, true);
    assert.equal(store.getEvents()[0].payload.apiToken, '[REDACTED]');

    const reloaded = new EventStore(logPath, new EventBus()).initialize();
    assert.equal(reloaded.getEvents().length, 1);
    assert.equal(reloaded.getEventCount(), 1);
    assert.equal(reloaded.getEventCountByType('TEST_EVENT'), 1);
    assert.equal(reloaded.getLastEvent()?.type, 'TEST_EVENT');
    assert.equal(reloaded.getEvents()[0].type, 'TEST_EVENT');
    assert.equal(reloaded.getEvents()[0].payload.ok, true);
    assert.equal(reloaded.getEvents()[0].payload.apiToken, '[REDACTED]');
    assert.equal(typeof reloaded.getEvents()[0].storedAt, 'string');
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test('static EventBus API shares the default event stream', () => {
  const eventType = 'STATIC_API_TEST_EVENT';
  let received = 0;
  const handler = () => { received += 1; };

  EventBus.subscribe(eventType, handler);
  try {
    EventBus.publish({ type: eventType, payload: { ok: true } });
    assert.equal(received, 1);
  } finally {
    // The shared bus has no unsubscribe API yet; use a unique event type per test.
  }
});
