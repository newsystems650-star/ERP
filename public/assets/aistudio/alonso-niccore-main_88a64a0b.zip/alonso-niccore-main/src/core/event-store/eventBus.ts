// NICCORE EVENT BUS

export type EventHandler = (event: any) => void;

/**
 * EventBus keeps instance-based subscriptions while preserving the static
 * API already used by existing NicCore modules.
 */
export class EventBus {
  private handlers: Map<string, EventHandler[]> = new Map();

  subscribe(eventType: string, handler: EventHandler): void {
    const handlers = this.handlers.get(eventType) ?? [];
    handlers.push(handler);
    this.handlers.set(eventType, handlers);
  }

  publish(event: any): void {
    if (!event || typeof event.type !== 'string' || event.type.length === 0) {
      throw new TypeError('NICCORE events must include a non-empty string type');
    }

    const exactHandlers = this.handlers.get(event.type) ?? [];
    const wildcardHandlers = this.handlers.get('*') ?? [];
    for (const handler of [...exactHandlers, ...wildcardHandlers]) {
      handler(event);
    }
  }

  static subscribe(eventType: string, handler: EventHandler): void {
    eventBus.subscribe(eventType, handler);
  }

  static publish(event: any): void {
    eventBus.publish(event);
  }
}

export const eventBus = new EventBus();
