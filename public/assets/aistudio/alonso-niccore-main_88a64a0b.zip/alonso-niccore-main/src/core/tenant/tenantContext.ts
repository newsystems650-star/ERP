import { AsyncLocalStorage } from 'async_hooks';
export interface TenantStore { tenantId: string; userId: string; }
export const tenantStorage = new AsyncLocalStorage<TenantStore>();
export const getTenantContext = () => {
  const store = tenantStorage.getStore();
  if (!store) return { tenantId: 'niccore-master', userId: 'admin-dev' };
  return store;
};
