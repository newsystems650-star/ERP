import { eventBus } from '../event-store/eventBus';
import { prisma }   from '../../lib/prisma';

const FLUSH_INTERVAL_MS = 30_000;
const FLUSH_THRESHOLD   = 500;

interface BreadcrumbRecord {
    nodeId:       string;
    trip_id:      string;
    latitud:      number;
    longitud:     number;
    velocidadKmh: number;
    timestamp:    Date;
}

export class PostgresBatchWorker {
    private buffer:     BreadcrumbRecord[] = [];
    private flushTimer?: NodeJS.Timeout;
    private isFlushing  = false;

    constructor() { this.initialize(); }

    private initialize(): void {
        eventBus.subscribe('LOGISTICS_NODE_BREADCRUMB', (event) => {
            const d = event.payload;
            this.buffer.push({
                nodeId:       d.nodeId,
                trip_id:      d.tripId,
                latitud:      d.latitud,
                longitud:     d.longitud,
                velocidadKmh: d.velocidad_kmh,
                timestamp:    new Date(d.timestamp_dispositivo * 1000),
            });
            if (this.buffer.length >= FLUSH_THRESHOLD) void this.flush();
        });

        this.flushTimer = setInterval(() => void this.flush(), FLUSH_INTERVAL_MS);
    }

    private async flush(): Promise<void> {
        if (this.buffer.length === 0 || this.isFlushing) return;
        this.isFlushing  = true;
        const batch = this.buffer.splice(0, this.buffer.length);
        try {
            await prisma.node_breadcrumbs.createMany({ data: batch, skipDuplicates: true });
            console.log(`[BatchWorker] ${batch.length} breadcrumbs grabados.`);
        } catch (e) {
            console.error(`[BatchWorker] Lote descartado: ${batch.length} registros.`);
        } finally {
            this.isFlushing = false;
        }
    }

    public async shutdown(): Promise<void> {
        clearInterval(this.flushTimer);
        await this.flush();
        await prisma.$disconnect();
        console.log('[BatchWorker] Desconectado de PostgreSQL.');
    }
}

export const batchWorker = new PostgresBatchWorker();
