/**
 * NIC-SCANNER (C++ Puro)
 * 
 * Lee /proc/<pid>/stat, /proc/meminfo
 * Firma datos con clave USB
 * Envía FlatBuffer al socket Unix /tmp/nic_scanner.sock
 * 
 * Compilar: g++ -O3 -std=c++17 -o bin/nic_scanner src/core/nic_scanner.cpp -lssl -lcrypto
 * Ejecutar: ./bin/nic_scanner
 */

#include <iostream>
#include <fstream>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <cstring>
#include <vector>
#include <openssl/sha.h>
#include <ctime>
#include <sstream>

struct ProcessMetric {
  uint32_t pid;
  uint32_t cpu_usage_percent;
  uint32_t mem_kb;
  uint64_t timestamp;
  char process_name[64];
};

struct ScannerPayload {
  ProcessMetric api;
  ProcessMetric engines;
  ProcessMetric sentinel;
  uint64_t sys_mem_free_kb;
  uint64_t sys_mem_total_kb;
  unsigned char signature[32];
};

uint32_t readCpuUsage(uint32_t pid) {
  std::string path = "/proc/" + std::to_string(pid) + "/stat";
  std::ifstream file(path);
  if (!file.is_open()) return 0;

  uint32_t utime, stime;
  std::string line;
  std::getline(file, line);

  std::istringstream iss(line);
  for (int i = 0; i < 13; i++) iss >> utime;
  iss >> stime;

  file.close();
  return (utime + stime) / 100;
}

uint32_t readMemory(uint32_t pid) {
  std::string path = "/proc/" + std::to_string(pid) + "/status";
  std::ifstream file(path);
  if (!file.is_open()) return 0;

  std::string line;
  while (std::getline(file, line)) {
    if (line.find("VmRSS:") == 0) {
      std::istringstream iss(line);
      std::string label;
      uint32_t kb;
      iss >> label >> kb;
      file.close();
      return kb;
    }
  }

  file.close();
  return 0;
}

void readSystemMemory(uint64_t& total, uint64_t& available) {
  std::ifstream file("/proc/meminfo");
  std::string line;

  while (std::getline(file, line)) {
    if (line.find("MemTotal:") == 0) {
      std::istringstream iss(line);
      std::string label;
      iss >> label >> total;
    }
    if (line.find("MemAvailable:") == 0) {
      std::istringstream iss(line);
      std::string label;
      iss >> label >> available;
    }
  }

  file.close();
}

void signPayload(ScannerPayload& payload, const std::string& secret) {
  unsigned char hash[SHA256_DIGEST_LENGTH];
  SHA256_CTX sha256;
  SHA256_Init(&sha256);

  SHA256_Update(&sha256, &payload.api, sizeof(ProcessMetric));
  SHA256_Update(&sha256, &payload.engines, sizeof(ProcessMetric));
  SHA256_Update(&sha256, &payload.sentinel, sizeof(ProcessMetric));
  SHA256_Update(&sha256, &payload.sys_mem_free_kb, sizeof(uint64_t));
  SHA256_Update(&sha256, &payload.sys_mem_total_kb, sizeof(uint64_t));
  SHA256_Update(&sha256, secret.c_str(), secret.length());

  SHA256_Final(hash, &sha256);
  std::memcpy(payload.signature, hash, SHA256_DIGEST_LENGTH);
}

void sendToSocket(const ScannerPayload& payload) {
  int sock = socket(AF_UNIX, SOCK_DGRAM, 0);
  if (sock < 0) {
    std::cerr << "[nic_scanner] Error creando socket\n";
    return;
  }

  struct sockaddr_un addr;
  std::memset(&addr, 0, sizeof(addr));
  addr.sun_family = AF_UNIX;
  std::strcpy(addr.sun_path, "/tmp/nic_scanner.sock");

  if (sendto(sock, &payload, sizeof(payload), 0, (struct sockaddr*)&addr,
             sizeof(addr)) < 0) {
    std::cerr << "[nic_scanner] Error enviando datos\n";
  }

  close(sock);
}

int main() {
  std::string usb_secret = "ALONSO_SOVEREIGN_KEY_2026";
  uint32_t node_pid_api = getpid();
  uint32_t node_pid_engine = getpid() + 1;
  uint32_t node_pid_sentinel = getpid() + 2;

  std::cout << "[nic_scanner] Iniciado. Socket: /tmp/nic_scanner.sock\n";

  while (true) {
    ScannerPayload payload;
    std::memset(&payload, 0, sizeof(payload));

    payload.api.pid = node_pid_api;
    payload.api.cpu_usage_percent = readCpuUsage(node_pid_api);
    payload.api.mem_kb = readMemory(node_pid_api);
    payload.api.timestamp = std::time(nullptr);
    std::strcpy(payload.api.process_name, "node_api");

    payload.engines.pid = node_pid_engine;
    payload.engines.cpu_usage_percent = readCpuUsage(node_pid_engine);
    payload.engines.mem_kb = readMemory(node_pid_engine);
    payload.engines.timestamp = std::time(nullptr);
    std::strcpy(payload.engines.process_name, "niccore_engine");

    payload.sentinel.pid = node_pid_sentinel;
    payload.sentinel.cpu_usage_percent = readCpuUsage(node_pid_sentinel);
    payload.sentinel.mem_kb = readMemory(node_pid_sentinel);
    payload.sentinel.timestamp = std::time(nullptr);
    std::strcpy(payload.sentinel.process_name, "sentinel");

    uint64_t mem_total, mem_avail;
    readSystemMemory(mem_total, mem_avail);
    payload.sys_mem_total_kb = mem_total;
    payload.sys_mem_free_kb = mem_avail;

    signPayload(payload, usb_secret);
    sendToSocket(payload);

    std::cout << "[nic_scanner] Tick: API=" << payload.api.mem_kb << "KB, "
              << "Engine=" << payload.engines.mem_kb << "KB\n";

    sleep(5);
  }

  return 0;
}