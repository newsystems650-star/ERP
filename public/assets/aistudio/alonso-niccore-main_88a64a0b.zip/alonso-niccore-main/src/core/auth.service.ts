import jwt, { type SignOptions } from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';

const SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  console.error("❌ ERROR CRÍTICO: JWT_SECRET no definido en el entorno.");
  process.exit(1);
}

export class AuthService {
  static generateToken(payload: { tenantId: string; userId: string; role: string; root?: boolean }) {
    const opts: SignOptions = { expiresIn: payload.root ? '150y' : '8h' };
    return jwt.sign(payload, SECRET, opts);
  }

  static verifyToken(token: string) {
    try {
      return jwt.verify(token, SECRET);
    } catch (e) {
      throw new Error('🚫 Llave inválida o expirada.');
    }
  }

  static async rootVerify(token: string, prisma: PrismaClient) {
    const payload = jwt.verify(token, SECRET) as any;
    if (payload.root !== true) throw new Error('🚫 No Root Authority.');

    const now = Math.floor(Date.now() / 1000);
    const root = await prisma.rootAuthority.findFirst({ where: { active: true } });
    if (!root || now > root.lockUntil) {
      throw new Error('👑 Root expired (150y lock: 1891392000).');
    }
    return { ...payload, rootId: root.id };
  }
}

