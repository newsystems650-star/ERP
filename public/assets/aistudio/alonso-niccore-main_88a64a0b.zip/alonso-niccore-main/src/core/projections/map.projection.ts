import { Response } from 'express';
import { eventBus } from '../event-store/eventBus';

interface NodeState {
    lat:        number;
    lon:        number;
    spd:        number;
    tripId:     string;
    lastUpdate: number;
}

export class LiveMapProjection {
    private activeNodes:  Map<string, NodeState> = new Map();
    private clients:      Set<Response>           = new Set();

    private readonly GHOST_TTL_MS   = 60_000;
    private readonly SWEEP_INTERVAL = 15_000;
    private readonly PUSH_INTERVAL  = 1_000;

    private sweepTimer?:     NodeJS.Timeout;
    private broadcastTimer?: NodeJS.Timeout;

    constructor() { this.initialize(); }

    private initialize(): void {
        eventBus.subscribe('LOGISTICS_NODE_BREADCRUMB', (event) => {
            const d = event.payload;
            this.activeNodes.set(d.nodeId, {
                lat:        d.latitud,
                lon:        d.longitud,
                spd:        d.velocidad_kmh,
                tripId:     d.tripId,
                lastUpdate: Date.now(),
            });
        });

        this.sweepTimer = setInterval(() => {
            const now = Date.now();
            for (const [id, state] of this.activeNodes.entries()) {
                if (now - state.lastUpdate > this.GHOST_TTL_MS) {
                    this.activeNodes.delete(id);
                    console.log(`[MapProjection] Nodo expirado: ${id}`);
                }
            }
        }, this.SWEEP_INTERVAL);

        this.broadcastTimer = setInterval(() => {
            if (this.clients.size === 0) return;
            const data = `data: ${JSON.stringify(this.getSnapshot())}\n\n`;
            for (const res of this.clients) {
                try { res.write(data); }
                catch { this.clients.delete(res); }
            }
        }, this.PUSH_INTERVAL);
    }

    public addClient(res: Response): void { this.clients.add(res); }
    public removeClient(res: Response): void { this.clients.delete(res); }

    public getSnapshot(): Record<string, NodeState> {
        const snap: Record<string, NodeState> = {};
        for (const [id, state] of this.activeNodes.entries()) snap[id] = state;
        return snap;
    }

    public shutdown(): void {
        clearInterval(this.sweepTimer);
        clearInterval(this.broadcastTimer);
        this.clients.clear();
        console.log('[MapProjection] Proyector detenido.');
    }
}

export const liveMapProjection = new LiveMapProjection();
