import { spawn, ChildProcess } from 'child_process';
import path from 'path';

const ENGINE_BIN             = path.resolve('build/Release/niccore_engine');
const MAX_CRASHES_EN_MINUTO  = 5;
const RESTART_DELAY_MS       = 50;

export class EngineSupervisor {
    private proc:        ChildProcess | null = null;
    private crashCount:  number  = 0;
    private windowStart: number  = Date.now();
    private running:     boolean = false;

    public start(): void {
        this.running = true;
        this.launch();
    }

    private launch(): void {
        if (!this.running) return;

        this.proc = spawn(ENGINE_BIN, [], {
            stdio: ['ignore', 'inherit', 'inherit'],
        });

        this.proc.on('exit', (code, signal) => {
            if (!this.running) return;
            console.error(`[Supervisor] Engine caído. code=${code} signal=${signal}`);
            this.registrarCrash();

            if (this.debeAbandonar()) {
                console.error(`[Supervisor] ${MAX_CRASHES_EN_MINUTO} crashes en 60s. Intervención manual requerida.`);
                this.running = false;
                process.exit(1);
                return;
            }

            setTimeout(() => this.launch(), RESTART_DELAY_MS);
        });

        console.log(`[Supervisor] Engine PID ${this.proc.pid} activo.`);
    }

    private registrarCrash(): void {
        const ahora = Date.now();
        if (ahora - this.windowStart > 60_000) {
            this.crashCount  = 0;
            this.windowStart = ahora;
        }
        this.crashCount++;
    }

    private debeAbandonar(): boolean {
        return this.crashCount >= MAX_CRASHES_EN_MINUTO;
    }

    public stop(): void {
        this.running = false;
        if (this.proc) {
            this.proc.kill('SIGTERM');
            this.proc = null;
        }
        console.log('[Supervisor] Engine detenido limpiamente.');
    }
}

export const engineSupervisor = new EngineSupervisor();
