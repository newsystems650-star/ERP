#include <iostream>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <cstdint>
#include <cstring> // Necesario para strncpy

// Contrato de datos blindado (Cero Padding)
#pragma pack(push, 1)
struct IntegralValidationRequest {
    uint64_t operation_id; // 8 bytes (Coincide con 'Q')
    double limit_a;        // 8 bytes (Coincide con 'd')
    double limit_b;        // 8 bytes (Coincide con 'd')
    double tolerance;      // 8 bytes (Coincide con 'd')
}; // TOTAL: 32 Bytes
#pragma pack(pop)

#define PATH_SOCKET "/tmp/motor_calculo.sock"

int main() {
    int server_fd, client_fd;
    struct sockaddr_un server_addr;

    server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    
    // Limpieza estricta
    unlink(PATH_SOCKET);

    // Configuración del socket Unix
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, PATH_SOCKET, sizeof(server_addr.sun_path) - 1);

    bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    listen(server_fd, 5); 

    std::cout << "[NicCore C++] Cerebro escuchando en binario puro...\n";

    while (true) {
        client_fd = accept(server_fd, NULL, NULL);
        if (client_fd < 0) continue;

        // Buffer exacto de 32 bytes
        char buffer[sizeof(IntegralValidationRequest)];
        
        // Lectura de los bytes enviados por Python
        ssize_t bytes_leidos = read(client_fd, buffer, sizeof(buffer));

        // Zero Trust: Verificación de longitud de binario
        if (bytes_leidos == sizeof(IntegralValidationRequest)) {
            
            // Casteo directo
            IntegralValidationRequest* req = reinterpret_cast<IntegralValidationRequest*>(buffer);
            
            if (req->operation_id == 5) {
                // AQUÍ VA LA LÓGICA DE TU CÁLCULO
                
                // Respuesta de Éxito (1 byte con valor 5 hexadecimal)
                char respuesta = 0x05; 
                write(client_fd, &respuesta, 1);
            } else {
                // Operación no reconocida
                char respuesta_error = 0x00;
                write(client_fd, &respuesta_error, 1);
            }
        } else {
            std::cerr << "Petición descartada: Tamaño de binario no coincide con la estructura.\n";
            char respuesta_error = 0x00;
            write(client_fd, &respuesta_error, 1);
        }

        close(client_fd);
    }
    
    close(server_fd);
    unlink(PATH_SOCKET);
    return 0;
}
