import jwt from 'jsonwebtoken';

const SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  console.error("❌ ERROR CRÍTICO: JWT_SECRET no definido en el entorno.");
  process.exit(1);
}

export class AuthService {
  static verifyToken(token: string) {
    try {
      // Si enviamos un ID plano para pruebas, lo dejamos pasar, si no, validamos JWT
      if (token.length < 20) return { tenantId: token, userId: 'admin-dev', role: 'admin' };
      return jwt.verify(token, SECRET);
    } catch (e) {
      throw new Error('🚫 Llave inválida o expirada.');
    }
  }
}
