import { AuthService } from './auth.service';

const tenants = [
  { id: 'NICCORE-MATRIZ', user: 'alonso-root', role: 'SUPER_ADMIN' },
  { id: 'MADERERA-NORTE', user: 'gerente-norte', role: 'MANAGER' },
  { id: 'CARPINTERIA-EL-SOL', user: 'operador-01', role: 'USER' }
];

console.log("🔑 --- GENERADOR DE LLAVES VORTEX --- 🔑\n");

tenants.forEach(t => {
  const token = AuthService.generateToken({ 
    tenantId: t.id, 
    userId: t.user, 
    role: t.role 
  });
  console.log(`🏢 Empresa: ${t.id}`);
  console.log(`👤 Usuario: ${t.user}`);
  console.log(`🎫 Token: Bearer ${token}\n`);
});
