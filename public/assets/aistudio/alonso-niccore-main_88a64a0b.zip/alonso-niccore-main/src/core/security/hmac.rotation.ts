import * as crypto from 'crypto';
import * as fs     from 'fs';
import * as path   from 'path';

const KEYS_PATH     = path.resolve('.niccore_keys.json');
const ROTATION_DAYS = 30;
const KEY_BYTES     = 32;

interface KeyEntry { key: string; rotatedAt: string; }
type KeyStore = Record<string, KeyEntry>;

function loadStore(): KeyStore {
    if (!fs.existsSync(KEYS_PATH)) return {};
    return JSON.parse(fs.readFileSync(KEYS_PATH, 'utf-8')) as KeyStore;
}

function saveStore(store: KeyStore): void {
    fs.writeFileSync(KEYS_PATH, JSON.stringify(store, null, 2), { mode: 0o600 });
}

function diasDesde(iso: string): number {
    return Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000);
}

export function rotarClave(nodeId: string): string {
    const store   = loadStore();
    const newKey  = crypto.randomBytes(KEY_BYTES).toString('hex');
    store[nodeId] = { key: newKey, rotatedAt: new Date().toISOString() };
    saveStore(store);
    console.log(`[HMACRotation] Clave rotada: ${nodeId}`);
    return newKey;
}

export function loadActiveKeys(): Record<string, string> {
    const store  = loadStore();
    const result: Record<string, string> = {};
    for (const [id, entry] of Object.entries(store)) result[id] = entry.key;
    return result;
}

export function runRotationCycle(): void {
    const store = loadStore();
    let rotadas = 0;
    for (const [nodeId, entry] of Object.entries(store)) {
        if (diasDesde(entry.rotatedAt) >= ROTATION_DAYS) {
            rotarClave(nodeId); rotadas++;
        }
    }
    if (rotadas > 0) {
        console.log(`[HMACRotation] ${rotadas} clave(s) rotadas.`);
        console.warn('[HMACRotation] Distribuir claves nuevas a nodos afectados.');
    }
}

export function startRotationScheduler(): void {
    runRotationCycle();
    setInterval(runRotationCycle, 86_400_000);
    console.log('[HMACRotation] Scheduler activo — verificación diaria.');
}
