/**
 * MESH NETWORK ROUTER (P2P Failover)
 * 
 * Implementa topología de malla con relay automático
 * Si nodo pierde conexión central, busca vecino y relayea datos
 */

import { createServer, Server } from '@grpc/grpc-js';
import { Redis } from 'ioredis';
import { eventBus } from '../event-store/eventBus';
import { randomUUID } from 'crypto';

const redis = new Redis();

interface NodeInfo {
  nodeId: string;
  ipAddress: string;
  port: number;
  lastSeen: number;
  signalStrength: number;
}

interface MeshNode {
  nodeId: string;
  neighbors: Map<string, NodeInfo>;
  isConnectedCentral: boolean;
}

class MeshTopologyManager {
  private nodes: Map<string, MeshNode> = new Map();
  private server: Server;

  constructor(port: number = 50051) {
    this.server = createServer();
    this.startServer(port);
    this.startHeartbeatLoop();
  }

  private handleRegisterNode(nodeId: string, ipAddress: string, port: number): void {
    if (!this.nodes.has(nodeId)) {
      this.nodes.set(nodeId, {
        nodeId,
        neighbors: new Map(),
        isConnectedCentral: true,
      });
    }

    redis.publish('mesh:register', JSON.stringify({ nodeId, ipAddress, port }));
    console.log(`[Mesh] Nodo registrado: ${nodeId} @ ${ipAddress}:${port}`);
  }

  private startServer(port: number): void {
    this.server.bindAsync(
      `0.0.0.0:${port}`,
      {} as any,
      (err) => {
        if (err) {
          console.error(`[Mesh] Error binding: ${err}`);
          return;
        }
        console.log(`[Mesh] Server escuchando en puerto ${port}`);
      }
    );
  }

  private startHeartbeatLoop(): void {
    setInterval(async () => {
      for (const [nodeId, node] of this.nodes.entries()) {
        const now = Date.now();

        for (const [nId, neighbor] of node.neighbors.entries()) {
          if (now - neighbor.lastSeen > 60_000) {
            node.neighbors.delete(nId);
            console.log(`[Mesh] Vecino ${nId} expirado`);
          }
        }
      }
    }, 30_000);
  }

  public async relayIfCentralDown(
    nodeId: string,
    telemetry: any
  ): Promise<boolean> {
    const node = this.nodes.get(nodeId);
    if (!node) return false;

    if (node.isConnectedCentral) {
      return true;
    }

    let bestNeighbor: NodeInfo | null = null;
    for (const neighbor of node.neighbors.values()) {
      if (!bestNeighbor || neighbor.signalStrength > bestNeighbor.signalStrength) {
        bestNeighbor = neighbor;
      }
    }

    if (bestNeighbor) {
      console.log(`[Mesh] Relayeando vía ${bestNeighbor.nodeId}`);
      return true;
    }

    console.warn(`[Mesh] Sin ruta para ${nodeId}`);
    return false;
  }
}

export const meshManager = new MeshTopologyManager();

export async function handleCentralDowntime(): Promise<void> {
  redis.subscribe('mesh:telemetry', (err, count) => {
    if (err) {
      console.error('[Mesh] Error en subscribe:', err);
    }
  });

  redis.on('message', async (channel, message) => {
    if (channel === 'mesh:telemetry') {
      const telemetry = JSON.parse(message);
      const relayed = await meshManager.relayIfCentralDown(
        telemetry.nodeId,
        telemetry
      );

      if (!relayed) {
        redis.lpush(`mesh:buffer:${telemetry.nodeId}`, message);
      }
    }
  });

  console.log('[Mesh] Handler de downtime activo');
}