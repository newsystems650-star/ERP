import { PrismaClient, ContractState, JsonContract } from '@prisma/client';
import { z } from 'zod';
import CryptoJS from 'crypto-js';

const ContractSchema = z.object({
  id: z.string(),
  totalValue: z.number(),
  state: z.nativeEnum(ContractState),
  // ... extensible
});

export class ContractsService {
  constructor(private prisma: PrismaClient) {}

  async createContract(payload: z.infer<typeof ContractSchema>): Promise<JsonContract> {
    const data = ContractSchema.parse(payload);
    const prevContracts = await this.prisma.jsonContract.findMany({ orderBy: { createdAt: 'desc' }, take: 1 });
    const prevHash = prevContracts[0]?.hash || '';

    const contractJson = JSON.stringify(data);
    const hash = CryptoJS.SHA256(contractJson + prevHash).toString();

    return this.prisma.jsonContract.create({
      data: {
        rootId: 'root1', // From auth
        payload: contractJson,
        prevHash,
        hash,
        totalValue: data.totalValue,
        state: data.state,
      },
    });
  }

  async lockContract(id: string, penaltyPct?: number) {
    const contract = await this.prisma.jsonContract.update({
      where: { id },
      data: { state: 'LOCKED' as ContractState, lockedAt: new Date(), penaltyPct: penaltyPct },
    });
    // Trigger Sentinel hash chain
    return contract;
  }

  async applyPenalty(contractId: string, pct: number) {
    // 10-30% auto split to sovereign/warchest
    const finSplit = await this.prisma.finSplit.create({
      data: {
        contractId,
        sovereignPct: 0.3, // Alonso
        evolIAPct: 0.1,
        opsPct: 0.4,
        warChestPct: 0.2,
        totalSplit: 1.0,
      },
    });
    return finSplit;
  }
}

