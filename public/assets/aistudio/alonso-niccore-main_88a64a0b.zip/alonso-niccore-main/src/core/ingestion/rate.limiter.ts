const VENTANA_MS   = 60_000;
const MAX_INTENTOS = 20;
const BLACKLIST_MS = 300_000;

interface EntradaIP {
    timestamps:     number[];
    bloqueadaHasta: number;
}

class RateLimiter {
    private tabla: Map<string, EntradaIP> = new Map();

    public estaLimitada(ip: string): boolean {
        const ahora   = Date.now();
        let   entrada = this.tabla.get(ip);

        if (!entrada) {
            entrada = { timestamps: [], bloqueadaHasta: 0 };
            this.tabla.set(ip, entrada);
        }

        if (ahora < entrada.bloqueadaHasta) return true;

        entrada.timestamps = entrada.timestamps.filter(
            (ts) => ahora - ts < VENTANA_MS
        );
        entrada.timestamps.push(ahora);

        if (entrada.timestamps.length > MAX_INTENTOS) {
            entrada.bloqueadaHasta = ahora + BLACKLIST_MS;
            console.warn(`[RateLimiter] IP bloqueada 5 min: ${ip}`);
            return true;
        }

        return false;
    }

    public purgarInactivas(): void {
        const ahora = Date.now();
        for (const [ip, entrada] of this.tabla.entries()) {
            const sinActividad    = entrada.timestamps.every((ts) => ahora - ts > VENTANA_MS);
            const blacklistExpiro = entrada.bloqueadaHasta < ahora;
            if (sinActividad && blacklistExpiro) this.tabla.delete(ip);
        }
    }
}

export const rateLimiter = new RateLimiter();

setInterval(() => rateLimiter.purgarInactivas(), 600_000);
