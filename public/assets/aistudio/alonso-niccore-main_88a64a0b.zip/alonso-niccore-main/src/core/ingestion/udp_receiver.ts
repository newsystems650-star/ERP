import * as dgram  from 'dgram';
import * as crypto from 'crypto';
import { randomUUID }  from 'crypto';
import { eventBus }    from '../event-store/eventBus';
import { rateLimiter } from './rate.limiter';

const UDP_PORT          = 41234;
const MAX_DATAGRAM_SIZE = 256;
const REPLAY_WINDOW_S   = 60;
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function loadNodeKeys(): Record<string, string> {
    const encoded = process.env.NIC_NODE_KEYS_B64?.trim();
    const raw = encoded
        ? Buffer.from(encoded, 'base64').toString('utf8').trim()
        : process.env.NIC_NODE_KEYS?.trim();
    if (!raw) return {};
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error('NIC_NODE_KEYS must be a JSON object mapping node IDs to shared secrets');
    }
    for (const [nodeId, secret] of Object.entries(parsed)) {
        if (!nodeId || typeof secret !== 'string' || secret.length < 16) {
            throw new Error('Each NIC_NODE_KEYS entry must have a node ID and a secret of at least 16 characters');
        }
    }
    return parsed as Record<string, string>;
}

function jitter(): Promise<void> {
    return new Promise((r) => setTimeout(r, Math.floor(Math.random() * 50)));
}

export class TelemetryTunnel {
    private server: dgram.Socket;
    private readonly nodeKeys: Record<string, string>;

    constructor() {
        this.nodeKeys = loadNodeKeys();
        if (Object.keys(this.nodeKeys).length === 0) {
            console.warn('[TelemetryTunnel] No node keys configured; incoming telemetry will be rejected.');
        }
        this.server = dgram.createSocket('udp4');
        this.initialize();
    }

    private initialize(): void {
        this.server.on('error', async (err) => {
            console.error(`[TelemetryTunnel] Fallo crítico:\n${err.stack}`);
            await this.stop();
        });

        this.server.on('message', (msg, rinfo) => {
            if (msg.length > MAX_DATAGRAM_SIZE)       return;
            if (rateLimiter.estaLimitada(rinfo.address)) return;
            void this.authenticateAndProcess(msg, rinfo.address);
        });

        this.server.on('listening', () => {
            const addr = this.server.address();
            console.log(`[TelemetryTunnel] UDP activo → ${addr.address}:${addr.port}`);
        });
    }

    public start(): void { this.server.bind(UDP_PORT, '0.0.0.0'); }

    public stop(): Promise<void> {
        return new Promise((resolve) => {
            try { this.server.close(() => resolve()); }
            catch { resolve(); }
        });
    }

    private async authenticateAndProcess(msg: Buffer, ip: string): Promise<void> {
        const fields = msg.toString('utf-8').trim().split('|');

        if (fields.length !== 7) { await jitter(); return; }

        const [nodeId, latStr, lonStr, velStr, tsStr, tripId, receivedHmac] = fields;

        const secretKey = this.nodeKeys[nodeId];
        if (!secretKey || !UUID_REGEX.test(tripId)) { await jitter(); return; }

        const lat = parseFloat(latStr);
        const lon = parseFloat(lonStr);
        const vel = parseFloat(velStr);
        const ts  = parseInt(tsStr, 10);

        if (
            isNaN(lat) || lat < -90  || lat > 90  ||
            isNaN(lon) || lon < -180 || lon > 180 ||
            isNaN(vel) || vel < 0    || vel > 300 ||
            isNaN(ts)  || receivedHmac.length !== 64
        ) { await jitter(); return; }

        const body     = `${nodeId}|${latStr}|${lonStr}|${velStr}|${tsStr}|${tripId}`;
        const expected = crypto.createHmac('sha256', secretKey).update(body).digest('hex');

        const bExp = Buffer.from(expected,     'utf-8');
        const bRec = Buffer.from(receivedHmac, 'utf-8');

        if (bExp.length !== bRec.length || !crypto.timingSafeEqual(bExp, bRec)) {
            await jitter();
            console.warn(`[TelemetryTunnel] HMAC inválido. Nodo: ${nodeId} | IP: ${ip}`);
            return;
        }

        if (Math.abs(Math.floor(Date.now() / 1000) - ts) > REPLAY_WINDOW_S) {
            await jitter(); return;
        }

        eventBus.publish({
            id:        randomUUID(),
            type:      'LOGISTICS_NODE_BREADCRUMB',
            timestamp: new Date().toISOString(),
            payload: {
                nodeId, tripId,
                latitud:               lat,
                longitud:              lon,
                velocidad_kmh:         vel,
                timestamp_dispositivo: ts,
            },
        });
    }
}
