#include <iostream>
#include <vector>
#include <string>
#include <unistd.h>

int main(int argc, char* argv[]) {
    if (argc < 2) return 1;
    std::cout << "--- [NIC-EDITOR] MODO BÜNKER ACTIVO ---" << std::endl;
    return 0;
}
