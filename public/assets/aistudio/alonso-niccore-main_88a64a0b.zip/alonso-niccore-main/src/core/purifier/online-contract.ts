import { z } from 'zod';

export const MercadoLibreOrderSchema = z.object({
  orderId: z.string(),
  sku: z.string(),
  quantity: z.number().positive(),
  totalPaid: z.number(),
  platform: z.literal('MERCADO_LIBRE')
});

// Purificación: El sistema solo acepta la orden si el stock en el Búnker es > 0
