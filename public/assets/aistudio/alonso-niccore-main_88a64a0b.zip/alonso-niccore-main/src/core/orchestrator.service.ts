import { spawn, ChildProcess } from 'node:child_process'; // [23]

/**
 * MetaOrchestrator: Garantiza la vida eterna del núcleo C++ (Ley 3).
 * Implementa resiliencia atómica y autocuración [1, 24].
 */
export class MetaOrchestrator {
  private static sonProcess: ChildProcess | null = null;

  static spawnSon(): void {
    // Inicia el binario como proceso hijo bajo vigilancia estricta [24, 25].
    this.sonProcess = spawn('./src/core/niccore_engine', [], {
      stdio: 'inherit',
      detached: false
    });

    console.log('🦾 Capa Madre: Hijo C++ operando en Prisión de Cristal.');

    // AUTO-HEALING: Reinicio instantáneo tras colapso o ataque [1, 26].
    this.sonProcess.on('exit', (code, signal) => {
      console.error(`⚠️ ALERTA: El núcleo colapsó (Código ${code}, Señal ${signal}). Reviviendo...`);
      // Espera de 50ms para evitar saturación de CPU en fallos críticos [1, 2].
      setTimeout(() => this.spawnSon(), 50); 
    });

    this.sonProcess.on('error', (err) => {
      console.error('❌ Error fatal en el puente del Hijo:', err.message);
    });
  }

  static killSon(): void {
    if (this.sonProcess) {
      this.sonProcess.kill('SIGTERM'); // Cierre elegante [27, 28].
      console.log('🛑 Hijo C++ retirado de forma segura.');
    }
  }
}
