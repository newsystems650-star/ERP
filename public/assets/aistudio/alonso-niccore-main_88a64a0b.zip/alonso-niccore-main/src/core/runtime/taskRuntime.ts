import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { eventBus } from '../event-store/eventBus';

export type TaskStatus = 'queued' | 'running' | 'succeeded' | 'failed';
export interface RuntimeTask {
  id: string;
  executor: string;
  input: Record<string, unknown>;
  status: TaskStatus;
  createdAt: string;
  updatedAt: string;
  attempts: number;
  result?: unknown;
  error?: string;
}
export type TaskExecutor = (input: Record<string, unknown>, taskId: string) => Promise<unknown>;

export class TaskRuntime {
  private tasks = new Map<string, RuntimeTask>();
  private executors = new Map<string, TaskExecutor>();
  private queue: string[] = [];
  private active = 0;
  private ready = false;

  constructor(
    private readonly journal = process.env.NICCORE_TASK_LOG || path.join(process.cwd(), 'data', 'tasks.jsonl'),
    private readonly concurrency = Number(process.env.NICCORE_TASK_CONCURRENCY || 2),
  ) {
    if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 16) {
      throw new RangeError('Task concurrency must be between 1 and 16');
    }
  }

  register(name: string, executor: TaskExecutor): this {
    if (!/^[a-z][a-z0-9._-]{1,63}$/.test(name)) throw new TypeError('Invalid executor name');
    if (this.executors.has(name)) throw new Error('Executor already registered');
    this.executors.set(name, executor);
    return this;
  }

  initialize(): this {
    if (this.ready) return this;
    fs.mkdirSync(path.dirname(this.journal), { recursive: true });
    if (fs.existsSync(this.journal)) {
      for (const [i, line] of fs.readFileSync(this.journal, 'utf8').split(/\r?\n/).entries()) {
        if (!line.trim()) continue;
        let task: RuntimeTask;
        try { task = JSON.parse(line) as RuntimeTask; }
        catch { throw new Error('Invalid task journal record at line ' + (i + 1)); }
        if (!task || typeof task.id !== 'string' || typeof task.executor !== 'string') {
          throw new Error('Invalid task journal record at line ' + (i + 1));
        }
        this.tasks.set(task.id, task);
      }
    }
    this.ready = true;
    for (const task of this.tasks.values()) {
      if (task.status === 'queued' || task.status === 'running') {
        task.status = 'queued';
        task.updatedAt = new Date().toISOString();
        this.persist(task);
        this.queue.push(task.id);
      }
    }
    this.event('RUNTIME_READY', { tasks: this.tasks.size, recovered: this.queue.length });
    this.pump();
    return this;
  }

  submit(executor: string, input: Record<string, unknown>): RuntimeTask {
    if (!this.ready) throw new Error('TaskRuntime is not initialized');
    if (!this.executors.has(executor)) throw new Error('Unknown executor: ' + executor);
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new TypeError('Input must be an object');
    if (Buffer.byteLength(JSON.stringify(input), 'utf8') > 65536) throw new RangeError('Input exceeds 64 KiB');
    const now = new Date().toISOString();
    const task: RuntimeTask = { id: randomUUID(), executor, input, status: 'queued', createdAt: now, updatedAt: now, attempts: 0 };
    this.tasks.set(task.id, task);
    this.persist(task);
    this.queue.push(task.id);
    this.event('TASK_QUEUED', { taskId: task.id, executor });
    this.pump();
    return { ...task };
  }

  get(id: string): RuntimeTask | undefined {
    const task = this.tasks.get(id);
    return task ? { ...task } : undefined;
  }

  list(limit = 50): RuntimeTask[] {
    return [...this.tasks.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, Math.max(1, Math.min(100, Math.floor(limit)))).map(task => ({ ...task }));
  }

  snapshot() {
    const state = { queued: 0, running: 0, succeeded: 0, failed: 0, concurrency: this.concurrency };
    for (const task of this.tasks.values()) state[task.status] += 1;
    return state;
  }

  private persist(task: RuntimeTask) {
    fs.appendFileSync(this.journal, JSON.stringify(task) + '\n', 'utf8');
  }

  private event(type: string, payload: Record<string, unknown>) {
    eventBus.publish({ type, source: 'task-runtime', payload, timestamp: new Date().toISOString() });
  }

  private pump() {
    while (this.ready && this.active < this.concurrency && this.queue.length) {
      const id = this.queue.shift();
      const task = id ? this.tasks.get(id) : undefined;
      if (!task || task.status !== 'queued') continue;
      this.active++;
      void this.execute(task).finally(() => { this.active--; this.pump(); });
    }
  }

  private async execute(task: RuntimeTask) {
    const executor = this.executors.get(task.executor);
    if (!executor) {
      task.status = 'failed'; task.error = 'Executor unavailable after restart';
      task.updatedAt = new Date().toISOString(); this.persist(task);
      this.event('TASK_FAILED', { taskId: task.id }); return;
    }
    task.status = 'running'; task.attempts++; task.updatedAt = new Date().toISOString();
    this.persist(task); this.event('TASK_STARTED', { taskId: task.id, executor: task.executor });
    try {
      const result = await executor(task.input, task.id);
      if (Buffer.byteLength(JSON.stringify(result), 'utf8') > 262144) throw new RangeError('Result exceeds 256 KiB');
      task.result = result; task.status = 'succeeded'; delete task.error;
      this.event('TASK_SUCCEEDED', { taskId: task.id, executor: task.executor });
    } catch (error) {
      task.status = 'failed';
      task.error = error instanceof Error ? error.message.slice(0, 1000) : 'Executor failed';
      this.event('TASK_FAILED', { taskId: task.id, executor: task.executor, reason: task.error });
    }
    task.updatedAt = new Date().toISOString();
    this.persist(task);
  }
}

export const taskRuntime = new TaskRuntime();
