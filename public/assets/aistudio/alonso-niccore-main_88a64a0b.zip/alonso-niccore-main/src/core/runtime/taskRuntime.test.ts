import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { TaskRuntime } from './taskRuntime';

const waitUntil = async (check: () => boolean, timeoutMs = 2000) => {
  const start = Date.now();
  while (!check()) {
    if (Date.now() - start > timeoutMs) throw new Error('Timed out waiting for task completion');
    await new Promise(resolve => setTimeout(resolve, 10));
  }
};

test('executes a registered task and restores its last persisted state', async () => {
  const directory = mkdtempSync(path.join(tmpdir(), 'niccore-runtime-'));
  const journal = path.join(directory, 'tasks.jsonl');
  try {
    const runtime = new TaskRuntime(journal, 1);
    runtime.register('test.echo', async input => ({ received: input.value })).initialize();
    const submitted = runtime.submit('test.echo', { value: 'hello' });
    await waitUntil(() => runtime.get(submitted.id)?.status === 'succeeded');
    assert.deepEqual(runtime.get(submitted.id)?.result, { received: 'hello' });

    const restored = new TaskRuntime(journal, 1);
    restored.register('test.echo', async input => ({ received: input.value })).initialize();
    assert.equal(restored.get(submitted.id)?.status, 'succeeded');
    assert.deepEqual(restored.get(submitted.id)?.result, { received: 'hello' });
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test('rejects an executor that has not been registered', () => {
  const directory = mkdtempSync(path.join(tmpdir(), 'niccore-runtime-'));
  try {
    const runtime = new TaskRuntime(path.join(directory, 'tasks.jsonl'), 1).initialize();
    assert.throws(() => runtime.submit('not.registered', {}), /Unknown executor/);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});
