#include <napi.h>

Napi::Value CalculateWood(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    
    double width = info[0].As<Napi::Number>().DoubleValue();
    double thickness = info[1].As<Napi::Number>().DoubleValue();
    double length = info[2].As<Napi::Number>().DoubleValue();
    int pieces = info[3].As<Napi::Number>().Int32Value();
    double costPerFoot = info[4].As<Napi::Number>().DoubleValue();
    double margin = info[5].As<Napi::Number>().DoubleValue();

    // Lógica Inyectada de Alto Valor
    double feetPerPiece = (width * thickness * length) / 144.0;
    double totalFeet = feetPerPiece * pieces;
    double costTotal = totalFeet * costPerFoot;
    double pricePerPiece = (costTotal / pieces) * (1 + (margin / 100.0));
    double profitTotal = (pricePerPiece * pieces) - costTotal;

    Napi::Object res = Napi::Object::New(env);
    res.Set("feetPerPiece", feetPerPiece);
    res.Set("totalFeet", totalFeet);
    res.Set("pricePerPiece", pricePerPiece);
    res.Set("profitTotal", profitTotal);
    return res;
}

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports.Set(Napi::String::New(env, "calculate"), Napi::Function::New(env, CalculateWood));
    return exports;
}

NODE_API_MODULE(vortex_engine, Init)