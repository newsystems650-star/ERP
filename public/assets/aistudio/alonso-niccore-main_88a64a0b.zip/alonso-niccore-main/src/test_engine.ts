import { WoodTestSchema } from './shared/contracts/wood_test.contract';
import { WoodCalculatorService } from './services/wood_calculator.service';

async function runTest() {
  console.log('🚀 Iniciando Prueba de Transmisión IPC (Bloque 2)...');

  try {
    const primeraTabla = WoodTestSchema.parse({
      type: 'PINO_1RA',
      thickness: 1,
      width: 6,
      length: 8,
      cost: 150 // Inversión simulada en pesos/dólares
    });

    console.log('✅ Contrato validado. Carga enviada al Músculo C++...');

    // Esperamos la respuesta exacta del motor
    const resultado = await WoodCalculatorService.calculateRealYield(primeraTabla, 5);
    
    // --- LÓGICA DE NEGOCIO (NODE.JS) ---
    const costoTotal = primeraTabla.cost;
    const ptOriginal = resultado.pieTablarOriginal;
    const ptReal = resultado.pieTablarReal;

    // 1. Lo que la competencia CREE que le cuesta cada PT
    const costoFalsoPorPt = costoTotal / ptOriginal; 

    // 2. Lo que REALMENTE cuesta cada PT en NicCore
    const costoRealPorPt = costoTotal / ptReal;

    // 3. El Patrón exige un 35% de margen de utilidad libre de polvo y paja
    const margenDeseado = 0.35;
    
    // Fórmula de precio de venta: Costo / (1 - Margen)
    const precioVentaSugerido = costoRealPorPt / (1 - margenDeseado);
    const gananciaNeta = (precioVentaSugerido - costoRealPorPt) * ptReal;

    console.log('\n=========================================');
    console.log('🎯 RESULTADOS FINANCIEROS NICCORE:');
    console.log('=========================================');
    console.log(`🪵  Pie Tablar Teórico: ${ptOriginal.toFixed(4)} PT`);
    console.log(`🔪  Pie Tablar Real:    ${ptReal.toFixed(4)} PT (Tras merma)`);
    console.log('-----------------------------------------');
    console.log(`📉  Costo Falso (Competencia): $${costoFalsoPorPt.toFixed(2)} / PT`);
    console.log(`📈  Costo Real (NicCore):      $${costoRealPorPt.toFixed(2)} / PT`);
    console.log(`💰  Precio Venta Sugerido:     $${precioVentaSugerido.toFixed(2)} / PT (Margen 35%)`);
    console.log(`💵  Ganancia Neta por Tabla:   $${gananciaNeta.toFixed(2)}`);
    console.log('=========================================\n');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Falló la prueba:', error);
    process.exit(1);
  }
}

runTest();
