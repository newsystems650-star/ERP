import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError, AppError } from '../../../shared/errors/AppError'

// Catálogo básico de uso de CFDI
export const USOS_CFDI = [
  { key: 'G01', label: 'Adquisición de mercancias' },
  { key: 'G02', label: 'Devoluciones, descuentos o bonificaciones' },
  { key: 'G03', label: 'Gastos en general' },
  { key: 'I01', label: 'Construcciones' },
  { key: 'I03', label: 'Equipo de transporte' },
  { key: 'I04', label: 'Equipo de computo y accesorios' },
  { key: 'S01', label: 'Sin efectos fiscales' },
]

export const REGIMENES = [
  { key: '601', label: 'General de Ley Personas Morales' },
  { key: '612', label: 'Personas Físicas con Actividades Empresariales' },
  { key: '616', label: 'Sin obligaciones fiscales' },
  { key: '621', label: 'Incorporación Fiscal' },
  { key: '625', label: 'Régimen de las actividades empresariales con ingresos a través de plataformas' },
  { key: '626', label: 'Régimen Simplificado de Confianza' },
]

export const CLAVES_UNIDAD = [
  { key: 'H87', label: 'Pieza' },
  { key: 'MTR', label: 'Metro' },
  { key: 'MTK', label: 'Metro cuadrado' },
  { key: 'MTQ', label: 'Metro cúbico' },
  { key: 'KGM', label: 'Kilogramo' },
  { key: 'LTR', label: 'Litro' },
]

// Generar folio incremental
async function nextFolio(type: string): Promise<number> {
  const last = await prisma.invoice.findFirst({
    where: { type: type as any },
    orderBy: { createdAt: 'desc' },
    select: { folio: true },
  })
  const lastNum = last?.folio ? parseInt(last.folio) : 0
  return lastNum + 1
}

export async function createSaleInvoice(data: {
  ticketId: string
  customerId?: string
  rfcReceptor: string
  nombreReceptor: string
  usoCFDI: string
  regimenFiscal: string
  applyTax: boolean
  userId: string
}) {
  const ticket = await prisma.ticket.findUnique({
    where: { id: data.ticketId },
    include: { items: { include: { product: true } }, invoice: true },
  })
  if (!ticket) throw new NotFoundError('Ticket')
  if (ticket.status !== 'CONFIRMED') throw new AppError('Solo se puede facturar tickets confirmados')
  if (ticket.invoice) throw new AppError('Este ticket ya tiene una factura')

  const subtotal = Number(ticket.total)
  const tax = data.applyTax ? subtotal * 0.16 : 0
  const total = subtotal + tax
  const folio = await nextFolio('SALE')

  return prisma.invoice.create({
    data: {
      type: 'SALE',
      folio: folio.toString().padStart(6, '0'),
      series: 'A',
      status: 'DRAFT',
      rfcReceptor: data.rfcReceptor,
      nombreReceptor: data.nombreReceptor,
      usoCFDI: data.usoCFDI,
      regimenFiscal: data.regimenFiscal,
      subtotal,
      tax,
      total,
      ticketId: data.ticketId,
      customerId: data.customerId,
      userId: data.userId,
      items: {
        create: ticket.items.map(i => ({
          description: i.product.name,
          quantity: Number(i.quantity),
          unitPrice: Number(i.unitPrice),
          subtotal: Number(i.subtotal),
          unit: i.unit,
          claveUnit: 'H87',
          claveProd: '14111701',
        })),
      },
    },
    include: {
      items: true,
      ticket: { select: { code: true } },
      customer: { select: { name: true } },
    },
  })
}

export async function createPurchaseInvoice(data: {
  supplierId: string
  rfcEmisor: string
  folio: string
  subtotal: number
  applyTax: boolean
  notes?: string
  userId: string
  items: { description: string; quantity: number; unitPrice: number; unit: string }[]
}) {
  const tax = data.applyTax ? data.subtotal * 0.16 : 0
  const total = data.subtotal + tax
  const folioInterno = await nextFolio('PURCHASE')

  return prisma.$transaction(async (tx) => {
    const invoice = await tx.invoice.create({
      data: {
        type: 'PURCHASE',
        folio: data.folio,
        series: 'C',
        status: 'DRAFT',
        rfcEmisor: data.rfcEmisor,
        subtotal: data.subtotal,
        tax,
        total,
        notes: data.notes,
        supplierId: data.supplierId,
        userId: data.userId,
        items: {
          create: data.items.map(i => ({
            description: i.description,
            quantity: i.quantity,
            unitPrice: i.unitPrice,
            subtotal: i.quantity * i.unitPrice,
            unit: i.unit,
          })),
        },
      },
      include: { items: true, supplier: { select: { name: true } } },
    })

    // Registrar como gasto contable
    await tx.expense.create({
      data: {
        type: 'SUPPLIER',
        category: 'Compra de madera',
        description: `Factura ${data.folio} — ${invoice.supplier?.name}`,
        amount: data.subtotal,
        tax,
        total,
        reference: data.folio,
        userId: data.userId,
      },
    })

    // Subir stock de los items
    for (const item of data.items) {
      const product = await tx.product.findFirst({
        where: { name: { contains: item.description, mode: 'insensitive' } },
      })
      if (product) {
        await tx.stock.upsert({
          where: { productId: product.id },
          update: { quantity: { increment: item.quantity }, updatedAt: new Date() },
          create: { productId: product.id, quantity: item.quantity, updatedAt: new Date() },
        })
      }
    }

    return invoice
  })
}

export async function getInvoices(filters: {
  type?: string
  status?: string
  page?: number
  limit?: number
}) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit
  const where: any = {}
  if (filters.type) where.type = filters.type
  if (filters.status) where.status = filters.status

  const [data, total] = await prisma.$transaction([
    prisma.invoice.findMany({
      where, skip, take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { name: true } },
        customer: { select: { name: true, rfc: true } },
        supplier: { select: { name: true, rfc: true } },
        ticket: { select: { code: true } },
      },
    }),
    prisma.invoice.count({ where }),
  ])

  return { data, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}

export async function getInvoiceById(id: string) {
  const inv = await prisma.invoice.findUnique({
    where: { id },
    include: {
      items: true,
      user: { select: { name: true } },
      customer: { select: { name: true, rfc: true, address: true } },
      supplier: { select: { name: true, rfc: true, address: true } },
      ticket: { select: { code: true, total: true } },
    },
  })
  if (!inv) throw new NotFoundError('Factura')
  return inv
}

// Placeholder para cuando se conecte el PAC
export async function stampInvoice(id: string) {
  const inv = await prisma.invoice.findUnique({ where: { id } })
  if (!inv) throw new NotFoundError('Factura')
  if (inv.status === 'STAMPED') throw new AppError('Esta factura ya fue timbrada')

  // TODO: Conectar PAC aquí (Finkok, SW Sapien, etc.)
  // const xml = generateXML(inv)
  // const result = await pac.stamp(xml, csd)
  // await prisma.invoice.update({ where: { id }, data: { uuid: result.uuid, xmlContent: result.xml, status: 'STAMPED' } })

  throw new AppError('Timbrado no configurado. Contacta al administrador para configurar el PAC.', 501, 'PAC_NOT_CONFIGURED')
}
