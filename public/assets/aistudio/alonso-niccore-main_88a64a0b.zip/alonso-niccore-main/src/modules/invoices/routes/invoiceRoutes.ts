import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import {
  createSaleInvoice, createPurchaseInvoice,
  getInvoices, getInvoiceById, stampInvoice,
  USOS_CFDI, REGIMENES, CLAVES_UNIDAD,
} from '../services/invoiceService'

const router = Router()
router.use(authenticate)

// Catálogos SAT
router.get('/catalogos', (req, res) => {
  res.json({ usosCFDI: USOS_CFDI, regimenes: REGIMENES, clavesUnidad: CLAVES_UNIDAD })
})

router.get('/', async (req, res) => {
  const result = await getInvoices({
    type: req.query.type as string,
    status: req.query.status as string,
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 20,
  })
  res.json(result)
})

router.get('/:id', async (req, res) => {
  const invoice = await getInvoiceById(req.params.id)
  res.json({ invoice })
})

// Factura de venta (desde ticket)
router.post('/venta', authorize('ADMIN', 'MANAGER', 'OPERATOR'), async (req: AuthRequest, res) => {
  const schema = z.object({
    ticketId: z.string(),
    customerId: z.string().optional(),
    rfcReceptor: z.string().min(12).max(13),
    nombreReceptor: z.string().min(2),
    usoCFDI: z.string().default('G03'),
    regimenFiscal: z.string().default('616'),
    applyTax: z.boolean().default(true),
  })
  const data = schema.parse(req.body)
  const invoice = await createSaleInvoice({ ...data, userId: req.user!.id })
  res.status(201).json({ invoice })
})

// Factura de compra (proveedor)
router.post('/compra', authorize('ADMIN', 'MANAGER'), async (req: AuthRequest, res) => {
  const schema = z.object({
    supplierId: z.string(),
    rfcEmisor: z.string().min(12).max(13),
    folio: z.string().min(1),
    subtotal: z.number().positive(),
    applyTax: z.boolean().default(true),
    notes: z.string().optional(),
    items: z.array(z.object({
      description: z.string(),
      quantity: z.number().positive(),
      unitPrice: z.number().positive(),
      unit: z.string(),
    })).min(1),
  })
  const data = schema.parse(req.body)
  const invoice = await createPurchaseInvoice({ ...data, userId: req.user!.id })
  res.status(201).json({ invoice })
})

// Timbrar (placeholder PAC)
router.post('/:id/timbrar', authorize('ADMIN'), async (req, res) => {
  const invoice = await stampInvoice(req.params.id)
  res.json({ invoice })
})

export default router
