import { Router } from 'express'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import { createProductSchema, updateProductSchema } from '../validators/productValidator'
import {
  createProduct,
  getProducts,
  getProductById,
  updateProduct,
  deactivateProduct,
} from '../services/productService'

const router = Router()
router.use(authenticate)

router.get('/', async (req, res) => {
  const result = await getProducts({
    search: req.query.search as string,
    unit: req.query.unit as string,
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 20,
  })
  res.json(result)
})

router.get('/:id', async (req, res) => {
  const product = await getProductById(req.params.id)
  res.json({ product })
})

router.post('/', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const data = createProductSchema.parse(req.body)
  const product = await createProduct(data)
  res.status(201).json({ product })
})

router.put('/:id', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const data = updateProductSchema.parse(req.body)
  const product = await updateProduct(req.params.id, data)
  res.json({ product })
})

router.delete('/:id', authorize('ADMIN'), async (req, res) => {
  const product = await deactivateProduct(req.params.id)
  res.json({ product })
})

export default router
