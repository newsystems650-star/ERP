import { z } from 'zod'

export const createProductSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  sku: z.string().min(1).toUpperCase(),
  unit: z.enum(['M2', 'M3', 'KG', 'LITER', 'LINEAR_M', 'FEET', 'INCH', 'PIECE']),
  price: z.number().positive(),
  initialStock: z.number().nonnegative().optional().default(0),
  minAlert: z.number().nonnegative().optional(),
})

export const updateProductSchema = createProductSchema.partial().omit({ initialStock: true })

export type CreateProductInput = z.infer<typeof createProductSchema>
export type UpdateProductInput = z.infer<typeof updateProductSchema>
