import { prisma } from '../../../infrastructure/database/prisma'
import { ConflictError, NotFoundError } from '../../../shared/errors/AppError'
import { CreateProductInput, UpdateProductInput } from '../validators/productValidator'

export async function createProduct(data: CreateProductInput) {
  const exists = await prisma.product.findUnique({ where: { sku: data.sku } })
  if (exists) throw new ConflictError(`El SKU "${data.sku}" ya existe`)

  const product = await prisma.$transaction(async (tx) => {
    const created = await tx.product.create({
      data: {
        name: data.name,
        description: data.description,
        sku: data.sku,
        unit: data.unit,
        price: data.price,
      },
    })

    await tx.stock.create({
      data: {
        productId: created.id,
        quantity: data.initialStock ?? 0,
        minAlert: data.minAlert ?? null,
        updatedAt: new Date(),
      },
    })

    return created
  })

  return getProductById(product.id)
}

export async function getProducts(filters: {
  search?: string
  unit?: string
  active?: boolean
  page?: number
  limit?: number
}) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit

  const where: any = { active: filters.active ?? true }
  if (filters.unit) where.unit = filters.unit
  if (filters.search) {
    where.OR = [
      { name: { contains: filters.search, mode: 'insensitive' } },
      { sku: { contains: filters.search, mode: 'insensitive' } },
    ]
  }

  const [products, total] = await prisma.$transaction([
    prisma.product.findMany({
      where,
      skip,
      take: limit,
      orderBy: { name: 'asc' },
      include: { stock: true },
    }),
    prisma.product.count({ where }),
  ])

  return {
    data: products,
    meta: { page, limit, total, pages: Math.ceil(total / limit) },
  }
}

export async function getProductById(id: string) {
  const product = await prisma.product.findUnique({
    where: { id },
    include: { stock: true },
  })
  if (!product) throw new NotFoundError('Producto')
  return product
}

export async function updateProduct(id: string, data: UpdateProductInput) {
  await getProductById(id)
  return prisma.product.update({
    where: { id },
    data,
    include: { stock: true },
  })
}

export async function deactivateProduct(id: string) {
  await getProductById(id)
  return prisma.product.update({
    where: { id },
    data: { active: false },
    select: { id: true, name: true, active: true },
  })
}
