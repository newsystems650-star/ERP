// src/modules/wood-inventory/wood.service.ts
import { EventStore } from '../../core/event-store/eventStore';
import { WoodPhysicalParams, VortexCalculationResult } from './types';

// El motor nativo debe ser tratado como una caja negra tipada
const vortex = require('../../../build/Release/vortex_engine');

export class WoodInventoryService {
  static async executeFullSale(data: WoodPhysicalParams): Promise<{ success: boolean; data: VortexCalculationResult; auditId: string }> {
    
    // 1. CÁLCULO C++ (Invocación con contrato estricto)
    const calculation: VortexCalculationResult = vortex.calculate(
      data.widthMm, 
      data.thicknessMm, 
      data.lengthMm,
      data.totalPieces, 
      data.baseHumidity, 
      data.shrinkageFactor,
      data.costPerFoot, 
      data.marginPercent
    );

    // 2. PERSISTENCIA INMUTABLE
    const event = await EventStore.append('WOOD_INVENTORY_CALCULATED', {
      input: data,
      output: calculation
    });

    return { 
      success: true, 
      data: calculation, 
      auditId: event.id 
    };
  }
}
