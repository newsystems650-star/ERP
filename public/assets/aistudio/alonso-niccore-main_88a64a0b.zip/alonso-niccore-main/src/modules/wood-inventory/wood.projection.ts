import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export class WoodProjection {
  static async handle(event: any) {
    const { tenantId, payload } = event;
    
    console.log("📈 [PROJECTION] Ajustando stock físico...");

    // En un flujo real, aquí buscaríamos por SKU. 
    // Por ahora, actualizamos el resumen global del Tenant.
    await prisma.woodSummary.upsert({
      where: { tenantId },
      update: {
        totalFeet: { increment: payload.totalFeet },
        accumulatedProfit: { increment: payload.profitTotal }
      },
      create: {
        tenantId,
        totalFeet: payload.totalFeet,
        accumulatedProfit: payload.profitTotal
      }
    });
    
    console.log("✅ Stock y Ganancias actualizadas en DB para " + tenantId);
  }
}
