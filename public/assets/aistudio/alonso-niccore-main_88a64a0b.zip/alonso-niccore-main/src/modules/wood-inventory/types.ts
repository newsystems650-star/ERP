// src/modules/wood-inventory/types.ts

export interface WoodPhysicalParams {
  widthMm: number;
  thicknessMm: number;
  lengthMm: number;
  totalPieces: number;
  baseHumidity: number;
  shrinkageFactor: number;
  costPerFoot: number;
  marginPercent: number;
}

export interface VortexCalculationResult {
  netVolume: number;
  adjustedVolume: number;
  totalCost: number;
  salePrice: number;
  integrityHash: string;
}
