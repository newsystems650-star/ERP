import Stripe from 'stripe';
import { PrismaClient, JsonContract } from '@prisma/client';
import { ContractsService } from '../../core/contracts.service';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' });

export class NiccOportunidadService {
  constructor(private prisma: PrismaClient, private contracts: ContractsService) {}

  async createLoan(contractId: string, amount: number) {
    const contract = await this.prisma.jsonContract.findUnique({ where: { id: contractId } });
    if (contract?.state !== 'LOCKED') throw new Error('🚫 Solo LOCKED contracts.');

    // Préstamo prendario
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100,
      currency: 'mxn',
      metadata: { contractId },
    });

    // Embargo auto >30d via BullMQ job
    return { paymentIntent, contract };
  }

  async embargoAsset(contractId: string) {
    // Auto embargo assets if overdue
    const finSplit = await this.prisma.finSplit.create({
      data: {
        contractId,
        sovereignPct: 0.3, // Alonso take
        // ...
      },
    });
    return finSplit;
  }
}

