// Sniper-Arbitrage: Buy low Durango, sell high CDMX
import { PrismaClient } from '@prisma/client';
import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';

const PROTO_PATH = '../../protos/nic-os.proto';
const vortexPackageDefinition = protoLoader.loadSync(PROTO_PATH);
const vortexProto = grpc.loadPackageDefinition(vortexPackageDefinition).nic_os as any;

export class SniperArbitrageService {
  constructor(private prisma: PrismaClient) {}

  async optimizeConvoy(nodes: string[], trucks: number) {
    const client = new vortexProto.VortexService('localhost:50051', grpc.credentials.createInsecure());
    const request = { nodes, trucks };

    return new Promise((resolve, reject) => {
      client.OptimizeRoute(request, (error: any, response: any) => {
        if (error) reject(error);
        resolve(response);
      });
    });
  }

  async arbitrageOpportunity(origin: string, dest: string) {
    const route = await this.optimizeConvoy([origin, dest], 15) as any;
    if (route.empty_leg) {
      // Buy low, sell high, 0 cost log
      console.log(`💰 Empty-Leg: ${origin} -> ${dest}, cost: ${route.cost}`);
    }
    return route;
  }
}

