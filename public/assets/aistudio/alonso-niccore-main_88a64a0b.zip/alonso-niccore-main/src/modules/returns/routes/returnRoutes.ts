import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import { createReturn, approveReturn, getReturns } from '../services/returnService'

const router = Router()
router.use(authenticate)

router.get('/', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const result = await getReturns({
    status: req.query.status as string,
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 20,
  })
  res.json(result)
})

router.post('/', async (req: AuthRequest, res) => {
  const schema = z.object({
    ticketId: z.string(),
    reason: z.string().min(1),
    refundType: z.enum(['CASH', 'CREDIT', 'EXCHANGE']),
    notes: z.string().optional(),
    items: z.array(z.object({
      productId: z.string(),
      quantity: z.number().positive(),
      reason: z.string().optional(),
      backToStock: z.boolean().default(true),
    })).min(1),
  })
  const data = schema.parse(req.body)
  const ret = await createReturn({ ...data, userId: req.user!.id })
  res.status(201).json({ return: ret })
})

router.patch('/:id/approve', authorize('ADMIN', 'MANAGER'), async (req: AuthRequest, res) => {
  const ret = await approveReturn(req.params.id, req.user!.id)
  res.json({ return: ret })
})

export default router
