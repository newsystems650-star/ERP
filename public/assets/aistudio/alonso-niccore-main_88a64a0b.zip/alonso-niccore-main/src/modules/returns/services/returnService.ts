import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError, AppError } from '../../../shared/errors/AppError'

function generateCode(): string {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '')
  const rand = Math.floor(Math.random() * 9999).toString().padStart(4, '0')
  return `DEV-${date}-${rand}`
}

export async function createReturn(data: {
  ticketId: string
  reason: string
  refundType: 'CASH' | 'CREDIT' | 'EXCHANGE'
  notes?: string
  userId: string
  items: {
    productId: string
    quantity: number
    reason?: string
    backToStock: boolean
  }[]
}) {
  const ticket = await prisma.ticket.findUnique({
    where: { id: data.ticketId },
    include: { items: true },
  })
  if (!ticket) throw new NotFoundError('Ticket')
  if (ticket.status !== 'CONFIRMED') throw new AppError('Solo se pueden hacer devoluciones de tickets confirmados')

  const refundAmount = data.items.reduce((sum, item) => {
    const ticketItem = ticket.items.find(i => i.productId === item.productId)
    return sum + (Number(ticketItem?.unitPrice || 0) * item.quantity)
  }, 0)

  return prisma.$transaction(async (tx) => {
    const ret = await tx.return.create({
      data: {
        code: generateCode(),
        reason: data.reason,
        status: 'PENDING',
        refundType: data.refundType,
        refundAmount,
        notes: data.notes,
        ticketId: data.ticketId,
        userId: data.userId,
        items: {
          create: data.items.map(i => ({
            quantity: i.quantity,
            reason: i.reason,
            backToStock: i.backToStock,
            productId: i.productId,
          })),
        },
      },
      include: {
        items: { include: { product: { select: { name: true, sku: true } } } },
        ticket: { select: { code: true } },
      },
    })

    await tx.auditLog.create({
      data: {
        action: 'RETURN_CREATED',
        entity: 'Return',
        entityId: ret.id,
        after: { ticketId: data.ticketId, refundAmount, reason: data.reason },
        userId: data.userId,
        ticketId: data.ticketId,
      },
    })

    return ret
  })
}

export async function approveReturn(returnId: string, userId: string) {
  const ret = await prisma.return.findUnique({
    where: { id: returnId },
    include: { items: true },
  })
  if (!ret) throw new NotFoundError('Devolución')
  if (ret.status !== 'PENDING') throw new AppError('Solo se pueden aprobar devoluciones pendientes')

  return prisma.$transaction(async (tx) => {
    const updated = await tx.return.update({
      where: { id: returnId },
      data: { status: 'APPROVED' },
    })

    // Regresar stock de items que lo requieren
    for (const item of ret.items) {
      if (item.backToStock) {
        await tx.stock.upsert({
          where: { productId: item.productId },
          update: { quantity: { increment: Number(item.quantity) }, updatedAt: new Date() },
          create: { productId: item.productId, quantity: item.quantity, updatedAt: new Date() },
        })
      }
    }

    await tx.auditLog.create({
      data: {
        action: 'RETURN_APPROVED',
        entity: 'Return',
        entityId: returnId,
        before: { status: 'PENDING' },
        after: { status: 'APPROVED' },
        userId,
        ticketId: ret.ticketId,
      },
    })

    return updated
  })
}

export async function getReturns(filters: { status?: string; page?: number; limit?: number }) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit
  const where: any = {}
  if (filters.status) where.status = filters.status

  const [data, total] = await prisma.$transaction([
    prisma.return.findMany({
      where, skip, take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        ticket: { select: { code: true } },
        user: { select: { name: true } },
        items: { include: { product: { select: { name: true } } } },
      },
    }),
    prisma.return.count({ where }),
  ])

  return { data, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}
