import { Router } from 'express'
import { authenticate, authorize } from '../../auth/middleware/authenticate'
import { getStockWithReservations, cleanExpiredReservations, getAvailableStock } from '../services/reservationService'

const router = Router()
router.use(authenticate)

router.get('/', async (req, res) => {
  const data = await getStockWithReservations()
  res.json({ data })
})

router.get('/available/:productId', async (req, res) => {
  const available = await getAvailableStock(req.params.productId)
  res.json({ available })
})

router.post('/clean', authorize('ADMIN'), async (req, res) => {
  const count = await cleanExpiredReservations()
  res.json({ cleaned: count })
})

export default router
