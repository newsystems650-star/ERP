import { prisma } from '../../../infrastructure/database/prisma'
import { AppError, InsufficientStockError } from '../../../shared/errors/AppError'

const RESERVATION_TTL_MINUTES = 30

export async function getAvailableStock(productId: string): Promise<number> {
  const stock = await prisma.stock.findUnique({ where: { productId } })
  if (!stock) return 0

  const reserved = await prisma.stockReservation.aggregate({
    where: { productId, status: 'ACTIVE', expiresAt: { gt: new Date() } },
    _sum: { quantity: true },
  })

  const available = Number(stock.quantity) - Number(reserved._sum.quantity || 0)
  return Math.max(0, available)
}

export async function reserveStock(data: {
  productId: string
  quantity: number
  ticketId?: string
  minutesTTL?: number
}): Promise<void> {
  const available = await getAvailableStock(data.productId)

  if (available < data.quantity) {
    const product = await prisma.product.findUnique({
      where: { id: data.productId },
      select: { name: true },
    })
    throw new InsufficientStockError(
      product?.name || data.productId,
      available,
      data.quantity
    )
  }

  const expiresAt = new Date()
  expiresAt.setMinutes(expiresAt.getMinutes() + (data.minutesTTL || RESERVATION_TTL_MINUTES))

  await prisma.stockReservation.create({
    data: {
      productId: data.productId,
      quantity: data.quantity,
      status: 'ACTIVE',
      expiresAt,
      ticketId: data.ticketId,
    },
  })
}

export async function confirmReservations(ticketId: string): Promise<void> {
  await prisma.stockReservation.updateMany({
    where: { ticketId, status: 'ACTIVE' },
    data: { status: 'CONFIRMED' },
  })
}

export async function releaseReservations(ticketId: string): Promise<void> {
  await prisma.stockReservation.updateMany({
    where: { ticketId, status: 'ACTIVE' },
    data: { status: 'RELEASED' },
  })
}

export async function cleanExpiredReservations(): Promise<number> {
  const result = await prisma.stockReservation.updateMany({
    where: { status: 'ACTIVE', expiresAt: { lt: new Date() } },
    data: { status: 'RELEASED' },
  })
  return result.count
}

export async function getStockWithReservations() {
  const stocks = await prisma.stock.findMany({
    include: { product: true },
    orderBy: { product: { name: 'asc' } },
  })

  const result = await Promise.all(
    stocks.map(async (s) => {
      const available = await getAvailableStock(s.productId)
      const reserved = Number(s.quantity) - available
      return {
        ...s,
        available,
        reserved,
        alert: s.minAlert ? available <= Number(s.minAlert) : false,
      }
    })
  )

  return result
}
