import { cmToCommercialInch, cmToCommercialFeet, cmToThicknessInch, calcBoardFeet } from './woodEntryService'

const STANDARD_WIDTHS_CM    = [5, 7.5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 60]
const STANDARD_LENGTHS_CM   = [122, 152, 183, 244, 305, 366]
const STANDARD_THICKNESS_CM = [1.25, 1.9, 2.5, 3.8, 5, 6.3, 7.5]

export function getEquivalenceTable() {
  const widths = STANDARD_WIDTHS_CM.map(cm => ({
    cm, inches: cmToCommercialInch(cm),
    label: `${cm}cm = ${cmToCommercialInch(cm)}"`,
  }))

  const lengths = STANDARD_LENGTHS_CM.map(cm => ({
    cm, feet: cmToCommercialFeet(cm),
    label: `${cm}cm = ${cmToCommercialFeet(cm)}'`,
  }))

  const thicknesses = STANDARD_THICKNESS_CM.map(cm => ({
    cm, inches: cmToThicknessInch(cm),
    label: `${cm}cm = ${cmToThicknessInch(cm)}"`,
  }))

  const boardFeetTable: any[] = []
  const commonWidths    = [5, 10, 15, 20, 25, 30]
  const commonLengths   = [122, 183, 244, 305]
  const commonThickness = [2.5, 3.8, 5]

  for (const w of commonWidths) {
    for (const l of commonLengths) {
      for (const t of commonThickness) {
        const wi = cmToCommercialInch(w)
        const lf = cmToCommercialFeet(l)
        const ti = cmToThicknessInch(t)
        const bf = calcBoardFeet(ti, wi, lf)
        boardFeetTable.push({
          medida: `${w}×${t}×${l}cm`,
          comercial: `${wi}"×${ti}"×${lf}'`,
          pieTablar: bf,
          m3: Number(((w/100) * (t/100) * (l/100)).toFixed(6)),
        })
      }
    }
  }

  const strips: any[] = []
  for (let w = 1; w <= 9.5; w = Math.round((w + 0.5) * 10) / 10) {
    strips.push({
      anchoCm: w,
      anchoPulg: cmToCommercialInch(w),
      descripcion: `Tira de ${w}cm (${cmToCommercialInch(w)}")`,
    })
  }

  return { widths, lengths, thicknesses, boardFeetTable, strips }
}

export function quickConvert(value: number, from: 'cm' | 'inch' | 'feet', to: 'cm' | 'inch' | 'feet'): number {
  let cm = value
  if (from === 'inch') cm = value * 2.54
  if (from === 'feet') cm = value * 30.48
  if (to === 'cm')   return Math.round(cm * 100) / 100
  if (to === 'inch') return cmToCommercialInch(cm)
  if (to === 'feet') return cmToCommercialFeet(cm)
  return cm
}
