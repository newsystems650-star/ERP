import { Router } from 'express'
import { z } from 'zod'
import { createWoodEntry, previewPrices } from '../services/woodEntryService'
import { getEquivalenceTable, quickConvert } from '../services/equivalenceTable'

const router = Router()

const entrySchema = z.object({
  woodType: z.string().min(1),
  woodClass: z.enum(['PRIMERA', 'SEGUNDA', 'TERCERA', 'ESPECIAL']),
  branchId: z.string(),
  userId: z.string(),
  productId: z.string().optional(),
  widthCm: z.number().positive(),
  thicknessCm: z.number().positive(),
  lengthCm: z.number().positive(),
  totalPieces: z.number().int().positive(),
  costPerFoot: z.number().positive(),
  marginPercent: z.number().min(1).max(500),
})

router.get('/equivalences', (req, res) => res.json(getEquivalenceTable()))

router.post('/preview', async (req, res) => {
  try {
    const data = req.body;
    const result = await previewPrices(data);
    res.json(result);
  } catch (e) { res.status(400).json({ error: e }); }
});

router.post('/', async (req, res) => {
  try {
    const data = entrySchema.parse(req.body);
    const result = await createWoodEntry(data);
    res.status(201).json(result);
  } catch (e) { res.status(400).json({ error: e }); }
});

export default router
