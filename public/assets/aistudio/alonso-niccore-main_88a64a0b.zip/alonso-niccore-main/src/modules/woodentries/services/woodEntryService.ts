import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError } from '../../../shared/errors/AppError'
import Decimal from 'decimal.js'

Decimal.set({ precision: 10, rounding: Decimal.ROUND_HALF_UP })

const COMMERCIAL_INCH_FRACTIONS = [1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 8, 10, 12]
const COMMERCIAL_FEET = [4, 6, 8, 10, 12, 14, 16]

export function cmToCommercialInch(cm: number): number {
  const exact = cm / 2.54
  let closest = COMMERCIAL_INCH_FRACTIONS[0]
  let minDiff = Math.abs(exact - closest)
  for (const f of COMMERCIAL_INCH_FRACTIONS) {
    const diff = Math.abs(exact - f)
    if (diff < minDiff) { minDiff = diff; closest = f }
  }
  return closest
}

export function cmToCommercialFeet(cm: number): number {
  const exact = cm / 30.48
  let closest = COMMERCIAL_FEET[0]
  let minDiff = Math.abs(exact - closest)
  for (const f of COMMERCIAL_FEET) {
    const diff = Math.abs(exact - f)
    if (diff < minDiff) { minDiff = diff; closest = f }
  }
  return closest
}

export function cmToThicknessInch(cm: number): number {
  const thicknesses = [0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 4]
  const exact = cm / 2.54
  let closest = thicknesses[0]
  let minDiff = Math.abs(exact - closest)
  for (const t of thicknesses) {
    const diff = Math.abs(exact - t)
    if (diff < minDiff) { minDiff = diff; closest = t }
  }
  return closest
}

export function calcBoardFeet(thicknessInch: number, widthInch: number, lengthFeet: number): number {
  return new Decimal(thicknessInch).mul(widthInch).mul(lengthFeet).div(12).toDecimalPlaces(2).toNumber()
}

export function calculatePrices(data: {
  widthCm: number; thicknessCm: number; lengthCm: number
  totalPieces: number; costPerFoot: number; marginPercent: number
}) {
  const widthInch     = cmToCommercialInch(data.widthCm)
  const thicknessInch = cmToThicknessInch(data.thicknessCm)
  const lengthFeet    = cmToCommercialFeet(data.lengthCm)
  const feetPerPiece  = calcBoardFeet(thicknessInch, widthInch, lengthFeet)
  const totalFeet     = new Decimal(feetPerPiece).mul(data.totalPieces).toDecimalPlaces(2).toNumber()
  const m3PerPiece    = (data.widthCm/100) * (data.thicknessCm/100) * (data.lengthCm/100)
  const totalM3       = new Decimal(m3PerPiece).mul(data.totalPieces).toDecimalPlaces(4).toNumber()
  const m2PerPiece    = (data.widthCm/100) * (data.lengthCm/100)
  const costPerFoot   = new Decimal(data.costPerFoot)
  const costPerPiece  = new Decimal(feetPerPiece).mul(costPerFoot).toDecimalPlaces(2).toNumber()
  const totalCost     = new Decimal(totalFeet).mul(costPerFoot).toDecimalPlaces(2).toNumber()
  const factor        = new Decimal(1).add(new Decimal(data.marginPercent).div(100))
  const pricePerFoot  = costPerFoot.mul(factor).toDecimalPlaces(2).toNumber()
  const pricePerPiece = new Decimal(costPerPiece).mul(factor).toDecimalPlaces(2).toNumber()
  const pricePerM3    = totalM3 > 0 ? new Decimal(totalCost).div(totalM3).mul(factor).toDecimalPlaces(2).toNumber() : 0
  const pricePerM2    = m2PerPiece > 0 ? new Decimal(costPerPiece).div(m2PerPiece).mul(factor).toDecimalPlaces(2).toNumber() : 0
  const profitPerFoot  = new Decimal(pricePerFoot).sub(data.costPerFoot).toDecimalPlaces(2).toNumber()
  const profitPerPiece = new Decimal(pricePerPiece).sub(costPerPiece).toDecimalPlaces(2).toNumber()
  const profitTotal    = new Decimal(profitPerPiece).mul(data.totalPieces).toDecimalPlaces(2).toNumber()
  return { widthInch, thicknessInch, lengthFeet, feetPerPiece, totalFeet, m3PerPiece, totalM3, m2PerPiece, totalCost, costPerPiece, pricePerFoot, pricePerPiece, pricePerM3, pricePerM2, profitPerFoot, profitPerPiece, profitTotal }
}

export function calculateStrips(data: { widthCm: number; lengthCm: number; thicknessCm: number; pricePerPiece: number; totalPieces: number; kerfCm?: number }) {
  const kerf = data.kerfCm || 0.3
  const boardWidth = data.widthCm - kerf
  const boardArea  = data.widthCm * data.lengthCm
  const strips = []
  for (let w = 1.0; w <= 9.5; w = Math.round((w + 0.5) * 10) / 10) {
    if (w >= data.widthCm) continue
    const slotWidth     = w + kerf
    const piecesPerPlan = Math.floor(boardWidth / slotWidth)
    if (piecesPerPlan < 1) continue
    const areaRatio    = (w * data.lengthCm) / boardArea
    const pricePerStrip = new Decimal(data.pricePerPiece).mul(areaRatio).div(piecesPerPlan).mul(1.10).toDecimalPlaces(2).toNumber()
    strips.push({ widthCm: w, widthInch: cmToCommercialInch(w), piecesPerPlan, totalPieces: piecesPerPlan * data.totalPieces, pricePerPiece: pricePerStrip })
  }
  return strips
}

function generateEntryCode(): string {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '')
  const rand = Math.floor(Math.random() * 9999).toString().padStart(4, '0')
  return `ENT-${date}-${rand}`
}

export async function createWoodEntry(data: any) {
  const calc   = calculatePrices(data)
  const strips = data.generateStrips !== false ? calculateStrips({ widthCm: data.widthCm, lengthCm: data.lengthCm, thicknessCm: data.thicknessCm, pricePerPiece: calc.pricePerPiece, totalPieces: data.totalPieces }) : []

  const entry = await prisma.woodEntry.create({
    data: {
      entryCode: generateEntryCode(), woodType: data.woodType, woodClass: data.woodClass,
      supplierId: data.supplierId, widthCm: data.widthCm, lengthCm: data.lengthCm, thicknessCm: data.thicknessCm,
      widthInch: calc.widthInch, lengthFeet: calc.lengthFeet, thicknessInch: calc.thicknessInch,
      totalPieces: data.totalPieces, totalFeet: calc.totalFeet, totalM3: calc.totalM3,
      costPerFoot: data.costPerFoot, totalCost: calc.totalCost, marginPercent: data.marginPercent,
      pricePerFoot: calc.pricePerFoot, pricePerPiece: calc.pricePerPiece, pricePerM3: calc.pricePerM3,
      pricePerM2: calc.pricePerM2, pricePerInch: new Decimal(calc.pricePerFoot).div(12).toDecimalPlaces(2).toNumber(),
      profitPerFoot: calc.profitPerFoot, profitPerPiece: calc.profitPerPiece, profitTotal: calc.profitTotal,
      notes: data.notes, userId: data.userId, productId: data.productId,
      strips: strips.length > 0 ? { create: strips } : undefined,
    },
    include: { strips: true, supplier: { select: { name: true } } },
  })

  if (data.productId) {
    await prisma.product.update({ where: { id: data.productId }, data: { price: calc.pricePerPiece } })
  }
  return { entry, calculations: calc, strips }
}

export async function previewPrices(data: any) {
  const calc   = calculatePrices(data)
  const strips = calculateStrips({ widthCm: data.widthCm, lengthCm: data.lengthCm, thicknessCm: data.thicknessCm, pricePerPiece: calc.pricePerPiece, totalPieces: data.totalPieces })
  return { calculations: calc, strips }
}

export async function getWoodEntries(filters: any) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip  = (page - 1) * limit
  const where: any = { active: true }
  if (filters.woodType)  where.woodType  = { contains: filters.woodType, mode: 'insensitive' }
  if (filters.woodClass) where.woodClass = filters.woodClass
  const [data, total] = await prisma.$transaction([
    prisma.woodEntry.findMany({ where, skip, take: limit, orderBy: { createdAt: 'desc' }, include: { strips: true, supplier: { select: { name: true } }, product: { select: { name: true, sku: true } }, user: { select: { name: true } } } }),
    prisma.woodEntry.count({ where }),
  ])
  return { data, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}

export async function updateMargin(id: string, marginPercent: number) {
  const entry = await prisma.woodEntry.findUnique({ where: { id } })
  if (!entry) throw new NotFoundError('Entrada de madera')
  const calc = calculatePrices({ widthCm: Number(entry.widthCm), thicknessCm: Number(entry.thicknessCm), lengthCm: Number(entry.lengthCm), totalPieces: entry.totalPieces, costPerFoot: Number(entry.costPerFoot), marginPercent })
  const updated = await prisma.woodEntry.update({ where: { id }, data: { marginPercent, pricePerFoot: calc.pricePerFoot, pricePerPiece: calc.pricePerPiece, pricePerM3: calc.pricePerM3, pricePerM2: calc.pricePerM2, profitPerFoot: calc.profitPerFoot, profitPerPiece: calc.profitPerPiece, profitTotal: calc.profitTotal } })
  if (entry.productId) await prisma.product.update({ where: { id: entry.productId }, data: { price: calc.pricePerPiece } })
  return { entry: updated, calculations: calc }
}
