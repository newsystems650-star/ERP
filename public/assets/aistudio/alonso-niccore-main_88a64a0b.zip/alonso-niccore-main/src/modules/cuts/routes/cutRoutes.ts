import { Router } from 'express'
import { z } from 'zod'
import { authenticate, AuthRequest } from '../../auth/middleware/authenticate'
import { createCutSheet, calculateCuts, getCutSheets } from '../services/cutService'

const router = Router()
router.use(authenticate)

router.get('/', async (req: AuthRequest, res) => {
  const data = await getCutSheets(req.query.mine === 'true' ? req.user!.id : undefined)
  res.json({ data })
})

router.post('/', async (req: AuthRequest, res) => {
  const schema = z.object({
    name: z.string().min(1),
    stockWidth: z.number().positive(),
    stockHeight: z.number().positive(),
    stockQty: z.number().int().positive().optional(),
    kerf: z.number().optional(),
    notes: z.string().optional(),
    pieces: z.array(z.object({
      label: z.string().min(1),
      width: z.number().positive(),
      height: z.number().positive(),
      quantity: z.number().int().positive(),
      grain: z.boolean().optional(),
    })).min(1),
  })
  const data = schema.parse(req.body)
  const cutSheet = await createCutSheet({ ...data, userId: req.user!.id })
  res.status(201).json({ cutSheet })
})

router.post('/:id/calcular', async (req, res) => {
  const result = await calculateCuts(req.params.id)
  res.json(result)
})

export default router
