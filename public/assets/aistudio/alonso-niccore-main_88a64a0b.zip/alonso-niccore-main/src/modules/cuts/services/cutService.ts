import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError } from '../../../shared/errors/AppError'

interface Piece {
  id: string
  label: string
  width: number
  height: number
  quantity: number
  grain: boolean
}

interface PlacedPiece {
  label: string
  x: number
  y: number
  width: number
  height: number
  rotated: boolean
}

interface Sheet {
  sheetIndex: number
  pieces: PlacedPiece[]
  usedArea: number
}

// Algoritmo de corte optimizado — First Fit Decreasing Height (FFDH)
function optimizeCuts(
  stockW: number,
  stockH: number,
  pieces: Piece[],
  kerf: number
): { sheets: Sheet[]; efficiency: number; waste: number; totalSheets: number } {
  // Expandir piezas por cantidad
  const allPieces: { label: string; w: number; h: number; grain: boolean }[] = []
  pieces.forEach((p) => {
    for (let i = 0; i < p.quantity; i++) {
      allPieces.push({ label: p.label, w: p.width, h: p.height, grain: p.grain })
    }
  })

  // Ordenar por altura descendente (FFDH)
  allPieces.sort((a, b) => Math.max(b.w, b.h) - Math.max(a.w, a.h))

  const sheets: Sheet[] = []
  let currentSheet: Sheet = { sheetIndex: 0, pieces: [], usedArea: 0 }
  sheets.push(currentSheet)

  // Espacios libres en cada hoja: [x, y, w, h]
  let freeRects: [number, number, number, number][] = [[0, 0, stockW, stockH]]

  for (const piece of allPieces) {
    let placed = false

    const orientations = piece.grain
      ? [{ w: piece.w, h: piece.h, rotated: false }]
      : [
          { w: piece.w, h: piece.h, rotated: false },
          { w: piece.h, h: piece.w, rotated: true },
        ]

    for (const ori of orientations) {
      if (placed) break
      const pw = ori.w + kerf
      const ph = ori.h + kerf

      // Buscar espacio libre (Best Short Side Fit)
      let bestIdx = -1
      let bestScore = Infinity

      for (let i = 0; i < freeRects.length; i++) {
        const [, , fw, fh] = freeRects[i]
        if (fw >= pw && fh >= ph) {
          const score = Math.min(fw - pw, fh - ph)
          if (score < bestScore) { bestScore = score; bestIdx = i }
        }
      }

      if (bestIdx >= 0) {
        const [rx, ry, rw, rh] = freeRects[bestIdx]
        currentSheet.pieces.push({ label: piece.label, x: rx, y: ry, width: ori.w, height: ori.h, rotated: ori.rotated })
        currentSheet.usedArea += ori.w * ori.h

        // Dividir espacio restante
        freeRects.splice(bestIdx, 1)
        if (rw - pw > kerf) freeRects.push([rx + pw, ry, rw - pw, ph])
        if (rh - ph > kerf) freeRects.push([rx, ry + ph, rw, rh - ph])
        placed = true
      }
    }

    if (!placed) {
      // Nueva hoja
      currentSheet = { sheetIndex: sheets.length, pieces: [], usedArea: 0 }
      sheets.push(currentSheet)
      freeRects = [[0, 0, stockW, stockH]]

      const ori = piece.grain
        ? { w: piece.w, h: piece.h, rotated: false }
        : piece.w <= stockW && piece.h <= stockH
          ? { w: piece.w, h: piece.h, rotated: false }
          : { w: piece.h, h: piece.w, rotated: true }

      const pw = ori.w + kerf
      const ph = ori.h + kerf
      currentSheet.pieces.push({ label: piece.label, x: 0, y: 0, width: ori.w, height: ori.h, rotated: ori.rotated })
      currentSheet.usedArea += ori.w * ori.h
      freeRects = []
      if (stockW - pw > kerf) freeRects.push([pw, 0, stockW - pw, ph])
      if (stockH - ph > kerf) freeRects.push([0, ph, stockW, stockH - ph])
    }
  }

  const totalSheets = sheets.length
  const sheetArea = stockW * stockH
  const totalArea = totalSheets * sheetArea
  const usedArea = sheets.reduce((s, sh) => s + sh.usedArea, 0)
  const efficiency = totalArea > 0 ? usedArea / totalArea : 0
  const waste = totalArea - usedArea

  return { sheets, efficiency, waste, totalSheets }
}

export async function createCutSheet(data: {
  name: string
  stockWidth: number
  stockHeight: number
  stockQty?: number
  kerf?: number
  notes?: string
  userId: string
  pieces: { label: string; width: number; height: number; quantity: number; grain?: boolean }[]
}) {
  return prisma.cutSheet.create({
    data: {
      name: data.name,
      stockWidth: data.stockWidth,
      stockHeight: data.stockHeight,
      stockQty: data.stockQty || 1,
      kerf: data.kerf || 0.003,
      notes: data.notes,
      userId: data.userId,
      pieces: {
        create: data.pieces.map((p) => ({
          label: p.label,
          width: p.width,
          height: p.height,
          quantity: p.quantity,
          grain: p.grain || false,
        })),
      },
    },
    include: { pieces: true },
  })
}

export async function calculateCuts(cutSheetId: string) {
  const sheet = await prisma.cutSheet.findUnique({
    where: { id: cutSheetId },
    include: { pieces: true },
  })
  if (!sheet) throw new NotFoundError('Hoja de corte')

  const pieces: Piece[] = sheet.pieces.map((p) => ({
    id: p.id,
    label: p.label,
    width: Number(p.width),
    height: Number(p.height),
    quantity: p.quantity,
    grain: p.grain,
  }))

  const result = optimizeCuts(
    Number(sheet.stockWidth),
    Number(sheet.stockHeight),
    pieces,
    Number(sheet.kerf)
  )

  // Guardar resultado
  const saved = await prisma.$transaction(async (tx) => {
    const cutResult = await tx.cutResult.create({
      data: {
        layout: result.sheets as any,
        efficiency: result.efficiency,
        waste: result.waste,
        sheets: result.totalSheets,
        cutSheetId,
      },
    })

    await tx.cutSheet.update({
      where: { id: cutSheetId },
      data: { efficiency: result.efficiency, waste: result.waste },
    })

    return cutResult
  })

  return {
    id: saved.id,
    hojas: result.totalSheets,
    eficiencia: (result.efficiency * 100).toFixed(2) + '%',
    desperdicio: result.waste.toFixed(4) + ' m²',
    layout: result.sheets,
    resumen: result.sheets.map((s) => ({
      hoja: s.sheetIndex + 1,
      piezas: s.pieces.length,
      areaUsada: s.usedArea.toFixed(4),
      piezasDetalle: s.pieces.map((p) => ({
        etiqueta: p.label,
        x: p.x.toFixed(3),
        y: p.y.toFixed(3),
        ancho: p.width,
        alto: p.height,
        rotada: p.rotated,
      })),
    })),
  }
}

export async function getCutSheets(userId?: string) {
  return prisma.cutSheet.findMany({
    where: userId ? { userId } : {},
    orderBy: { createdAt: 'desc' },
    include: {
      pieces: true,
      results: { orderBy: { createdAt: 'desc' }, take: 1 },
      user: { select: { name: true } },
    },
  })
}
