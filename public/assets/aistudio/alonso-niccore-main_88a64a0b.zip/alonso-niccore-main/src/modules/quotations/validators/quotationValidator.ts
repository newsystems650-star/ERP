import { z } from 'zod'

export const createQuotationSchema = z.object({
  notes: z.string().optional(),
  applyTax: z.boolean().default(false),
  taxRate: z.number().min(0).max(1).default(0.16),
  validUntil: z.string().datetime().optional(),
  items: z.array(z.object({
    productId: z.string(),
    quantity: z.number().positive(),
    unitPrice: z.number().nonnegative(),
    discount: z.number().min(0).max(1).default(0),
    unit: z.enum(['M2', 'M3', 'KG', 'LITER', 'LINEAR_M', 'FEET', 'INCH', 'PIECE']),
    description: z.string().optional(),
  })).min(1),
})

export type CreateQuotationInput = z.infer<typeof createQuotationSchema>
