import { Router } from 'express'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import { createQuotationSchema } from '../validators/quotationValidator'
import {
  createQuotation, getQuotations, getQuotationById,
  updateStatus, convertToTicket,
} from '../services/quotationService'

const router = Router()
router.use(authenticate)

router.get('/', async (req, res) => {
  const result = await getQuotations({
    status: req.query.status as string,
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 20,
  })
  res.json(result)
})

router.get('/:id', async (req, res) => {
  const quotation = await getQuotationById(req.params.id)
  res.json({ quotation })
})

router.post('/', async (req: AuthRequest, res) => {
  const data = createQuotationSchema.parse(req.body)
  const quotation = await createQuotation({ ...data, userId: req.user!.id })
  res.status(201).json({ quotation })
})

router.patch('/:id/status', authorize('ADMIN', 'MANAGER', 'OPERATOR'), async (req, res) => {
  const { status } = req.body
  if (!['SENT', 'APPROVED', 'REJECTED'].includes(status)) {
    return res.status(400).json({ error: { message: 'Estado inválido' } })
  }
  const quotation = await updateStatus(req.params.id, status)
  res.json({ quotation })
})

router.post('/:id/convert', authorize('ADMIN', 'MANAGER'), async (req: AuthRequest, res) => {
  const ticket = await convertToTicket(req.params.id, req.user!.id)
  res.status(201).json({ ticket })
})

export default router
