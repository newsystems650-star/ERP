import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError, AppError } from '../../../shared/errors/AppError'
import { CreateQuotationInput } from '../validators/quotationValidator'

function generateCode(): string {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '')
  const rand = Math.floor(Math.random() * 9999).toString().padStart(4, '0')
  return `COT-${date}-${rand}`
}

function calcTotals(items: CreateQuotationInput['items'], applyTax: boolean, taxRate: number) {
  const subtotal = items.reduce((sum, i) => {
    const lineTotal = i.quantity * i.unitPrice
    return sum + (lineTotal - lineTotal * i.discount)
  }, 0)
  const tax = applyTax ? subtotal * taxRate : 0
  return { subtotal, tax, total: subtotal + tax }
}

export async function createQuotation(data: CreateQuotationInput & { userId: string }) {
  const { subtotal, tax, total } = calcTotals(data.items, data.applyTax, data.taxRate)

  return prisma.quotation.create({
    data: {
      code: generateCode(),
      status: 'DRAFT',
      notes: data.notes,
      applyTax: data.applyTax,
      taxRate: data.taxRate,
      subtotal, tax, total,
      validUntil: data.validUntil ? new Date(data.validUntil) : null,
      userId: data.userId,
      items: {
        create: data.items.map((i) => ({
          quantity: i.quantity,
          unitPrice: i.unitPrice,
          discount: i.discount,
          subtotal: (i.quantity * i.unitPrice) * (1 - i.discount),
          unit: i.unit,
          description: i.description,
          productId: i.productId,
        })),
      },
    },
    include: {
      items: { include: { product: { select: { name: true, sku: true } } } },
      user: { select: { id: true, name: true } },
    },
  })
}

export async function getQuotations(filters: { status?: string; page?: number; limit?: number }) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit
  const where: any = {}
  if (filters.status) where.status = filters.status

  const [data, total] = await prisma.$transaction([
    prisma.quotation.findMany({
      where, skip, take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { id: true, name: true } },
        items: { include: { product: { select: { name: true, sku: true } } } },
      },
    }),
    prisma.quotation.count({ where }),
  ])

  return { data, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}

export async function getQuotationById(id: string) {
  const q = await prisma.quotation.findUnique({
    where: { id },
    include: {
      user: { select: { id: true, name: true } },
      items: { include: { product: { select: { name: true, sku: true, unit: true } } } },
      ticket: { select: { id: true, code: true, status: true } },
    },
  })
  if (!q) throw new NotFoundError('Cotización')
  return q
}

export async function updateStatus(id: string, status: 'SENT' | 'APPROVED' | 'REJECTED') {
  const q = await prisma.quotation.findUnique({ where: { id } })
  if (!q) throw new NotFoundError('Cotización')
  if (q.status === 'CONVERTED') throw new AppError('La cotización ya fue convertida en venta')
  if (q.status === 'REJECTED') throw new AppError('La cotización ya fue rechazada')
  return prisma.quotation.update({ where: { id }, data: { status } })
}

export async function convertToTicket(quotationId: string, userId: string) {
  const q = await getQuotationById(quotationId)
  if (q.status !== 'APPROVED') throw new AppError('Solo se pueden convertir cotizaciones aprobadas')
  if (q.ticket) throw new AppError('Esta cotización ya fue convertida')

  return prisma.$transaction(async (tx) => {
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, '')
    const rand = Math.floor(Math.random() * 9999).toString().padStart(4, '0')

    const ticket = await tx.ticket.create({
      data: {
        code: `VTA-${date}-${rand}`,
        type: 'SALE',
        status: 'PENDING',
        total: q.total,
        notes: q.notes,
        userId,
        quotationId,
        items: {
          create: q.items.map((i) => ({
            quantity: i.quantity,
            unitPrice: i.unitPrice,
            subtotal: i.subtotal,
            unit: i.unit,
            productId: i.productId,
          })),
        },
      },
      include: { items: { include: { product: { select: { name: true, sku: true } } } } },
    })

    await tx.quotation.update({ where: { id: quotationId }, data: { status: 'CONVERTED' } })

    await tx.auditLog.create({
      data: {
        action: 'QUOTATION_CONVERTED',
        entity: 'Quotation',
        entityId: quotationId,
        before: { status: 'APPROVED' },
        after: { status: 'CONVERTED', ticketId: ticket.id },
        userId,
        ticketId: ticket.id,
      },
    })

    return ticket
  })
}
