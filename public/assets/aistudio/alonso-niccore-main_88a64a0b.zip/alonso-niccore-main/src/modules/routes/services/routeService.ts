import { prisma } from '../../../infrastructure/database/prisma'

const ZONAS_CDMX: Record<string, string[]> = {
  'Iztapalapa': ['iztapalapa', 'iztapalpa', 'culhuacan', 'ermita'],
  'Naucalpan': ['naucalpan', 'satelite', 'tlalnepantla'],
  'Centro': ['centro', 'tepito', 'doctores', 'obrera', 'guerrero'],
  'Coyoacan': ['coyoacan', 'copilco', 'pedregal'],
  'Ecatepec': ['ecatepec', 'ciudad azteca', 'aragon'],
  'Tlalpan': ['tlalpan', 'coapa', 'periferico sur'],
  'Azcapotzalco': ['azcapotzalco', 'vallejo', 'industrial'],
  'Otras': [],
}

function detectZona(address: string): string {
  if (!address) return 'Otras'
  const lower = address.toLowerCase()
  for (const [zona, keywords] of Object.entries(ZONAS_CDMX)) {
    if (keywords.some((k) => lower.includes(k))) return zona
  }
  return 'Otras'
}

export async function getHojaRuta(date?: string) {
  const from = date ? new Date(date) : new Date()
  from.setHours(0, 0, 0, 0)
  const to = new Date(from)
  to.setHours(23, 59, 59, 999)

  const tickets = await prisma.ticket.findMany({
    where: {
      type: 'SALE',
      status: 'CONFIRMED',
      createdAt: { gte: from, lte: to },
      customer: { isNot: null },
    },
    include: {
      customer: { select: { name: true, phone: true, address: true } },
      items: { include: { product: { select: { name: true, sku: true } } } },
      user: { select: { name: true } },
    },
    orderBy: { createdAt: 'asc' },
  })

  // Agrupar por zona
  const porZona: Record<string, typeof tickets> = {}
  tickets.forEach((t) => {
    const zona = detectZona(t.customer?.address || '')
    if (!porZona[zona]) porZona[zona] = []
    porZona[zona].push(t)
  })

  const zonas = Object.entries(porZona).map(([zona, entregas]) => ({
    zona,
    totalEntregas: entregas.length,
    totalPiezas: entregas.reduce((s, t) => s + t.items.reduce((si, i) => si + Number(i.quantity), 0), 0),
    entregas: entregas.map((t) => ({
      ticket: t.code,
      cliente: t.customer?.name,
      telefono: t.customer?.phone,
      direccion: t.customer?.address,
      total: Number(t.total),
      items: t.items.map((i) => ({ producto: i.product.name, cantidad: Number(i.quantity), unidad: i.unit })),
    })),
  }))

  return {
    fecha: from.toLocaleDateString('es-MX'),
    totalEntregas: tickets.length,
    zonas,
  }
}

export async function getHojaPatio(date?: string) {
  const from = date ? new Date(date) : new Date()
  from.setHours(0, 0, 0, 0)
  const to = new Date(from)
  to.setHours(23, 59, 59, 999)

  const items = await prisma.ticketItem.findMany({
    where: {
      ticket: {
        type: 'SALE',
        status: 'CONFIRMED',
        createdAt: { gte: from, lte: to },
      },
    },
    include: {
      product: { select: { name: true, sku: true, unit: true } },
      ticket: {
        select: {
          code: true,
          customer: { select: { name: true } },
        },
      },
    },
    orderBy: { product: { name: 'asc' } },
  })

  // Agrupar por producto
  const porProducto: Record<string, { nombre: string; sku: string; unidad: string; totalQty: number; tickets: string[] }> = {}

  items.forEach((i) => {
    const key = i.productId
    if (!porProducto[key]) {
      porProducto[key] = {
        nombre: i.product.name,
        sku: i.product.sku,
        unidad: i.unit,
        totalQty: 0,
        tickets: [],
      }
    }
    porProducto[key].totalQty += Number(i.quantity)
    porProducto[key].tickets.push(`${i.ticket.code}${i.ticket.customer ? ' ('+i.ticket.customer.name+')' : ''}`)
  })

  return {
    fecha: from.toLocaleDateString('es-MX'),
    totalItems: items.length,
    cortes: Object.values(porProducto).sort((a, b) => b.totalQty - a.totalQty),
  }
}
