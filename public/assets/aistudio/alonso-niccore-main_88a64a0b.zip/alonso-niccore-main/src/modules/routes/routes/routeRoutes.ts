import { Router } from 'express'
import { authenticate, authorize } from '../../auth/middleware/authenticate'
import { getHojaRuta, getHojaPatio } from '../services/routeService'

const router = Router()
router.use(authenticate)
router.use(authorize('ADMIN', 'MANAGER', 'OPERATOR'))

router.get('/hoja-ruta', async (req, res) => {
  const data = await getHojaRuta(req.query.date as string)
  res.json(data)
})

router.get('/hoja-patio', async (req, res) => {
  const data = await getHojaPatio(req.query.date as string)
  res.json(data)
})

export default router
