import { Router } from 'express'
import { authenticate, authorize } from '../../auth/middleware/authenticate'
import { prisma } from '../../../infrastructure/database/prisma'

const router = Router()
router.use(authenticate)

router.get('/', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const page = Number(req.query.page) || 1
  const limit = Math.min(Number(req.query.limit) || 20, 100)
  const skip = (page - 1) * limit

  const where: any = {}
  if (req.query.entity) where.entity = req.query.entity
  if (req.query.action) where.action = req.query.action
  if (req.query.userId) where.userId = req.query.userId

  const [logs, total] = await prisma.$transaction([
    prisma.auditLog.findMany({
      where, skip, take: limit,
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { id: true, name: true, email: true } } },
    }),
    prisma.auditLog.count({ where }),
  ])

  res.json({ data: logs, meta: { page, limit, total, pages: Math.ceil(total / limit) } })
})

router.get('/ticket/:ticketId', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const logs = await prisma.auditLog.findMany({
    where: { ticketId: req.params.ticketId },
    orderBy: { createdAt: 'asc' },
    include: { user: { select: { id: true, name: true } } },
  })
  res.json({ data: logs })
})

export default router
