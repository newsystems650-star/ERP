import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import {
  createDelivery, getDeliveries, completeDelivery,
  assignDriver, getDriverSummary, driverArrived, markDriverAtWarehouse,
} from '../services/deliveryService'

const router = Router()
router.use(authenticate)

// Lista de entregas — patrón y manager
router.get('/', authorize('ADMIN', 'MANAGER', 'OPERATOR'), async (req, res) => {
  const result = await getDeliveries({
    status: req.query.status as string,
    driverId: req.query.driverId as string,
    date: req.query.date as string,
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 50,
  })
  res.json(result)
})

// Resumen del chofer — sus entregas del día
router.get('/my-deliveries', async (req: AuthRequest, res) => {
  const data = await getDriverSummary(req.user!.id)
  res.json(data)
})

// Crear entrega para un ticket
router.post('/', authorize('ADMIN', 'MANAGER', 'OPERATOR'), async (req: AuthRequest, res) => {
  const schema = z.object({
    ticketId: z.string(),
    address: z.string().min(1),
    contactName: z.string().optional(),
    contactPhone: z.string().optional(),
    scheduledAt: z.string().optional(),
    notes: z.string().optional(),
    driverId: z.string().optional(),
  })
  const data = schema.parse(req.body)
  const delivery = await createDelivery(data)
  res.status(201).json({ delivery })
})

// Asignar chofer
router.patch('/:id/assign', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const { driverId } = req.body
  const delivery = await assignDriver(req.params.id, driverId)
  res.json({ delivery })
})

// Chofer llegó al negocio a cargar
router.post('/arrived-warehouse', async (req: AuthRequest, res) => {
  const result = await markDriverAtWarehouse(req.user!.id)
  res.json(result)
})

// Chofer llegó a domicilio del cliente
router.patch('/:id/arrived', async (req: AuthRequest, res) => {
  const delivery = await driverArrived(req.params.id, req.user!.id)
  res.json({ delivery })
})

// Marcar entrega completada con foto
router.patch('/:id/complete', async (req: AuthRequest, res) => {
  const schema = z.object({
    photoBase64: z.string().optional(),
    driverNotes: z.string().optional(),
  })
  const data = schema.parse(req.body)
  const delivery = await completeDelivery({
    deliveryId: req.params.id,
    driverId: req.user!.id,
    ...data,
  })
  res.json({ delivery })
})

export default router
