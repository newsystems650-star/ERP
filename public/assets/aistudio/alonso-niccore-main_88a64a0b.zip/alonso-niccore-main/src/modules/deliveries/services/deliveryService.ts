import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError, AppError } from '../../../shared/errors/AppError'
import { sendInfo } from '../../../infrastructure/monitor/telegram'
import path from 'path'
import fs from 'fs'

export async function createDelivery(data: {
  ticketId: string
  address: string
  contactName?: string
  contactPhone?: string
  scheduledAt?: string
  notes?: string
  driverId?: string
}) {
  const ticket = await prisma.ticket.findUnique({ where: { id: data.ticketId } })
  if (!ticket) throw new NotFoundError('Ticket')
  if (ticket.status !== 'CONFIRMED') throw new AppError('Solo tickets confirmados pueden tener entregas')

  const existing = await prisma.delivery.findUnique({ where: { ticketId: data.ticketId } })
  if (existing) throw new AppError('Este ticket ya tiene una entrega registrada')

  const freightFree = Number(ticket.total) >= 1000

  return prisma.delivery.create({
    data: {
      ticketId: data.ticketId,
      address: data.address,
      contactName: data.contactName,
      contactPhone: data.contactPhone,
      scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : null,
      notes: data.notes,
      driverId: data.driverId,
      freightFree,
      status: data.driverId ? 'ASSIGNED' : 'PENDING',
    },
    include: {
      ticket: { select: { code: true, total: true } },
      driver: { select: { name: true } },
    },
  })
}

export async function getDeliveries(filters: {
  status?: string
  driverId?: string
  date?: string
  page?: number
  limit?: number
}) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 50, 100)
  const skip = (page - 1) * limit
  const where: any = {}

  if (filters.status) where.status = filters.status
  if (filters.driverId) where.driverId = filters.driverId
  if (filters.date) {
    const from = new Date(filters.date)
    from.setHours(0, 0, 0, 0)
    const to = new Date(filters.date)
    to.setHours(23, 59, 59, 999)
    where.scheduledAt = { gte: from, lte: to }
  }

  const [data, total] = await prisma.$transaction([
    prisma.delivery.findMany({
      where, skip, take: limit,
      orderBy: [{ status: 'asc' }, { scheduledAt: 'asc' }],
      include: {
        ticket: {
          select: {
            code: true,
            total: true,
            items: {
              include: { product: { select: { name: true, sku: true } } },
              take: 5,
            },
          },
        },
        driver: { select: { id: true, name: true } },
      },
    }),
    prisma.delivery.count({ where }),
  ])

  return { data, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}

export async function driverArrived(deliveryId: string, driverId: string) {
  const delivery = await prisma.delivery.findUnique({ where: { id: deliveryId } })
  if (!delivery) throw new NotFoundError('Entrega')
  if (delivery.driverId !== driverId) throw new AppError('No autorizado para esta entrega')

  return prisma.delivery.update({
    where: { id: deliveryId },
    data: { status: 'ARRIVED', arrivedAt: new Date() },
  })
}

export async function markDriverAtWarehouse(driverId: string) {
  await sendInfo(
    `🚛 *Chofer llegó al negocio*\n\n` +
    `Driver ID: ${driverId}\n` +
    `Hora: ${new Date().toLocaleTimeString('es-MX')}\n\n` +
    `Listo para cargar pedidos`
  )

  return { message: 'Llegada registrada', timestamp: new Date() }
}

export async function completeDelivery(data: {
  deliveryId: string
  driverId: string
  photoBase64?: string
  driverNotes?: string
}) {
  const delivery = await prisma.delivery.findUnique({
    where: { id: data.deliveryId },
    include: {
      ticket: { select: { code: true } },
      driver: { select: { name: true } },
    },
  })
  if (!delivery) throw new NotFoundError('Entrega')
  if (delivery.driverId !== data.driverId) throw new AppError('No autorizado para esta entrega')
  if (delivery.status === 'DELIVERED') throw new AppError('Esta entrega ya fue completada')

  let photoUrl: string | undefined

  // Guardar foto si viene
  if (data.photoBase64) {
    const uploadsDir = path.join(process.cwd(), 'public', 'uploads', 'deliveries')
    if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true })

    const filename = `delivery-${data.deliveryId}-${Date.now()}.jpg`
    const filepath = path.join(uploadsDir, filename)
    const base64Data = data.photoBase64.replace(/^data:image\/\w+;base64,/, '')
    fs.writeFileSync(filepath, Buffer.from(base64Data, 'base64'))
    photoUrl = `/uploads/deliveries/${filename}`
  }

  const updated = await prisma.delivery.update({
    where: { id: data.deliveryId },
    data: {
      status: 'DELIVERED',
      deliveredAt: new Date(),
      photoUrl,
      driverNotes: data.driverNotes,
    },
    include: {
      ticket: { select: { code: true, total: true } },
      driver: { select: { name: true } },
    },
  })

  // Notificar al patrón
  await sendInfo(
    `✅ *Entrega completada*\n\n` +
    `*Ticket:* ${updated.ticket.code}\n` +
    `*Chofer:* ${updated.driver?.name}\n` +
    `*Dirección:* ${updated.address}\n` +
    `*Total:* $${Number(updated.ticket.total).toLocaleString('es-MX')}\n` +
    `*Hora:* ${new Date().toLocaleTimeString('es-MX')}\n` +
    `*Foto:* ${photoUrl ? '✅ Adjunta' : '❌ Sin foto'}\n` +
    (data.driverNotes ? `*Nota:* ${data.driverNotes}` : '')
  )

  return updated
}

export async function assignDriver(deliveryId: string, driverId: string) {
  return prisma.delivery.update({
    where: { id: deliveryId },
    data: { driverId, status: 'ASSIGNED' },
    include: { driver: { select: { name: true } } },
  })
}

export async function getDriverSummary(driverId: string) {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const deliveries = await prisma.delivery.findMany({
    where: {
      driverId,
      createdAt: { gte: today },
    },
    orderBy: [{ status: 'asc' }, { scheduledAt: 'asc' }],
    include: {
      ticket: {
        select: {
          code: true,
          total: true,
          items: {
            include: { product: { select: { name: true } } },
          },
        },
      },
    },
  })

  const pending = deliveries.filter(d => ['PENDING', 'ASSIGNED', 'IN_ROUTE', 'ARRIVED'].includes(d.status))
  const completed = deliveries.filter(d => d.status === 'DELIVERED')

  // Estimar hora de llegada para cada pendiente (20 min por entrega)
  let estimatedMinutes = 0
  const withEstimate = pending.map((d, i) => {
    estimatedMinutes += 20
    const eta = new Date(Date.now() + estimatedMinutes * 60 * 1000)
    return { ...d, position: i + 1, eta: eta.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) }
  })

  return {
    totalHoy: deliveries.length,
    pendientes: pending.length,
    completadas: completed.length,
    entregas: withEstimate,
    historial: completed,
  }
}
