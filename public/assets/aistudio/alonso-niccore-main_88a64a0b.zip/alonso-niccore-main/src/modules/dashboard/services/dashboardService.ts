import { prisma } from '../../../infrastructure/database/prisma'

function startOfDay() {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

function endOfDay() {
  const d = new Date()
  d.setHours(23, 59, 59, 999)
  return d
}

export async function getDashboard() {
  const today = { gte: startOfDay(), lte: endOfDay() }

  const [
    ticketsHoy,
    ventasConfirmadas,
    cotizacionesHoy,
    stockAlertas,
    ventasSemana,
    ultimosTickets,
  ] = await prisma.$transaction([

    // Tickets creados hoy
    prisma.ticket.groupBy({
      by: ['status'],
      where: { createdAt: today, type: 'SALE' },
      _count: true,
    }),

    // Total vendido hoy (tickets SALE confirmados)
    prisma.ticket.aggregate({
      where: { type: 'SALE', status: 'CONFIRMED', createdAt: today },
      _sum: { total: true },
      _count: true,
    }),

    // Cotizaciones hoy por estado
    prisma.quotation.groupBy({
      by: ['status'],
      where: { createdAt: today },
      _count: true,
    }),

    // Productos con stock bajo
    prisma.stock.findMany({
      where: { minAlert: { not: null }, product: { active: true } },
      include: { product: { select: { name: true, sku: true, unit: true } } },
    }),

    // Ventas últimos 7 días
    prisma.ticket.groupBy({
      by: ['createdAt'],
      where: {
        type: 'SALE',
        status: 'CONFIRMED',
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
      _sum: { total: true },
      _count: true,
    }),

    // Últimos 5 tickets
    prisma.ticket.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { name: true } } },
    }),
  ])

  const alertas = stockAlertas.filter(
    (s) => s.minAlert && Number(s.quantity) <= Number(s.minAlert)
  )

  const totalHoy = Number(ventasConfirmadas._sum.total || 0)
  const ticketsPendientes = ticketsHoy.find(t => t.status === 'PENDING')?._count || 0
  const ticketsConfirmados = ticketsHoy.find(t => t.status === 'CONFIRMED')?._count || 0
  const ticketsCancelados = ticketsHoy.find(t => t.status === 'CANCELLED')?._count || 0

  return {
    resumenHoy: {
      totalVentas: totalHoy,
      ticketsConfirmados,
      ticketsPendientes,
      ticketsCancelados,
      totalTickets: ticketsPendientes + ticketsConfirmados + ticketsCancelados,
    },
    cotizaciones: {
      draft: cotizacionesHoy.find(c => c.status === 'DRAFT')?._count || 0,
      sent: cotizacionesHoy.find(c => c.status === 'SENT')?._count || 0,
      approved: cotizacionesHoy.find(c => c.status === 'APPROVED')?._count || 0,
      converted: cotizacionesHoy.find(c => c.status === 'CONVERTED')?._count || 0,
    },
    alertasStock: {
      count: alertas.length,
      productos: alertas.map(a => ({
        nombre: a.product.name,
        sku: a.product.sku,
        unidad: a.product.unit,
        disponible: Number(a.quantity),
        minimo: Number(a.minAlert),
      })),
    },
    ventasSemana: ventasSemana.map(v => ({
      fecha: v.createdAt,
      total: Number(v._sum.total || 0),
      tickets: v._count,
    })),
    ultimosTickets: ultimosTickets.map(t => ({
      id: t.id,
      code: t.code,
      type: t.type,
      status: t.status,
      total: Number(t.total),
      usuario: t.user.name,
      fecha: t.createdAt,
    })),
  }
}
