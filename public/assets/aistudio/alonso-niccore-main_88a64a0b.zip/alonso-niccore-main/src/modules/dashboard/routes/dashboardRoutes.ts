import { Router } from 'express'
import { authenticate, authorize } from '../../auth/middleware/authenticate'
import { getDashboard } from '../services/dashboardService'

const router = Router()
router.use(authenticate)

router.get('/', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const data = await getDashboard()
  res.json(data)
})

export default router
