import { Router } from 'express'
import { authenticate } from '../../auth/middleware/authenticate'
import { getStock, getAlerts } from '../services/inventoryService'

const router = Router()
router.use(authenticate)

router.get('/', async (req, res) => {
  const result = await getStock({
    search: req.query.search as string,
    lowStock: req.query.lowStock === 'true',
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 20,
  })
  res.json(result)
})

router.get('/alerts', async (req, res) => {
  const result = await getAlerts()
  res.json(result)
})

export default router
