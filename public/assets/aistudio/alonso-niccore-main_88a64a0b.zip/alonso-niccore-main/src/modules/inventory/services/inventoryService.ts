import { prisma } from '../../../infrastructure/database/prisma'

export async function getStock(filters: {
  search?: string
  lowStock?: boolean
  page?: number
  limit?: number
}) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit

  const where: any = { product: { active: true } }
  if (filters.search) {
    where.product = {
      ...where.product,
      OR: [
        { name: { contains: filters.search, mode: 'insensitive' } },
        { sku: { contains: filters.search, mode: 'insensitive' } },
      ],
    }
  }

  const stock = await prisma.stock.findMany({
    where,
    skip,
    take: limit,
    include: { product: true },
    orderBy: { product: { name: 'asc' } },
  })

  const total = await prisma.stock.count({ where })

  const data = stock.map((s) => ({
    ...s,
    alert: s.minAlert !== null && Number(s.quantity) <= Number(s.minAlert),
  }))

  const filtered = filters.lowStock ? data.filter((s) => s.alert) : data

  return {
    data: filtered,
    meta: { page, limit, total, pages: Math.ceil(total / limit) },
  }
}

export async function getAlerts() {
  const stock = await prisma.stock.findMany({
    where: { minAlert: { not: null }, product: { active: true } },
    include: { product: true },
  })
  const alerts = stock.filter((s) => Number(s.quantity) <= Number(s.minAlert))
  return { data: alerts, count: alerts.length }
}
