import { Router, Request, Response } from 'express';
import { getViaje, getViajesDeNodo, getNodosConActividad } from './rutas.service';

export const rutasRouter = Router();

rutasRouter.get('/viaje/:tripId', async (req: Request, res: Response) => {
    try {
        const viaje = await getViaje(req.params.tripId);
        if (!viaje) return res.status(404).json({ error: 'Viaje no encontrado.' });
        res.json(viaje);
    } catch (e) { res.status(500).json({ error: String(e) }); }
});

rutasRouter.get('/nodo/:nodeId', async (req: Request, res: Response) => {
    const { desde, hasta } = req.query as { desde?: string; hasta?: string };
    const fechaDesde = desde ? new Date(desde) : (() => { const d = new Date(); d.setDate(d.getDate() - 7); return d; })();
    const fechaHasta = hasta ? new Date(hasta) : new Date();
    if (isNaN(fechaDesde.getTime()) || isNaN(fechaHasta.getTime()))
        return res.status(400).json({ error: 'Fechas inválidas. Formato ISO requerido.' });
    try {
        res.json(await getViajesDeNodo(req.params.nodeId, fechaDesde, fechaHasta));
    } catch (e) { res.status(500).json({ error: String(e) }); }
});

rutasRouter.get('/nodos', async (req: Request, res: Response) => {
    const { desde, hasta } = req.query as { desde?: string; hasta?: string };
    const fechaDesde = desde ? new Date(desde) : (() => { const d = new Date(); d.setDate(d.getDate() - 7); return d; })();
    const fechaHasta = hasta ? new Date(hasta) : new Date();
    try {
        res.json({ nodos: await getNodosConActividad(fechaDesde, fechaHasta) });
    } catch (e) { res.status(500).json({ error: String(e) }); }
});
