import { prisma } from '../../lib/prisma';

export interface Breadcrumb { lat: number; lon: number; spd: number; timestamp: string; }
export interface Viaje {
    tripId: string; nodeId: string; inicio: string; fin: string;
    duracionMin: number; distanciaKm: number; spdPromedio: number; spdMaxima: number;
    puntos: Breadcrumb[];
}
export interface ViajeResumen { tripId: string; inicio: string; fin: string; duracionMin: number; distanciaKm: number; }
export interface ResumenNodo { nodeId: string; totalViajes: number; viajes: ViajeResumen[]; }

function haversine(la1: number, lo1: number, la2: number, lo2: number): number {
    const R = 6371, dL = ((la2 - la1) * Math.PI) / 180, dO = ((lo2 - lo1) * Math.PI) / 180;
    const a = Math.sin(dL / 2) ** 2 + Math.cos((la1 * Math.PI) / 180) * Math.cos((la2 * Math.PI) / 180) * Math.sin(dO / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function calcularDistancia(puntos: { lat: number; lon: number }[]): number {
    let total = 0;
    for (let i = 1; i < puntos.length; i++) total += haversine(puntos[i-1].lat, puntos[i-1].lon, puntos[i].lat, puntos[i].lon);
    return parseFloat(total.toFixed(2));
}

export async function getViaje(tripId: string): Promise<Viaje | null> {
    const registros = await prisma.node_breadcrumbs.findMany({ where: { trip_id: tripId }, orderBy: { timestamp: 'asc' } });
    if (registros.length === 0) return null;
    const puntos: Breadcrumb[] = registros.map((r) => ({ lat: r.latitud, lon: r.longitud, spd: r.velocidadKmh, timestamp: r.timestamp.toISOString() }));
    const speeds = puntos.map((p) => p.spd);
    const inicio = puntos[0].timestamp, fin = puntos[puntos.length - 1].timestamp;
    return {
        tripId, nodeId: registros[0].nodeId, inicio, fin,
        duracionMin: parseFloat(((new Date(fin).getTime() - new Date(inicio).getTime()) / 60_000).toFixed(1)),
        distanciaKm: calcularDistancia(puntos),
        spdPromedio: parseFloat((speeds.reduce((a, b) => a + b, 0) / speeds.length).toFixed(1)),
        spdMaxima:   parseFloat(Math.max(...speeds).toFixed(1)),
        puntos,
    };
}

export async function getViajesDeNodo(nodeId: string, desde: Date, hasta: Date): Promise<ResumenNodo> {
    const grupos = await prisma.node_breadcrumbs.groupBy({
        by: ['trip_id'], where: { nodeId, timestamp: { gte: desde, lte: hasta } },
        _min: { timestamp: true }, _max: { timestamp: true }, orderBy: { _min: { timestamp: 'desc' } },
    });
    const viajes: ViajeResumen[] = [];
    for (const g of grupos) {
        const inicio = g._min.timestamp!, fin = g._max.timestamp!;
        const puntos = await prisma.node_breadcrumbs.findMany({ where: { trip_id: g.trip_id }, orderBy: { timestamp: 'asc' }, select: { latitud: true, longitud: true } });
        viajes.push({
            tripId: g.trip_id, inicio: inicio.toISOString(), fin: fin.toISOString(),
            duracionMin: parseFloat(((fin.getTime() - inicio.getTime()) / 60_000).toFixed(1)),
            distanciaKm: calcularDistancia(puntos.map((p) => ({ lat: p.latitud, lon: p.longitud }))),
        });
    }
    return { nodeId, totalViajes: viajes.length, viajes };
}

export async function getNodosConActividad(desde: Date, hasta: Date): Promise<string[]> {
    const nodos = await prisma.node_breadcrumbs.findMany({ where: { timestamp: { gte: desde, lte: hasta } }, distinct: ['nodeId'], select: { nodeId: true } });
    return nodos.map((n) => n.nodeId);
}
