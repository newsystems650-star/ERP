import { runAlertCycle } from './nicAlerts.service';

const DIAS_HABILES  = [1, 2, 3, 4, 5, 6];
const HORAS_DISPARO = [9, 15];

let schedulerTimer: NodeJS.Timeout | undefined;

function debeDisparar(): boolean {
    const ahora = new Date();
    return DIAS_HABILES.includes(ahora.getDay())
        && HORAS_DISPARO.includes(ahora.getHours())
        && ahora.getMinutes() === 0;
}

function tick(): void {
    if (debeDisparar()) {
        console.log('[AlertScheduler] Disparo activado.');
        runAlertCycle().catch((e) => console.error('[AlertScheduler]', e));
    }
    schedulerTimer = setTimeout(tick, 60_000 - (Date.now() % 60_000));
}

export function startAlertScheduler(): void {
    console.log('[AlertScheduler] Activo — 9:00 y 15:00 días hábiles.');
    schedulerTimer = setTimeout(tick, 60_000 - (Date.now() % 60_000));
}

export function stopAlertScheduler(): void {
    if (schedulerTimer) { clearTimeout(schedulerTimer); console.log('[AlertScheduler] Detenido.'); }
}
