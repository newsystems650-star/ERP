import { whatsappEngine } from '../../core/whatsapp/whatsapp.client';

const TELEGRAM_TOKEN = process.env.TELEGRAM_BOT_TOKEN ?? '';

interface SendResult { ok: boolean; canal: string; error?: string; }

async function sendTelegram(chatId: string, mensaje: string): Promise<SendResult> {
    if (!TELEGRAM_TOKEN) return { ok: false, canal: 'telegram', error: 'Sin token' };
    try {
        const res  = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chatId, text: mensaje, parse_mode: 'Markdown' }),
        });
        const data = await res.json() as { ok: boolean; description?: string };
        return data.ok ? { ok: true, canal: 'telegram' } : { ok: false, canal: 'telegram', error: data.description };
    } catch (e) {
        return { ok: false, canal: 'telegram', error: String(e) };
    }
}

export async function notify(
    telefono:   string,
    telegramId: string | null,
    mensaje:    string
): Promise<SendResult[]> {
    const resultados: SendResult[] = [];
    if (telefono) {
        const r = await whatsappEngine.send(telefono, mensaje);
        resultados.push({ ...r, canal: 'whatsapp' });
    }
    if (telegramId && TELEGRAM_TOKEN) {
        resultados.push(await sendTelegram(telegramId, mensaje));
    }
    return resultados;
}
