import { prisma }  from '../../lib/prisma';
import { notify }  from './notifier';

const NIVELES = [
    { nivel: 1, diasDesde: 1,  diasHasta: 7,        cadenciaDias: 7 },
    { nivel: 2, diasDesde: 8,  diasHasta: 15,       cadenciaDias: 3 },
    { nivel: 3, diasDesde: 16, diasHasta: Infinity,  cadenciaDias: 1 },
] as const;

function buildMensaje(nivel: number, nombre: string, concepto: string, monto: number, dias: number): string {
    const m = `$${monto.toFixed(2)} MXN`;
    const d = `${dias} día${dias !== 1 ? 's' : ''}`;
    if (nivel === 1) return `📋 *Recordatorio — NicCore Madería*\n\nHola *${nombre}*, tienes un saldo pendiente:\n\n📦 ${concepto}\n💰 *${m}*\n📅 Vencido hace ${d}\n\n¡Gracias por tu atención!`;
    if (nivel === 2) return `⚠️ *Aviso de adeudo — NicCore Madería*\n\n${nombre}, tu adeudo lleva *${d}* sin liquidarse:\n\n📦 ${concepto}\n💰 *${m}*\n\nContáctanos hoy para evitar inconvenientes.`;
    return `🚨 *ADEUDO URGENTE — NicCore Madería*\n\n${nombre}, tu adeudo de *${m}* tiene *${d}* de retraso.\n\n📦 ${concepto}\n\n*Comunícate HOY.* De no recibir respuesta procederemos con acciones adicionales.`;
}

async function yaEnviado(cuentaId: string, nivel: number, cadenciaDias: number): Promise<boolean> {
    const desde = new Date();
    desde.setDate(desde.getDate() - cadenciaDias);
    const reg = await prisma.alertLog.findFirst({
        where: { cuentaId, nivel, enviado: true, createdAt: { gte: desde } },
    });
    return reg !== null;
}

export async function runAlertCycle(): Promise<void> {
    console.log('[NicAlerts] Iniciando ciclo...');
    const hoy = new Date(); hoy.setHours(0, 0, 0, 0);

    const cuentas = await prisma.cuentaPorCobrar.findMany({
        where: { estado: { in: ['pendiente', 'parcial'] }, fechaVence: { lt: hoy } },
        include: { cliente: true },
    });

    let enviadas = 0;
    for (const cuenta of cuentas) {
        const vence = new Date(cuenta.fechaVence); vence.setHours(0, 0, 0, 0);
        const dias  = Math.floor((hoy.getTime() - vence.getTime()) / 86_400_000);
        const regla = NIVELES.find((n) => dias >= n.diasDesde && dias <= n.diasHasta);
        if (!regla) continue;
        if (await yaEnviado(cuenta.id, regla.nivel, regla.cadenciaDias)) continue;

        const monto   = Number(cuenta.monto) - Number(cuenta.montoPagado);
        const mensaje = buildMensaje(regla.nivel, cuenta.cliente.nombre, cuenta.concepto, monto, dias);
        const results = await notify(cuenta.cliente.telefono, cuenta.cliente.telegramId ?? null, mensaje);

        for (const r of results) {
            await prisma.alertLog.create({
                data: { cuentaId: cuenta.id, canal: r.canal, nivel: regla.nivel, enviado: r.ok, error: r.error ?? null },
            });
        }
        if (results.some((r) => r.ok)) enviadas++;
    }
    console.log(`[NicAlerts] Ciclo completo. Enviadas: ${enviadas}`);
}
