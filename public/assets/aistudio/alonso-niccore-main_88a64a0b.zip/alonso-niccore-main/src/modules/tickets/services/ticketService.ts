export async function processSale(data: TicketInput) {
  return await prisma.$transaction(async (tx) => {
    // 1. Crear el Ticket (Status: PENDING)
    const ticket = await tx.ticket.create({
      data: {
        code: generateCode('SALE'),
        total: data.total,
        paymentMethod: data.method, // [EFECTIVO, TARJETA, TRANSFERENCIA, CRÉDITO]
        workshopStatus: data.hasMaquila ? 'PENDING' : 'NOT_REQUIRED',
        items: {
          create: data.items.map(item => ({
            productId: item.id,
            quantity: item.qty,
            cuttingInstructions: item.instructions, // Lo que va a la Hoja de Patio
          }))
        }
      }
    });

    // 2. Ley 4: El Motor C++ valida las medidas en segundo plano
    // No bloqueamos al cajero, enviamos la orden al Worker
    await redis.publish('maquila-tasks', JSON.stringify({ ticketId: ticket.id }));

    return ticket;
  });
}

