import { prisma } from "../../prisma";

export const findAll = async () => {
  return prisma.ticket.findMany({
    include: {
      items: true,
      user: true,
      customer: true,
      payments: true,
      reservations: true,
    },
  });
};

export const create = async (data: any) => {
  return prisma.ticket.create({
    data,
  });
};
