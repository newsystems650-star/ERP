import { z } from 'zod'

export const createTicketSchema = z.object({
  type: z.enum(['SALE', 'PURCHASE', 'ADJUSTMENT_IN', 'ADJUSTMENT_OUT', 'RETURN']),
  notes: z.string().optional(),
  items: z.array(z.object({
    productId: z.string(),
    quantity: z.number().positive(),
    unitPrice: z.number().nonnegative(),
    unit: z.enum(['M2', 'M3', 'KG', 'LITER', 'LINEAR_M', 'FEET', 'INCH', 'PIECE']),
  })).min(1, 'El ticket debe tener al menos un item'),
})

export type CreateTicketInput = z.infer<typeof createTicketSchema>
