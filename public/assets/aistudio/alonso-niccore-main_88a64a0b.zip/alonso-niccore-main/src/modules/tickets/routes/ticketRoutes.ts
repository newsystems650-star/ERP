import { FastifyInstance } from 'fastify';

export default async function ticketRoutes(fastify: FastifyInstance) {
  fastify.get('/', async (request, reply) => {
    return { status: 'ok', message: 'Rutas de Tickets operativas' };
  });
}
