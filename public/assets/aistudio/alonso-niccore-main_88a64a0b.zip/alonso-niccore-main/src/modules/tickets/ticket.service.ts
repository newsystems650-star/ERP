import { PrismaClient } from '@prisma/client';
import { getTenantContext } from '../../core/tenant/tenantContext';
import { WoodInventoryService } from '../wood-inventory/wood.service';
import { EventBus } from '../../core/event-store/eventBus';

const prisma = new PrismaClient();

export class TicketService {
  static async createSale(data: any) {
    const { tenantId, userId } = getTenantContext();

    return await prisma.$transaction(async (tx) => {
      // 1. CÁLCULO VORTEX (C++) - Obtenemos subtotal y ganancia
      const vortex = await WoodInventoryService.executeFullSale(data.woodSpecs);
      
      const subtotal = vortex.data.profitTotal + (vortex.data.totalFeet * data.woodSpecs.costPerFoot);
      const taxRate = 0.16; // 16% IVA
      const taxAmount = subtotal * taxRate;
      const total = subtotal + taxAmount;

      // 2. CREACIÓN DE TICKET CON TODA LA DATA
      const ticket = await tx.ticket.create({
        data: {
          code: 'TK-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
          type: 'SALE',
          status: 'CONFIRMED',
          tenantId,
          userId,
          subtotal,
          taxAmount,
          taxRate,
          total,
          paymentMethod: data.paymentMethod || 'CASH',
          deliveryType: data.deliveryType || 'IMMEDIATE',
          workshopStatus: data.requiresCutting ? 'PENDING_WORKSHOP' : 'NOT_REQUIRED',
          notes: data.notes
        }
      });

      // 3. REGISTRO DE PAGO (Payment Model)
      await tx.payment.create({
        data: {
          amount: total,
          method: data.paymentMethod || 'CASH',
          ticketId: ticket.id
        }
      });

      // 4. DISPARAR EVENTOS (Telegram, Hoja de Patio, Stock)
      EventBus.publish({
        type: 'SALE_CONFIRMED',
        tenantId,
        payload: { ticket, wood: vortex.data }
      });

      return ticket;
    });
  }
}
