import { Request, Response } from "express";
import * as service from "./tickets.service";

export const getTickets = async (_: Request, res: Response) => {
  const data = await service.findAll();
  res.json(data);
};

export const createTicket = async (req: Request, res: Response) => {
  const data = await service.create(req.body);
  res.json(data);
};
