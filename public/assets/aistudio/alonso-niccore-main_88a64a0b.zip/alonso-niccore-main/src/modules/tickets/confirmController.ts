export const confirmTicket = async (req: Request, res: Response) => {
  const { ticketId, paymentData, deliveryData } = req.body;

  try {
    // 1. DECIDE: ¿Es pago completo, crédito o parcial?
    const result = await ticketService.finalize(ticketId, paymentData);

    // 2. MONTA Y EXPORTA: Disparamos las acciones paralelas
    // No usamos 'await' para el SAT o el C++ aquí, lo mandamos a BullMQ
    await queueService.add('process-maquila', { ticketId });
    
    if (deliveryData.type === 'DELIVERY') {
      await queueService.add('logistics-dispatch', { 
        ticketId, 
        address: deliveryData.address,
        priority: deliveryData.isUrgent ? 1 : 10
      });
    }

    // 3. RESPUESTA INMEDIATA (Ley 3: Cero milisegundos de espera)
    return res.status(200).json({ 
      status: 'CONFIRMED', 
      message: 'Venta cerrada. Documentos en proceso.' 
    });

  } catch (error) {
    // AUDITORÍA Y AUTORREPARACIÓN
    return errorHandler.handle(error, res);
  }
};
