export async function calcularCortesTriplay(medidaHoja: string, piezasSolicitadas: number, medidaCorte: string) {
  // LEY 4: C++ ES MOTOR, NO DECISOR
  // Enviamos al motor de C++ (Optimizer)
  const calculoNativo = await engineBridge.calculateOptimization({
    materiaPrima: medidaHoja,    // 122x244
    objetivo: medidaCorte,       // 60x122
    cantidad: piezasSolicitadas   // 10
  });

  // El motor nos dice: "4 piezas por hoja. Total 2.5 hojas necesarias"
  const hojasAVender = Math.ceil(calculoNativo.hojasNecesarias); 
  
  return {
    hojasAVender,        // Esto es lo que se cobra (Materia prima)
    piezasFinales: piezasSolicitadas,
    costoMaquila: hojasAVender * PRECIO_CORTE_HOJA, // Cobro por el servicio de corte
    diagramaUrl: calculoNativo.diagramaID // Lo que se imprime para Patio
  };
}
