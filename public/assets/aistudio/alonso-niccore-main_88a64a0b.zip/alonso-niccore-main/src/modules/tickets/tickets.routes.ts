import { Router } from "express";
import { getTickets, createTicket } from "./tickets.controller";

const router = Router();

router.get("/", getTickets);
router.post("/", createTicket);

export default router;
