import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'
import { UnauthorizedError, ForbiddenError } from '../../../shared/errors/AppError'

export interface AuthRequest extends Request {
  user?: { id: string; email: string; role: string; companyId?: string }
}

export function authenticate(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization
  if (!header?.startsWith('Bearer ')) return next(new UnauthorizedError('Token requerido'))
  try {
    const token = header.split(' ')[1]
    req.user = jwt.verify(token, process.env.JWT_SECRET as string) as AuthRequest['user']
    next()
  } catch {
    next(new UnauthorizedError('Token inválido o expirado'))
  }
}

export function authorize(...roles: string[]) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(new ForbiddenError('No tienes permisos para esta acción'))
    }
    next()
  }
}
