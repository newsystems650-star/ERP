import { Router } from 'express'
import { z } from 'zod'
import { register, login, me } from '../services/authService'
import { authenticate, AuthRequest } from '../middleware/authenticate'

const router = Router()

const registerSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(['ADMIN', 'MANAGER', 'OPERATOR', 'VIEWER']).optional()
})

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
})

router.post('/register', async (req, res) => {
  const data = registerSchema.parse(req.body)
  const user = await register(data)
  res.status(201).json({ user })
})

router.post('/login', async (req, res) => {
  const { email, password } = loginSchema.parse(req.body)
  const result = await login(email, password)
  res.json(result)
})

router.get('/me', authenticate, async (req: AuthRequest, res) => {
  const user = await me(req.user!.id)
  res.json({ user })
})

export default router
