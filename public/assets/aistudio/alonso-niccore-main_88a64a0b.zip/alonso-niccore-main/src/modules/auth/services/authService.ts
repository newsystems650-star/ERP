import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { prisma } from '../../../infrastructure/database/prisma'
import { ConflictError, UnauthorizedError } from '../../../shared/errors/AppError'

export async function register(data: {
  name: string
  email: string
  password: string
  role?: 'ADMIN' | 'MANAGER' | 'OPERATOR' | 'VIEWER'
}) {
  const exists = await prisma.user.findUnique({ where: { email: data.email } })
  if (exists) throw new ConflictError('El email ya está registrado')

  const hashed = await bcrypt.hash(data.password, 12)
  const user = await prisma.user.create({
    data: { name: data.name, email: data.email, password: hashed, role: data.role || 'OPERATOR' },
    select: { id: true, name: true, email: true, role: true, createdAt: true }
  })
  return user
}

export async function login(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email } })
  if (!user || !user.active) throw new UnauthorizedError('Credenciales inválidas')

  const valid = await bcrypt.compare(password, user.password)
  if (!valid) throw new UnauthorizedError('Credenciales inválidas')

  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET as string,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  )

  return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role } }
}

export async function me(userId: string) {
  return prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, name: true, email: true, role: true, active: true, createdAt: true }
  })
}
