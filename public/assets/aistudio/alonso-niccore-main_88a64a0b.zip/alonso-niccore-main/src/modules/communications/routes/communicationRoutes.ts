import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import { sendCustomerMessage, getCommunications, bulkCreditAlerts, sendCreditAlert } from '../services/communicationService'

const router = Router()
router.use(authenticate)
router.use(authorize('ADMIN', 'MANAGER'))

router.get('/customer/:customerId', async (req, res) => {
  const data = await getCommunications(req.params.customerId)
  res.json({ data })
})

router.post('/send', async (req: AuthRequest, res) => {
  const schema = z.object({
    customerId: z.string(),
    channel: z.enum(['WHATSAPP', 'EMAIL']),
    message: z.string().min(1),
  })
  const data = schema.parse(req.body)
  const result = await sendCustomerMessage({ ...data, userId: req.user!.id })
  res.json(result)
})

router.post('/credit-alert/:customerId', async (req: AuthRequest, res) => {
  const result = await sendCreditAlert(req.params.customerId, req.user!.id)
  res.json(result)
})

router.post('/bulk-credit-alerts', async (req: AuthRequest, res) => {
  const result = await bulkCreditAlerts(req.user!.id)
  res.json(result)
})

export default router
