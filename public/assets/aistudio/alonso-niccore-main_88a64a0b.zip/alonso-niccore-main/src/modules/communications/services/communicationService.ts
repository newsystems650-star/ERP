import { prisma } from '../../../infrastructure/database/prisma'
import { sendAlert } from '../../../infrastructure/monitor/telegram'
import { NotFoundError } from '../../../shared/errors/AppError'

export async function sendCustomerMessage(data: {
  customerId: string
  channel: 'WHATSAPP' | 'EMAIL'
  message: string
  userId: string
  automatic?: boolean
}) {
  const customer = await prisma.customer.findUnique({
    where: { id: data.customerId },
    select: { name: true, phone: true, email: true },
  })
  if (!customer) throw new NotFoundError('Cliente')

  // Registrar comunicación
  const comm = await prisma.customerCommunication.create({
    data: {
      channel: data.channel,
      direction: 'OUTBOUND',
      message: data.message,
      status: 'SENT',
      customerId: data.customerId,
      userId: data.userId,
    },
  })

  // TODO: Integrar con Twilio para WhatsApp real
  // TODO: Integrar con SendGrid para email real
  // Por ahora registra y simula envío
  console.log(`📱 Mensaje ${data.channel} a ${customer.name}: ${data.message}`)

  return { comm, customer }
}

export async function sendCreditAlert(customerId: string, userId: string) {
  const customer = await prisma.customer.findUnique({
    where: { id: customerId },
    include: {
      credits: {
        where: { status: 'ACTIVE' },
        orderBy: { createdAt: 'desc' },
        take: 1,
      },
    },
  })
  if (!customer) throw new NotFoundError('Cliente')

  const credit = customer.credits[0]
  if (!credit) return null

  const message = `Estimado/a ${customer.name}, le recordamos que tiene un saldo pendiente de $${Number(credit.balance).toLocaleString('es-MX')} en Maderería NicCore. Para cualquier duda comuníquese con nosotros. Gracias.`

  return sendCustomerMessage({
    customerId,
    channel: customer.phone ? 'WHATSAPP' : 'EMAIL',
    message,
    userId,
    automatic: true,
  })
}

export async function getCommunications(customerId: string) {
  return prisma.customerCommunication.findMany({
    where: { customerId },
    orderBy: { sentAt: 'desc' },
    include: { user: { select: { name: true } } },
  })
}

export async function bulkCreditAlerts(userId: string) {
  const activeCredits = await prisma.credit.findMany({
    where: { status: 'ACTIVE' },
    include: { customer: true },
    distinct: ['customerId'],
  })

  const results = await Promise.allSettled(
    activeCredits.map(c => sendCreditAlert(c.customerId, userId))
  )

  const sent = results.filter(r => r.status === 'fulfilled').length
  const failed = results.filter(r => r.status === 'rejected').length

  await sendAlert(`📨 Alertas de crédito enviadas\n\n✅ Enviadas: ${sent}\n❌ Fallidas: ${failed}`)

  return { sent, failed, total: activeCredits.length }
}
