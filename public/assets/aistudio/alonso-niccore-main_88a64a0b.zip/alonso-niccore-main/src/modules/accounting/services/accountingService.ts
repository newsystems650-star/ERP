import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError } from '../../../shared/errors/AppError'

export async function createExpense(data: {
  type: 'SALARY' | 'SUPPLIER' | 'RENT' | 'UTILITIES' | 'MAINTENANCE' | 'TAXES' | 'OTHER'
  category: string
  description: string
  amount: number
  applyTax?: boolean
  taxRate?: number
  reference?: string
  date?: string
  userId: string
}) {
  const tax = data.applyTax ? data.amount * (data.taxRate || 0.16) : 0
  return prisma.expense.create({
    data: {
      type: data.type,
      category: data.category,
      description: data.description,
      amount: data.amount,
      tax,
      total: data.amount + tax,
      reference: data.reference,
      date: data.date ? new Date(data.date) : new Date(),
      userId: data.userId,
    },
  })
}

export async function getExpenses(filters: {
  from?: string
  to?: string
  type?: string
  page?: number
  limit?: number
}) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit
  const where: any = {}
  if (filters.type) where.type = filters.type
  if (filters.from || filters.to) {
    where.date = {}
    if (filters.from) where.date.gte = new Date(filters.from)
    if (filters.to) where.date.lte = new Date(filters.to)
  }

  const [data, total, aggregate] = await prisma.$transaction([
    prisma.expense.findMany({
      where, skip, take: limit,
      orderBy: { date: 'desc' },
      include: { user: { select: { name: true } } },
    }),
    prisma.expense.count({ where }),
    prisma.expense.aggregate({ where, _sum: { total: true, tax: true } }),
  ])

  return {
    data,
    meta: { page, limit, total, pages: Math.ceil(total / limit) },
    totales: {
      gastos: Number(aggregate._sum.total || 0),
      impuestos: Number(aggregate._sum.tax || 0),
    },
  }
}

export async function getFinancialSummary(from?: string, to?: string) {
  const dateFilter: any = {}
  if (from || to) {
    dateFilter.date = {}
    if (from) dateFilter.date.gte = new Date(from)
    if (to) dateFilter.date.lte = new Date(to)
  }

  const ticketFilter: any = { status: 'CONFIRMED', type: 'SALE' }
  if (from || to) {
    ticketFilter.createdAt = {}
    if (from) ticketFilter.createdAt.gte = new Date(from)
    if (to) ticketFilter.createdAt.lte = new Date(to)
  }

  const [ventas, gastosPorTipo, nomina] = await prisma.$transaction([
    prisma.ticket.aggregate({
      where: ticketFilter,
      _sum: { total: true },
      _count: true,
    }),
    prisma.expense.groupBy({
      by: ['type'],
      where: dateFilter,
      _sum: { total: true },
      _count: true,
    }),
    prisma.payroll.aggregate({
      where: { paid: true, ...(from || to ? { paidAt: { gte: from ? new Date(from) : undefined, lte: to ? new Date(to) : undefined } } : {}) },
      _sum: { total: true },
    }),
  ])

  const totalVentas = Number(ventas._sum.total || 0)
  const totalGastos = gastosPorTipo.reduce((s, g) => s + Number(g._sum.total || 0), 0)
  const totalNomina = Number(nomina._sum.total || 0)
  const utilidad = totalVentas - totalGastos - totalNomina

  return {
    ventas: { total: totalVentas, tickets: ventas._count },
    gastos: {
      total: totalGastos,
      porTipo: gastosPorTipo.map(g => ({ tipo: g.type, total: Number(g._sum.total || 0), count: g._count })),
    },
    nomina: { total: totalNomina },
    utilidad,
    margen: totalVentas > 0 ? ((utilidad / totalVentas) * 100).toFixed(2) + '%' : '0%',
  }
}

export async function createEmployee(data: {
  name: string
  position: string
  salary: number
  payPeriod?: 'WEEKLY' | 'BIWEEKLY' | 'MONTHLY'
  startDate: string
}) {
  return prisma.employee.create({
    data: {
      name: data.name,
      position: data.position,
      salary: data.salary,
      payPeriod: data.payPeriod || 'BIWEEKLY',
      startDate: new Date(data.startDate),
    },
  })
}

export async function getEmployees() {
  return prisma.employee.findMany({
    where: { active: true },
    include: {
      payrolls: { orderBy: { createdAt: 'desc' }, take: 1 },
    },
    orderBy: { name: 'asc' },
  })
}

export async function generatePayroll(employeeId: string, data: {
  periodStart: string
  periodEnd: string
  bonuses?: number
  deductions?: number
  notes?: string
}) {
  const employee = await prisma.employee.findUnique({ where: { id: employeeId } })
  if (!employee) throw new NotFoundError('Empleado')

  const total = Number(employee.salary) + (data.bonuses || 0) - (data.deductions || 0)

  return prisma.payroll.create({
    data: {
      periodStart: new Date(data.periodStart),
      periodEnd: new Date(data.periodEnd),
      baseSalary: employee.salary,
      bonuses: data.bonuses || 0,
      deductions: data.deductions || 0,
      total,
      notes: data.notes,
      employeeId,
    },
    include: { employee: { select: { name: true, position: true } } },
  })
}

export async function payPayroll(payrollId: string) {
  return prisma.payroll.update({
    where: { id: payrollId },
    data: { paid: true, paidAt: new Date() },
    include: { employee: { select: { name: true } } },
  })
}

export async function getPayrolls(filters: { paid?: boolean; employeeId?: string }) {
  return prisma.payroll.findMany({
    where: {
      ...(filters.paid !== undefined ? { paid: filters.paid } : {}),
      ...(filters.employeeId ? { employeeId: filters.employeeId } : {}),
    },
    orderBy: { createdAt: 'desc' },
    include: { employee: { select: { name: true, position: true } } },
  })
}
