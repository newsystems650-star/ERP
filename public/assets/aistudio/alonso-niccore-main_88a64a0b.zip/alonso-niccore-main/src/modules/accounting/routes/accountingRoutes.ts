import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import {
  createExpense, getExpenses, getFinancialSummary,
  createEmployee, getEmployees, generatePayroll, payPayroll, getPayrolls,
} from '../services/accountingService'

const router = Router()
router.use(authenticate)
router.use(authorize('ADMIN', 'MANAGER'))

// GASTOS
router.get('/gastos', async (req, res) => {
  const result = await getExpenses({
    from: req.query.from as string,
    to: req.query.to as string,
    type: req.query.type as string,
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 20,
  })
  res.json(result)
})

router.post('/gastos', async (req: AuthRequest, res) => {
  const schema = z.object({
    type: z.enum(['SALARY','SUPPLIER','RENT','UTILITIES','MAINTENANCE','TAXES','OTHER']),
    category: z.string().min(1),
    description: z.string().min(1),
    amount: z.number().positive(),
    applyTax: z.boolean().optional(),
    taxRate: z.number().optional(),
    reference: z.string().optional(),
    date: z.string().optional(),
  })
  const data = schema.parse(req.body)
  const expense = await createExpense({ ...data, userId: req.user!.id })
  res.status(201).json({ expense })
})

// RESUMEN FINANCIERO
router.get('/resumen', async (req, res) => {
  const data = await getFinancialSummary(req.query.from as string, req.query.to as string)
  res.json(data)
})

// EMPLEADOS
router.get('/empleados', async (req, res) => {
  const data = await getEmployees()
  res.json({ data })
})

router.post('/empleados', async (req, res) => {
  const schema = z.object({
    name: z.string().min(2),
    position: z.string().min(1),
    salary: z.number().positive(),
    payPeriod: z.enum(['WEEKLY','BIWEEKLY','MONTHLY']).optional(),
    startDate: z.string(),
  })
  const data = schema.parse(req.body)
  const employee = await createEmployee(data)
  res.status(201).json({ employee })
})

// NÓMINA
router.get('/nomina', async (req, res) => {
  const data = await getPayrolls({
    paid: req.query.paid === 'true' ? true : req.query.paid === 'false' ? false : undefined,
    employeeId: req.query.employeeId as string,
  })
  res.json({ data })
})

router.post('/nomina/:employeeId', async (req, res) => {
  const schema = z.object({
    periodStart: z.string(),
    periodEnd: z.string(),
    bonuses: z.number().optional(),
    deductions: z.number().optional(),
    notes: z.string().optional(),
  })
  const data = schema.parse(req.body)
  const payroll = await generatePayroll(req.params.employeeId, data)
  res.status(201).json({ payroll })
})

router.patch('/nomina/:id/pagar', async (req, res) => {
  const payroll = await payPayroll(req.params.id)
  res.json({ payroll })
})

export default router
