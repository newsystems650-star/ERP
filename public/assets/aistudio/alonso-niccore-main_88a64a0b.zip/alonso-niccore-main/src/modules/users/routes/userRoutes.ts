import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import { getUsers, getUserById, updateUser, changePassword, deleteUser } from '../services/userService'

const router = Router()
router.use(authenticate)

router.get('/', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const users = await getUsers()
  res.json({ data: users })
})

router.get('/:id', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const user = await getUserById(req.params.id)
  res.json({ user })
})

router.put('/:id', authorize('ADMIN'), async (req, res) => {
  const schema = z.object({
    name: z.string().min(2).optional(),
    email: z.string().email().optional(),
    role: z.enum(['ADMIN', 'MANAGER', 'OPERATOR', 'VIEWER']).optional(),
    active: z.boolean().optional(),
  })
  const data = schema.parse(req.body)
  const user = await updateUser(req.params.id, data)
  res.json({ user })
})

router.patch('/me/password', async (req: AuthRequest, res) => {
  const schema = z.object({
    currentPassword: z.string().min(1),
    newPassword: z.string().min(6),
  })
  const { currentPassword, newPassword } = schema.parse(req.body)
  const result = await changePassword(req.user!.id, currentPassword, newPassword)
  res.json(result)
})

router.delete('/:id', authorize('ADMIN'), async (req: AuthRequest, res) => {
  const result = await deleteUser(req.params.id, req.user!.id)
  res.json({ user: result })
})

export default router
