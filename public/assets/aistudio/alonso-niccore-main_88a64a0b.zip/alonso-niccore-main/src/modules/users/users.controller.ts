import { Request, Response } from "express";
import * as service from "./users.service";

export const getUsers = async (_: Request, res: Response) => {
  const data = await service.findAll();
  res.json(data);
};

export const createUser = async (req: Request, res: Response) => {
  const data = await service.create(req.body);
  res.json(data);
};
