import { prisma } from "../../prisma";

export const findAll = async () => {
  return prisma.user.findMany();
};

export const create = async (data: any) => {
  return prisma.user.create({
    data,
  });
};
