import bcrypt from 'bcryptjs'
import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError, ConflictError, ForbiddenError } from '../../../shared/errors/AppError'

export async function getUsers() {
  return prisma.user.findMany({
    select: { id: true, name: true, email: true, role: true, active: true, createdAt: true },
    orderBy: { createdAt: 'desc' },
  })
}

export async function getUserById(id: string) {
  const user = await prisma.user.findUnique({
    where: { id },
    select: { id: true, name: true, email: true, role: true, active: true, createdAt: true },
  })
  if (!user) throw new NotFoundError('Usuario')
  return user
}

export async function updateUser(id: string, data: {
  name?: string
  email?: string
  role?: 'ADMIN' | 'MANAGER' | 'OPERATOR' | 'VIEWER'
  active?: boolean
}) {
  await getUserById(id)
  if (data.email) {
    const exists = await prisma.user.findFirst({
      where: { email: data.email, NOT: { id } },
    })
    if (exists) throw new ConflictError('El email ya está en uso')
  }
  return prisma.user.update({
    where: { id },
    data,
    select: { id: true, name: true, email: true, role: true, active: true, updatedAt: true },
  })
}

export async function changePassword(id: string, currentPassword: string, newPassword: string) {
  const user = await prisma.user.findUnique({ where: { id } })
  if (!user) throw new NotFoundError('Usuario')

  const valid = await bcrypt.compare(currentPassword, user.password)
  if (!valid) throw new ForbiddenError('Contraseña actual incorrecta')

  const hashed = await bcrypt.hash(newPassword, 12)
  await prisma.user.update({ where: { id }, data: { password: hashed } })
  return { message: 'Contraseña actualizada correctamente' }
}

export async function deleteUser(id: string, requesterId: string) {
  if (id === requesterId) throw new ForbiddenError('No puedes eliminarte a ti mismo')
  await getUserById(id)
  return prisma.user.update({
    where: { id },
    data: { active: false },
    select: { id: true, name: true, active: true },
  })
}
