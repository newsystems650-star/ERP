import { PrismaClient } from '@prisma/client';
import { getTenantContext } from '../../core/tenant/tenantContext';

const prisma = new PrismaClient();

export class UserService {
  static async getAll() {
    const { tenantId } = getTenantContext();
    // Filtro obligatorio: Ningún usuario puede ver gente de otra empresa
    return await prisma.user.findMany({
      where: { tenantId }
    });
  }

  static async create(userData: any) {
    const { tenantId } = getTenantContext();
    return await prisma.user.create({
      data: {
        ...userData,
        tenantId // Inyectamos el ADN de la empresa automáticamente
      }
    });
  }
}
