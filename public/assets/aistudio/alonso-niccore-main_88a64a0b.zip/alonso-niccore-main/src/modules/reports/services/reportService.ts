import ExcelJS from 'exceljs'
import PDFDocument from 'pdfkit'
import { prisma } from '../../../infrastructure/database/prisma'

export async function getReportData(filters: {
  from: Date
  to: Date
  type?: string
}) {
  const where: any = {
    createdAt: { gte: filters.from, lte: filters.to },
    status: 'CONFIRMED',
  }
  if (filters.type) where.type = filters.type

  return prisma.ticket.findMany({
    where,
    orderBy: { createdAt: 'asc' },
    include: {
      user: { select: { name: true } },
      customer: { select: { name: true, rfc: true } },
      items: { include: { product: { select: { name: true, sku: true } } } },
    },
  })
}

export async function generateExcel(filters: { from: Date; to: Date; type?: string }): Promise<Buffer> {
  const tickets = await getReportData(filters)

  const wb = new ExcelJS.Workbook()
  wb.creator = 'NicPlataform'
  wb.created = new Date()

  // Hoja de resumen
  const summary = wb.addWorksheet('Resumen')
  summary.columns = [
    { header: 'Código', key: 'code', width: 20 },
    { header: 'Tipo', key: 'type', width: 15 },
    { header: 'Cliente', key: 'customer', width: 25 },
    { header: 'Usuario', key: 'user', width: 20 },
    { header: 'Total', key: 'total', width: 15 },
    { header: 'Fecha', key: 'date', width: 20 },
  ]

  // Estilo encabezado
  summary.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } }
  summary.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2563EB' } }

  let totalGeneral = 0
  tickets.forEach((t) => {
    summary.addRow({
      code: t.code,
      type: t.type,
      customer: t.customer?.name || 'Sin cliente',
      user: t.user.name,
      total: Number(t.total),
      date: t.createdAt.toLocaleString('es-MX'),
    })
    totalGeneral += Number(t.total)
  })

  // Fila de total
  const totalRow = summary.addRow({ code: 'TOTAL', total: totalGeneral })
  totalRow.font = { bold: true }
  totalRow.getCell('total').numFmt = '"$"#,##0.00'

  // Formato moneda
  summary.getColumn('total').numFmt = '"$"#,##0.00'

  // Hoja de detalle
  const detail = wb.addWorksheet('Detalle')
  detail.columns = [
    { header: 'Ticket', key: 'ticket', width: 20 },
    { header: 'Producto', key: 'product', width: 25 },
    { header: 'SKU', key: 'sku', width: 15 },
    { header: 'Cantidad', key: 'qty', width: 12 },
    { header: 'Unidad', key: 'unit', width: 10 },
    { header: 'Precio Unit.', key: 'price', width: 15 },
    { header: 'Subtotal', key: 'subtotal', width: 15 },
  ]
  detail.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } }
  detail.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2563EB' } }

  tickets.forEach((t) => {
    t.items.forEach((i) => {
      detail.addRow({
        ticket: t.code,
        product: i.product.name,
        sku: i.product.sku,
        qty: Number(i.quantity),
        unit: i.unit,
        price: Number(i.unitPrice),
        subtotal: Number(i.subtotal),
      })
    })
  })
  detail.getColumn('price').numFmt = '"$"#,##0.00'
  detail.getColumn('subtotal').numFmt = '"$"#,##0.00'

  const buf = await wb.xlsx.writeBuffer()
  return Buffer.from(buf)
}

export async function generatePDF(filters: { from: Date; to: Date; type?: string }): Promise<Buffer> {
  const tickets = await getReportData(filters)

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 40, size: 'A4' })
    const chunks: Buffer[] = []

    doc.on('data', (c) => chunks.push(c))
    doc.on('end', () => resolve(Buffer.concat(chunks)))
    doc.on('error', reject)

    // Header
    doc.fontSize(18).font('Helvetica-Bold').text('NicPlataform', { align: 'center' })
    doc.fontSize(12).font('Helvetica').text('Reporte de Ventas', { align: 'center' })
    doc.text(`Período: ${filters.from.toLocaleDateString('es-MX')} — ${filters.to.toLocaleDateString('es-MX')}`, { align: 'center' })
    doc.moveDown()

    // Resumen
    const total = tickets.reduce((s, t) => s + Number(t.total), 0)
    doc.font('Helvetica-Bold').text(`Total de tickets: ${tickets.length}`)
    doc.text(`Total general: $${total.toLocaleString('es-MX', { minimumFractionDigits: 2 })}`)
    doc.moveDown()

    // Tabla
    doc.font('Helvetica-Bold').fontSize(10)
    doc.text('Código', 40, doc.y, { continued: true, width: 120 })
    doc.text('Cliente', 160, doc.y, { continued: true, width: 150 })
    doc.text('Usuario', 310, doc.y, { continued: true, width: 100 })
    doc.text('Total', 410, doc.y, { width: 100 })
    doc.moveTo(40, doc.y).lineTo(555, doc.y).stroke()
    doc.moveDown(0.3)

    doc.font('Helvetica').fontSize(9)
    tickets.forEach((t) => {
      if (doc.y > 700) doc.addPage()
      doc.text(t.code, 40, doc.y, { continued: true, width: 120 })
      doc.text(t.customer?.name || '-', 160, doc.y, { continued: true, width: 150 })
      doc.text(t.user.name, 310, doc.y, { continued: true, width: 100 })
      doc.text(`$${Number(t.total).toLocaleString('es-MX')}`, 410, doc.y, { width: 100 })
    })

    doc.moveDown()
    doc.moveTo(40, doc.y).lineTo(555, doc.y).stroke()
    doc.font('Helvetica-Bold').text(`TOTAL: $${total.toLocaleString('es-MX', { minimumFractionDigits: 2 })}`, { align: 'right' })

    doc.end()
  })
}

export async function getDebtorsReport() {
  const credits = await prisma.credit.findMany({
    where: { status: { in: ['ACTIVE', 'OVERDUE'] } },
    include: {
      customer: { select: { name: true, phone: true, email: true } },
      ticket: { select: { code: true, createdAt: true } },
      payments: { orderBy: { createdAt: 'desc' }, take: 1 },
    },
    orderBy: { balance: 'desc' },
  })

  const totalDeuda = credits.reduce((s, c) => s + Number(c.balance), 0)

  return {
    totalDeuda,
    count: credits.length,
    deudores: credits.map((c) => ({
      cliente: c.customer.name,
      telefono: c.customer.phone,
      ticket: c.ticket?.code,
      deuda: Number(c.balance),
      total: Number(c.amount),
      vencimiento: c.dueDate,
      ultimoPago: c.payments[0]?.createdAt || null,
      status: c.status,
    })),
  }
}
