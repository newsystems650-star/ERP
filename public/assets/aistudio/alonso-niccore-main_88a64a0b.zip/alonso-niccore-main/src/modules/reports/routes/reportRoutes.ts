import { Router } from 'express'
import { authenticate, authorize } from '../../auth/middleware/authenticate'
import { generateExcel, generatePDF, getDebtorsReport } from '../services/reportService'

const router = Router()
router.use(authenticate)
router.use(authorize('ADMIN', 'MANAGER'))

router.get('/ventas/excel', async (req, res) => {
  const from = new Date(req.query.from as string || new Date().setHours(0,0,0,0))
  const to = new Date(req.query.to as string || new Date().setHours(23,59,59,999))
  const buf = await generateExcel({ from, to, type: req.query.type as string })
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  res.setHeader('Content-Disposition', `attachment; filename="ventas-${from.toISOString().slice(0,10)}.xlsx"`)
  res.send(buf)
})

router.get('/ventas/pdf', async (req, res) => {
  const from = new Date(req.query.from as string || new Date().setHours(0,0,0,0))
  const to = new Date(req.query.to as string || new Date().setHours(23,59,59,999))
  const buf = await generatePDF({ from, to, type: req.query.type as string })
  res.setHeader('Content-Type', 'application/pdf')
  res.setHeader('Content-Disposition', `attachment; filename="ventas-${from.toISOString().slice(0,10)}.pdf"`)
  res.send(buf)
})

router.get('/deudores', async (req, res) => {
  const data = await getDebtorsReport()
  res.json(data)
})

export default router
