import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError, AppError, ForbiddenError } from '../../../shared/errors/AppError'

export async function createCredit(data: {
  customerId: string
  ticketId: string
  amount: number
  dueDate?: string
  notes?: string
  authorizedBy: string
  authorRole: string
}) {
  if (!['ADMIN', 'MANAGER'].includes(data.authorRole)) {
    throw new ForbiddenError('Solo ADMIN o MANAGER pueden autorizar fiado')
  }

  const ticket = await prisma.ticket.findUnique({ where: { id: data.ticketId } })
  if (!ticket) throw new NotFoundError('Ticket')
  if (ticket.credit) throw new AppError('Este ticket ya tiene un crédito asociado')

  return prisma.$transaction(async (tx) => {
    const credit = await tx.credit.create({
      data: {
        amount: data.amount,
        balance: data.amount,
        status: 'ACTIVE',
        dueDate: data.dueDate ? new Date(data.dueDate) : null,
        notes: data.notes,
        customerId: data.customerId,
        ticketId: data.ticketId,
      },
      include: { customer: { select: { name: true } }, ticket: { select: { code: true } } },
    })

    await tx.auditLog.create({
      data: {
        action: 'CREDIT_CREATED',
        entity: 'Credit',
        entityId: credit.id,
        after: { amount: data.amount, customerId: data.customerId },
        userId: data.authorizedBy,
        ticketId: data.ticketId,
      },
    })

    return credit
  })
}

export async function getCredits(filters: { status?: string; customerId?: string; page?: number; limit?: number }) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit
  const where: any = {}
  if (filters.status) where.status = filters.status
  if (filters.customerId) where.customerId = filters.customerId

  const [data, total] = await prisma.$transaction([
    prisma.credit.findMany({
      where, skip, take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        customer: { select: { name: true, phone: true } },
        ticket: { select: { code: true, total: true } },
        payments: { orderBy: { createdAt: 'desc' }, take: 3 },
      },
    }),
    prisma.credit.count({ where }),
  ])

  return { data, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}

export async function registerPayment(creditId: string, data: {
  amount: number
  method: 'CASH' | 'CARD' | 'TRANSFER' | 'CHECK' | 'CREDIT'
  notes?: string
  userId: string
}) {
  const credit = await prisma.credit.findUnique({ where: { id: creditId } })
  if (!credit) throw new NotFoundError('Crédito')
  if (credit.status === 'PAID') throw new AppError('Este crédito ya está pagado')
  if (credit.status === 'CANCELLED') throw new AppError('Este crédito fue cancelado')
  if (data.amount > Number(credit.balance)) throw new AppError(`El pago excede el saldo. Saldo actual: $${credit.balance}`)

  return prisma.$transaction(async (tx) => {
    const payment = await tx.creditPayment.create({
      data: { amount: data.amount, method: data.method, notes: data.notes, creditId },
    })

    const newBalance = Number(credit.balance) - data.amount
    const newStatus = newBalance <= 0 ? 'PAID' : 'ACTIVE'

    await tx.credit.update({
      where: { id: creditId },
      data: { balance: newBalance, status: newStatus },
    })

    await tx.auditLog.create({
      data: {
        action: 'CREDIT_PAYMENT',
        entity: 'Credit',
        entityId: creditId,
        before: { balance: Number(credit.balance) },
        after: { balance: newBalance, status: newStatus, payment: data.amount },
        userId: data.userId,
      },
    })

    return { payment, newBalance, status: newStatus }
  })
}
