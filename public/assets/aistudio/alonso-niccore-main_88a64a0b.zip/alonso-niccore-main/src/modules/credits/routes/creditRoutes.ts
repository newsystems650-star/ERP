import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize, AuthRequest } from '../../auth/middleware/authenticate'
import { createCredit, getCredits, registerPayment } from '../services/creditService'

const router = Router()
router.use(authenticate)

router.get('/', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const result = await getCredits({
    status: req.query.status as string,
    customerId: req.query.customerId as string,
    page: Number(req.query.page) || 1,
    limit: Number(req.query.limit) || 20,
  })
  res.json(result)
})

router.post('/', authorize('ADMIN', 'MANAGER'), async (req: AuthRequest, res) => {
  const schema = z.object({
    customerId: z.string(),
    ticketId: z.string(),
    amount: z.number().positive(),
    dueDate: z.string().datetime().optional(),
    notes: z.string().optional(),
  })
  const data = schema.parse(req.body)
  const credit = await createCredit({ ...data, authorizedBy: req.user!.id, authorRole: req.user!.role })
  res.status(201).json({ credit })
})

router.post('/:id/pay', authorize('ADMIN', 'MANAGER', 'OPERATOR'), async (req: AuthRequest, res) => {
  const schema = z.object({
    amount: z.number().positive(),
    method: z.enum(['CASH', 'CARD', 'TRANSFER', 'CHECK', 'CREDIT']),
    notes: z.string().optional(),
  })
  const data = schema.parse(req.body)
  const result = await registerPayment(req.params.id, { ...data, userId: req.user!.id })
  res.json(result)
})

export default router
