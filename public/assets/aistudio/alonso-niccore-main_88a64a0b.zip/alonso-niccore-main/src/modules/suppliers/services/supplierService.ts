import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError } from '../../../shared/errors/AppError'

export async function createSupplier(data: {
  name: string
  rfc?: string
  email?: string
  phone?: string
  address?: string
  notes?: string
}) {
  return prisma.supplier.create({ data })
}

export async function getSuppliers(search?: string) {
  return prisma.supplier.findMany({
    where: {
      active: true,
      ...(search ? { OR: [
        { name: { contains: search, mode: 'insensitive' } },
        { rfc: { contains: search, mode: 'insensitive' } },
      ]} : {}),
    },
    orderBy: { name: 'asc' },
  })
}

export async function updateSupplier(id: string, data: any) {
  return prisma.supplier.update({ where: { id }, data })
}
