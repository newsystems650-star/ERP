import { Router } from 'express'
import { z } from 'zod'
import { authenticate, authorize } from '../../auth/middleware/authenticate'
import { createSupplier, getSuppliers, updateSupplier } from '../services/supplierService'

const router = Router()
router.use(authenticate)

router.get('/', async (req, res) => {
  const data = await getSuppliers(req.query.search as string)
  res.json({ data })
})

router.post('/', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const schema = z.object({
    name: z.string().min(2),
    rfc: z.string().optional(),
    email: z.string().email().optional(),
    phone: z.string().optional(),
    address: z.string().optional(),
    notes: z.string().optional(),
  })
  const data = schema.parse(req.body)
  const supplier = await createSupplier(data)
  res.status(201).json({ supplier })
})

router.put('/:id', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const supplier = await updateSupplier(req.params.id, req.body)
  res.json({ supplier })
})

export default router
