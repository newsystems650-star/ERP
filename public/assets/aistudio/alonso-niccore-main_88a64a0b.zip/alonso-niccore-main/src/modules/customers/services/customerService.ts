import { prisma } from '../../../infrastructure/database/prisma'
import { NotFoundError } from '../../../shared/errors/AppError'
import { CreateCustomerInput } from '../validators/customerValidator'

export async function createCustomer(data: CreateCustomerInput) {
  return prisma.customer.create({ data })
}

export async function getCustomers(filters: { search?: string; page?: number; limit?: number }) {
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const skip = (page - 1) * limit
  const where: any = { active: true }
  if (filters.search) {
    where.OR = [
      { name: { contains: filters.search, mode: 'insensitive' } },
      { phone: { contains: filters.search } },
      { email: { contains: filters.search, mode: 'insensitive' } },
      { rfc: { contains: filters.search, mode: 'insensitive' } },
    ]
  }
  const [data, total] = await prisma.$transaction([
    prisma.customer.findMany({ where, skip, take: limit, orderBy: { name: 'asc' } }),
    prisma.customer.count({ where }),
  ])
  return { data, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}

export async function getCustomerById(id: string) {
  const customer = await prisma.customer.findUnique({
    where: { id },
    include: {
      tickets: { take: 10, orderBy: { createdAt: 'desc' }, select: { id: true, code: true, total: true, status: true, createdAt: true } },
      credits: { where: { status: 'ACTIVE' }, select: { id: true, amount: true, balance: true, dueDate: true } },
    },
  })
  if (!customer) throw new NotFoundError('Cliente')
  return customer
}

export async function updateCustomer(id: string, data: Partial<CreateCustomerInput>) {
  await getCustomerById(id)
  return prisma.customer.update({ where: { id }, data })
}

export async function deactivateCustomer(id: string) {
  await getCustomerById(id)
  return prisma.customer.update({ where: { id }, data: { active: false }, select: { id: true, name: true, active: true } })
}
