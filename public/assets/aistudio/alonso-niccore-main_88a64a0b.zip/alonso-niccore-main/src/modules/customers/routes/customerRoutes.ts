import { Router } from 'express'
import { authenticate, authorize } from '../../auth/middleware/authenticate'
import { createCustomerSchema, updateCustomerSchema } from '../validators/customerValidator'
import { createCustomer, getCustomers, getCustomerById, updateCustomer, deactivateCustomer } from '../services/customerService'

const router = Router()
router.use(authenticate)

router.get('/', async (req, res) => {
  const result = await getCustomers({ search: req.query.search as string, page: Number(req.query.page) || 1, limit: Number(req.query.limit) || 20 })
  res.json(result)
})

router.get('/:id', async (req, res) => {
  const customer = await getCustomerById(req.params.id)
  res.json({ customer })
})

router.post('/', async (req, res) => {
  const data = createCustomerSchema.parse(req.body)
  const customer = await createCustomer(data)
  res.status(201).json({ customer })
})

router.put('/:id', async (req, res) => {
  const data = updateCustomerSchema.parse(req.body)
  const customer = await updateCustomer(req.params.id, data)
  res.json({ customer })
})

router.delete('/:id', authorize('ADMIN', 'MANAGER'), async (req, res) => {
  const customer = await deactivateCustomer(req.params.id)
  res.json({ customer })
})

export default router
