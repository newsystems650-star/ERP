import { Router, Request, Response } from 'express';
import { compararProducto, getResumen, registrarCotizacion } from './inteligencia.service';

export const inteligenciaRouter = Router();

inteligenciaRouter.get('/resumen', async (_req, res) => {
    try { res.json(await getResumen()); } catch (e) { res.status(500).json({ error: String(e) }); }
});

inteligenciaRouter.get('/producto/:id', async (req, res) => {
    try {
        const comp = await compararProducto(req.params.id);
        if (!comp) return res.status(404).json({ error: 'Sin cotizaciones.' });
        res.json(comp);
    } catch (e) { res.status(500).json({ error: String(e) }); }
});

inteligenciaRouter.post('/cotizacion', async (req: Request, res: Response) => {
    const { proveedorId, productoId, precio, notas } = req.body;
    if (!proveedorId || !productoId || precio == null || typeof precio !== 'number' || precio <= 0)
        return res.status(400).json({ error: 'proveedorId, productoId y precio (positivo) requeridos.' });
    try { res.status(201).json(await registrarCotizacion({ proveedorId, productoId, precio, notas })); }
    catch (e) { res.status(500).json({ error: String(e) }); }
});
