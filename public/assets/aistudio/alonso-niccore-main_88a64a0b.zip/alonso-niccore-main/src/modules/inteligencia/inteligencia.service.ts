import { prisma } from '../../lib/prisma';
import { Decimal } from '@prisma/client/runtime/library';

export interface LineaComparacion {
    proveedorId: string; proveedor: string; zona: string | null;
    precio: number; fecha: string; diasDesdeQuote: number;
    esMasBarato: boolean; ahorroVsPromedio: number; notas: string | null;
}
export interface ComparacionProducto {
    productoId: string; clave: string; nombre: string; unidad: string;
    ranking: LineaComparacion[]; mejorPrecio: number; peorPrecio: number;
    promedio: number; ahorroMaximo: number;
}

function diasDesde(f: Date): number { return Math.floor((Date.now() - f.getTime()) / 86_400_000); }
function toNum(d: Decimal | number): number { return typeof d === 'number' ? d : Number(d.toString()); }

export async function compararProducto(productoId: string): Promise<ComparacionProducto | null> {
    const producto = await prisma.productoCatalogo.findUnique({ where: { id: productoId } });
    if (!producto) return null;
    const proveedores = await prisma.proveedor.findMany({ where: { activo: true } });
    const lineas: LineaComparacion[] = [];
    for (const prov of proveedores) {
        const ultima = await prisma.cotizacionProveedor.findFirst({ where: { proveedorId: prov.id, productoId }, orderBy: { fecha: 'desc' } });
        if (!ultima) continue;
        lineas.push({ proveedorId: prov.id, proveedor: prov.nombre, zona: prov.zona, precio: toNum(ultima.precio), fecha: ultima.fecha.toISOString(), diasDesdeQuote: diasDesde(ultima.fecha), esMasBarato: false, ahorroVsPromedio: 0, notas: ultima.notas });
    }
    if (lineas.length === 0) return null;
    lineas.sort((a, b) => a.precio - b.precio);
    const precios  = lineas.map((l) => l.precio);
    const mejor    = precios[0], peor = precios[precios.length - 1];
    const promedio = precios.reduce((s, p) => s + p, 0) / precios.length;
    for (const l of lineas) { l.esMasBarato = l.precio === mejor; l.ahorroVsPromedio = parseFloat((promedio - l.precio).toFixed(2)); }
    return { productoId: producto.id, clave: producto.clave, nombre: producto.nombre, unidad: producto.unidad, ranking: lineas, mejorPrecio: parseFloat(mejor.toFixed(2)), peorPrecio: parseFloat(peor.toFixed(2)), promedio: parseFloat(promedio.toFixed(2)), ahorroMaximo: parseFloat((peor - mejor).toFixed(2)) };
}

export async function getResumen() {
    const productos = await prisma.productoCatalogo.findMany({ where: { activo: true } });
    const comparaciones = []; let ahorroTotal = 0;
    for (const prod of productos) {
        const comp = await compararProducto(prod.id);
        if (!comp) continue;
        comparaciones.push(comp);
        if (comp.ranking.length >= 2) ahorroTotal += comp.ahorroMaximo;
    }
    return { totalProductos: productos.length, productosComparados: comparaciones.filter((c) => c.ranking.length >= 2).length, ahorroTotalPosible: parseFloat(ahorroTotal.toFixed(2)), productos: comparaciones, generadoEn: new Date().toISOString() };
}

export async function registrarCotizacion(data: { proveedorId: string; productoId: string; precio: number; notas?: string }) {
    const r = await prisma.cotizacionProveedor.create({ data: { ...data, notas: data.notas ?? null } });
    return { id: r.id };
}
