#include <iostream>
int main() {
    int* fuga = new int[10]; // Creamos memoria pero NUNCA la liberamos
    return 0; 
}
