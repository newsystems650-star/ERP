// src/services/wood_calculator.service.ts
import net from 'net';
import { WoodTest } from '../shared/contracts/wood_test.contract';

// Usamos Unix Sockets para máxima velocidad en entorno Linux
const SOCKET_PATH = '/tmp/niccore.sock'; 

export class WoodCalculatorService {
  /**
   * Envía las medidas al Motor C++ para calcular el Cubicaje Real
   * @param woodData Medidas validadas de la tabla
   * @param bladeKerfMm Grosor del disco de corte en milímetros (Por defecto 5mm)
   */
  static async calculateRealYield(woodData: WoodTest, bladeKerfMm: number = 5): Promise<any> {
    return new Promise((resolve, reject) => {
      const client = net.createConnection({ path: SOCKET_PATH }, () => {
        // Empaquetamos la carga útil: Medidas + Merma
        const payload = JSON.stringify({ ...woodData, bladeKerfMm });
        client.write(payload);
      });

      client.on('data', (data) => {
        // C++ responde con el Pie Tablar Real exacto
        const response = JSON.parse(data.toString());
        
        // Aquí Node tomará este resultado para aplicar el Margen de Utilidad
        client.end();
        resolve(response); 
      });

      client.on('error', (err) => {
        console.error('❌ Error de conexión con el Músculo C++:', err.message);
        reject(err);
      });
    });
  }
}
