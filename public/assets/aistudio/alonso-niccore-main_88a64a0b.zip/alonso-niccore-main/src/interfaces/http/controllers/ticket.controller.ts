import { Request, Response } from 'express';
import { TicketService } from '../../../modules/tickets/ticket.service';

export const createTicket = async (req: Request, res: Response) => {
  try {
    const ticket = await TicketService.createSale(req.body);
    res.status(201).json({ status: 'success', data: ticket });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

export const getTickets = async (req: Request, res: Response) => {
  try {
    const tickets = await TicketService.getHistory();
    res.json({ status: 'success', data: tickets });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};
