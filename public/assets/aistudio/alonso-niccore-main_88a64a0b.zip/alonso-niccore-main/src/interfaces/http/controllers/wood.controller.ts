import { Request, Response } from 'express';
import { WoodInventoryService } from '../../../modules/wood-inventory/wood.service';

export const processWoodSale = async (req: Request, res: Response) => {
  try {
    const result = await WoodInventoryService.executeFullSale(req.body);
    res.status(201).json(result);
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};
