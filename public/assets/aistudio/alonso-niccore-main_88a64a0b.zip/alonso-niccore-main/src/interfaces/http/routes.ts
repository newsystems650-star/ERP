import { Router } from 'express';
import { processWoodSale } from './controllers/wood.controller';
import { tenantMiddleware } from './middlewares/tenant.middleware';

const router = Router();

// Todas las rutas de madera pasan por el radar de Tenant
router.post('/wood/calculate', tenantMiddleware, processWoodSale);

export default router;
