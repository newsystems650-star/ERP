import { Request, Response, NextFunction } from 'express';
import { tenantStorage } from '../../../core/tenant/tenantContext';

export const tenantMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const tenantId = req.headers['x-tenant-id'] as string || 'niccore-default';
  tenantStorage.run({ tenantId, userId: 'admin' }, () => {
    next();
  });
};
