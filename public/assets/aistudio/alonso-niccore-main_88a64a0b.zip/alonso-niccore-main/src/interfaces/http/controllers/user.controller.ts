import { Request, Response } from 'express';
import { UserService } from '../../../modules/users/user.service';

export const getUsers = async (req: Request, res: Response) => {
  try {
    const users = await UserService.getAll();
    res.json({ status: 'success', data: users });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

export const createUser = async (req: Request, res: Response) => {
  try {
    const user = await UserService.create(req.body);
    res.status(201).json({ status: 'success', data: user });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};
