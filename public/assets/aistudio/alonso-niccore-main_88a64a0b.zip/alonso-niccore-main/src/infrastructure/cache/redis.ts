import IORedis from 'ioredis'

export const redisConnection = new IORedis({
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: Number(process.env.REDIS_PORT) || 6379,
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
})

redisConnection.on('connect', () => console.log('✅ Redis conectado'))
redisConnection.on('error', (err) => console.error('❌ Redis error:', err.message))

export default redisConnection
