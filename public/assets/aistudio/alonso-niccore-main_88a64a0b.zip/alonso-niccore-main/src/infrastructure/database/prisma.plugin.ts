import fp from 'fastify-plugin';
import { prisma } from './prisma';

export const prismaPlugin = fp(async (fastify) => {
  try {
    await prisma.$connect();
    fastify.log.info('✅ PostgreSQL Conectado (Modo Online)');
  } catch (err) {
    fastify.log.error('🔴 Fallo de Red: Activando Espejo Búnker (SQLite)');
    // Aquí el sistema ya sabe que debe usar el archivo local .db
  }
});

