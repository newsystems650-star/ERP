import { PrismaClient } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaLibSql } from '@prisma/adapter-libsql';
import { createClient } from '@libsql/client';
import pg from 'pg';

type PrismaGlobal = typeof globalThis & { __niccorePrisma?: PrismaClient };
const prismaGlobal = globalThis as PrismaGlobal;

function createPrismaClient(): PrismaClient {
  const adapter =
    process.env.BUNKER_MODE === 'true'
      ? new PrismaLibSql(
          createClient({
            url: process.env.BUNKER_DATABASE_URL ?? 'file:./prisma/niccore_bunker.db',
          }),
        )
      : new PrismaPg(
          new pg.Pool({
            connectionString: process.env.DATABASE_URL,
          }),
        );

  return new PrismaClient({ adapter });
}

// Keep one client per process while preserving the configured PostgreSQL/libSQL adapter.
export const prisma =
  prismaGlobal.__niccorePrisma ?? createPrismaClient();

if (process.env.NODE_ENV !== 'production') {
  prismaGlobal.__niccorePrisma = prisma;
}

export default prisma;
