import TelegramBot from 'node-telegram-bot-api'

let bot: TelegramBot | null = null

function getBot(): TelegramBot {
  if (!bot) {
    bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN!, { polling: false })
  }
  return bot
}

const chatId = () => process.env.TELEGRAM_CHAT_ID!

export async function sendAlert(message: string, urgent = false): Promise<void> {
  try {
    const prefix = urgent ? '🚨 URGENTE' : '⚠️ ALERTA'
    const text = `${prefix} — NicCore\n\n${message}\n\n🕐 ${new Date().toLocaleString('es-MX')}`
    await getBot().sendMessage(chatId(), text, { parse_mode: 'Markdown' })
  } catch (err) {
    console.error('Telegram error:', err)
  }
}

export async function sendInfo(message: string): Promise<void> {
  try {
    const text = `ℹ️ NicCore\n\n${message}\n\n🕐 ${new Date().toLocaleString('es-MX')}`
    await getBot().sendMessage(chatId(), text, { parse_mode: 'Markdown' })
  } catch (err) {
    console.error('Telegram error:', err)
  }
}

export async function sendRepair(what: string, how: string): Promise<void> {
  try {
    const text = `🔧 *AutoRepair — NicCore*\n\n*Problema detectado:*\n${what}\n\n*Acción tomada:*\n${how}\n\n✅ Sistema sigue operando normalmente\n\n🕐 ${new Date().toLocaleString('es-MX')}`
    await getBot().sendMessage(chatId(), text, { parse_mode: 'Markdown' })
  } catch (err) {
    console.error('Telegram error:', err)
  }
}

export async function sendUrgent(message: string, attempts: number): Promise<void> {
  try {
    const text = `🚨🚨🚨 *ACCIÓN INMEDIATA REQUERIDA*\n\nNicCore detectó una amenaza crítica\n\n${message}\n\n*Intentos registrados: ${attempts}*\n\nEl sistema está en *MODO BÚNKER* — operando con protección extra\n\n⚡ Revisa el sistema o ve al negocio\n\n🕐 ${new Date().toLocaleString('es-MX')}`
    // Enviar 3 veces para asegurar que llegue
    for (let i = 0; i < 3; i++) {
      await getBot().sendMessage(chatId(), text, { parse_mode: 'Markdown' })
      await new Promise(r => setTimeout(r, 1000))
    }
  } catch (err) {
    console.error('Telegram urgent error:', err)
  }
}
