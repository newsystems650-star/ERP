import { prisma } from '../../infrastructure/database/prisma'
import { redisConnection } from '../cache/redis'
import { sendInfo, sendAlert } from '../../infrastructure/monitor/telegram'
import { logger } from '../../infrastructure/logger'

// Verifica y repara integridad del inventario
export async function checkInventoryIntegrity(): Promise<void> {
  try {
    // Buscar stock negativo
    const negativeStock = await prisma.stock.findMany({
      where: { quantity: { lt: 0 } },
      include: { product: { select: { name: true, sku: true } } },
    })

    if (negativeStock.length > 0) {
      // Autocorregir — poner en 0
      await prisma.stock.updateMany({
        where: { quantity: { lt: 0 } },
        data: { quantity: 0 },
      })

      const productos = negativeStock.map(s => `• ${s.product.name} (${s.product.sku}): ${s.quantity}`).join('\n')

      await sendInfo(
        `🔧 *AutoRepair — Stock negativo corregido*\n\n` +
        `Productos corregidos a 0:\n${productos}\n\n` +
        `✅ Corrección aplicada automáticamente`
      )

      logger.warn('AUTO_REPAIR: stock negativo corregido', { count: negativeStock.length })
    }
  } catch (err) {
    logger.error('checkInventoryIntegrity failed:', err)
  }
}

// Verifica tickets en estado inconsistente
export async function checkTicketConsistency(): Promise<void> {
  try {
    // Tickets pendientes de más de 24 horas
    const staleTickets = await prisma.ticket.findMany({
      where: {
        status: 'PENDING',
        createdAt: { lt: new Date(Date.now() - 24 * 60 * 60 * 1000) },
      },
      include: { user: { select: { name: true } } },
    })

    if (staleTickets.length > 0) {
      const lista = staleTickets.map(t => `• ${t.code} — ${t.user.name}`).join('\n')
      await sendAlert(
        `⏰ *Tickets pendientes de más de 24h*\n\n${lista}\n\n` +
        `Verifica si deben confirmarse o cancelarse`
      )
    }
  } catch (err) {
    logger.error('checkTicketConsistency failed:', err)
  }
}

// Verifica salud de la base de datos
export async function checkDatabaseHealth(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`
    return true
  } catch (err) {
    await sendAlert('🔴 *Base de datos no responde*\n\nVerifica PostgreSQL inmediatamente', true)
    return false
  }
}

// Verifica salud de Redis
export async function checkRedisHealth(): Promise<boolean> {
  try {
    await redisConnection.ping()
    return true
  } catch (err) {
    await sendAlert('🔴 *Redis no responde*\n\nLas colas y sesiones pueden verse afectadas', true)
    return false
  }
}

// Alerta de stock bajo
export async function checkLowStock(): Promise<void> {
  try {
    const alerts = await prisma.stock.findMany({
      where: { minAlert: { not: null }, product: { active: true } },
      include: { product: { select: { name: true, sku: true } } },
    })

    const lowStock = alerts.filter(s => Number(s.quantity) <= Number(s.minAlert))

    if (lowStock.length > 0) {
      const lista = lowStock.map(s =>
        `• ${s.product.name}: ${Number(s.quantity)} (mín: ${Number(s.minAlert)})`
      ).join('\n')

      await sendAlert(`📦 *Stock bajo detectado*\n\n${lista}`)
    }
  } catch (err) {
    logger.error('checkLowStock failed:', err)
  }
}

// Reporte diario de salud
export async function dailyHealthReport(): Promise<void> {
  try {
    const hoy = new Date()
    hoy.setHours(0, 0, 0, 0)

    const [ventas, tickets, creditos] = await prisma.$transaction([
      prisma.ticket.aggregate({
        where: { type: 'SALE', status: 'CONFIRMED', createdAt: { gte: hoy } },
        _sum: { total: true },
        _count: true,
      }),
      prisma.ticket.count({ where: { status: 'PENDING' } }),
      prisma.credit.count({ where: { status: 'ACTIVE' } }),
    ])

    const dbOk = await checkDatabaseHealth()
    const redisOk = await checkRedisHealth()

    await sendInfo(
      `📊 *Reporte diario — NicCore*\n\n` +
      `*Ventas hoy:* $${Number(ventas._sum.total || 0).toLocaleString('es-MX')}\n` +
      `*Tickets confirmados:* ${ventas._count}\n` +
      `*Tickets pendientes:* ${tickets}\n` +
      `*Créditos activos:* ${creditos}\n\n` +
      `*Salud del sistema:*\n` +
      `• PostgreSQL: ${dbOk ? '✅' : '❌'}\n` +
      `• Redis: ${redisOk ? '✅' : '❌'}\n` +
      `• Modo Búnker: ${process.env.BUNKER_MODE === 'true' ? '🛡️ ACTIVO' : '✅ Normal'}`
    )
  } catch (err) {
    logger.error('dailyHealthReport failed:', err)
  }
}
