import { redisConnection } from '../cache/redis'
import { sendAlert, sendUrgent, sendRepair } from '../monitor/telegram'
import { logger } from '../../infrastructure/logger'

const MAX_ATTEMPTS = Number(process.env.MAX_USER_ERRORS || 2)
const BUNKER_KEY = 'system:bunker_mode'
const ERROR_TTL = 3600 // 1 hora

export async function isBunkerMode(): Promise<boolean> {
  try {
    const val = await redisConnection.get(BUNKER_KEY)
    return val === 'true'
  } catch {
    return false
  }
}

export async function activateBunker(reason: string): Promise<void> {
  try {
    await redisConnection.set(BUNKER_KEY, 'true', 'EX', 3600)
    process.env.BUNKER_MODE = 'true'
    logger.warn('BUNKER MODE ACTIVADO:', reason)
    await sendUrgent(reason, MAX_ATTEMPTS + 1)
  } catch (err) {
    console.error('Error activating bunker:', err)
  }
}

export async function deactivateBunker(): Promise<void> {
  try {
    await redisConnection.del(BUNKER_KEY)
    process.env.BUNKER_MODE = 'false'
    await sendInfo('✅ Modo Búnker desactivado — sistema operando normalmente')
  } catch (err) {
    console.error('Error deactivating bunker:', err)
  }
}

export async function trackUserError(data: {
  userId: string
  userName: string
  action: string
  module: string
  errorType: string
  details: string
  ip?: string
}): Promise<void> {
  const key = `user_errors:${data.userId}`

  try {
    const current = await redisConnection.incr(key)
    await redisConnection.expire(key, ERROR_TTL)

    logger.warn('USER_ERROR_TRACKED', data)

    if (current === 1) {
      // Primer intento — solo registrar
      await sendAlert(
        `👤 *Error de usuario registrado*\n\n` +
        `*Usuario:* ${data.userName}\n` +
        `*Módulo:* ${data.module}\n` +
        `*Acción intentada:* ${data.action}\n` +
        `*Error:* ${data.errorType}\n` +
        `*Detalle:* ${data.details}\n` +
        `*IP:* ${data.ip || 'desconocida'}\n\n` +
        `⚠️ Intento 1/${MAX_ATTEMPTS}`
      )
    } else if (current === 2) {
      // Segundo intento — alerta
      await sendAlert(
        `⚠️ *SEGUNDO INTENTO — Usuario reincidente*\n\n` +
        `*Usuario:* ${data.userName}\n` +
        `*Módulo:* ${data.module}\n` +
        `*Acción:* ${data.action}\n` +
        `*IP:* ${data.ip || 'desconocida'}\n\n` +
        `🔴 Intento 2/${MAX_ATTEMPTS} — próximo intento activa MODO BÚNKER`,
        true
      )
    } else if (current > MAX_ATTEMPTS) {
      // Límite superado — MODO BÚNKER
      await activateBunker(
        `*Usuario sospechoso detectado*\n\n` +
        `*Usuario:* ${data.userName}\n` +
        `*Módulo:* ${data.module}\n` +
        `*Acción repetida:* ${data.action}\n` +
        `*Total intentos:* ${current}\n` +
        `*IP:* ${data.ip || 'desconocida'}`
      )
    }
  } catch (err) {
    console.error('Error tracking user error:', err)
  }
}

export async function trackStructuralError(data: {
  error: Error
  module: string
  context?: string
  autoFixed?: boolean
  fixDescription?: string
}): Promise<void> {
  logger.error('STRUCTURAL_ERROR', {
    message: data.error.message,
    stack: data.error.stack,
    module: data.module,
    context: data.context,
  })

  if (data.autoFixed && data.fixDescription) {
    await sendRepair(
      `*Módulo:* ${data.module}\n*Error:* ${data.error.message}\n*Contexto:* ${data.context || 'N/A'}`,
      data.fixDescription
    )
  } else {
    await sendAlert(
      `🔴 *Error estructural detectado*\n\n` +
      `*Módulo:* ${data.module}\n` +
      `*Error:* ${data.error.message}\n` +
      `*Contexto:* ${data.context || 'N/A'}\n\n` +
      `⚡ Requiere revisión`,
      true
    )
  }
}
