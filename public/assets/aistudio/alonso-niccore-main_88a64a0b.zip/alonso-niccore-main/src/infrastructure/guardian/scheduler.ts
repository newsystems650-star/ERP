import { checkInventoryIntegrity, checkTicketConsistency, checkLowStock, dailyHealthReport } from './businessGuard'
import { logger } from '../../infrastructure/logger'

export function startScheduler(): void {
  logger.info('Scheduler iniciado')

  // Cada 5 minutos — verificar integridad de inventario
  setInterval(async () => {
    await checkInventoryIntegrity()
  }, 5 * 60 * 1000)

  // Cada 30 minutos — verificar tickets inconsistentes
  setInterval(async () => {
    await checkTicketConsistency()
  }, 30 * 60 * 1000)

  // Cada hora — verificar stock bajo
  setInterval(async () => {
    await checkLowStock()
  }, 60 * 60 * 1000)

  // Cada día a las 8am — reporte diario
  const scheduleDaily = () => {
    const now = new Date()
    const next8am = new Date()
    next8am.setHours(8, 0, 0, 0)
    if (next8am <= now) next8am.setDate(next8am.getDate() + 1)
    const delay = next8am.getTime() - now.getTime()

    setTimeout(async () => {
      await dailyHealthReport()
      scheduleDaily() // reagendar para mañana
    }, delay)
  }

  scheduleDaily()
}
