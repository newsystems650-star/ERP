import { Worker } from 'bullmq';
import { PrismaClient } from '@prisma/client';
import { PrismaLibSql } from '@prisma/adapter-libsql';
import { createClient } from '@libsql/client';
import IORedis from 'ioredis';

const libsqlClient = createClient({ url: 'file:./prisma/niccore_bunker.db' });
const adapter = new PrismaLibSql(libsqlClient as any);
const prisma = new PrismaClient({ adapter } as any);

const redisConnection = new IORedis({ maxRetriesPerRequest: null });

const worker = new Worker('inventory-queue', async (job) => {
  console.log(`[BULLMQ] Procesando ID: ${job.id}`);
  try {
    if (job.name === 'process-wood-entry') {
      await prisma.woodEntry.create({ 
        data: {
          ...job.data,
          // Aseguramos que los valores numéricos lleguen como tal
          widthCm: parseFloat(job.data.widthCm),
          thicknessCm: parseFloat(job.data.thicknessCm),
          lengthCm: parseFloat(job.data.lengthCm),
          totalFeet: parseFloat(job.data.totalFeet),
          totalM3: parseFloat(job.data.totalM3),
          costPerFoot: parseFloat(job.data.costPerFoot),
          pricePerFoot: parseFloat(job.data.pricePerFoot),
          profitTotal: parseFloat(job.data.profitTotal)
        } 
      });
      console.log(`[OK] Entrada ${job.id} persistida.`);
    }
  } catch (error: any) {
    console.error(`[ERROR] DB:`, error.message);
  }
}, { connection: redisConnection });

console.log('--- WORKER INDUSTRIAL ESPERANDO MADERA ---');
