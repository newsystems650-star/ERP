#!/usr/bin/env python3
"""Read-only health monitor for the NicCore API container."""
import json
import logging
import os
import signal
import sys
import time
from urllib.request import urlopen

API_URL = os.getenv("API_URL", "http://localhost:3000").rstrip("/")
HEALTH_URL = os.getenv("HEALTH_URL", f"{API_URL}/api/health")
CHECK_INTERVAL_S = 5
MAX_MEMORY_MB = 400
MAX_SILENCE_S = 120

os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/sentinel.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("Sentinel")


class Sentinel:
    def __init__(self):
        self.consecutive_fails = 0
        self.running = True
        signal.signal(signal.SIGINT, self._on_shutdown)
        signal.signal(signal.SIGTERM, self._on_shutdown)

    def _fetch_health(self):
        try:
            with urlopen(HEALTH_URL, timeout=3) as response:
                if response.status != 200:
                    return None
                payload = json.loads(response.read().decode("utf-8"))
                return payload if isinstance(payload, dict) else None
        except Exception as exc:
            log.debug("Health request failed: %s", exc)
            return None

    def run(self):
        log.info(
            "NicCore Sentinel | monitor-only | interval=%ss | endpoint=%s",
            CHECK_INTERVAL_S,
            HEALTH_URL,
        )
        while self.running:
            health = self._fetch_health()
            if health is None or health.get("status") != "ok":
                self.consecutive_fails += 1
                level = logging.ERROR if self.consecutive_fails >= 3 else logging.WARNING
                log.log(level, "API sin respuesta (%s comprobaciones consecutivas)",
                        self.consecutive_fails)
                if self.consecutive_fails == 3:
                    log.error("Intervención requerida: Sentinel no reinicia procesos de otros contenedores.")
                time.sleep(CHECK_INTERVAL_S)
                continue

            self.consecutive_fails = 0
            memory_mb = health.get("memoryMB")
            active_nodes = health.get("activeNodes")
            uptime = health.get("uptime")
            silence_ms = health.get("silenceMs")
            log.info(
                "API OK | heap=%sMB | nodos=%s | eventos=%s | uptime=%ss",
                memory_mb,
                active_nodes,
                health.get("eventCount", "N/D"),
                uptime,
            )

            if isinstance(memory_mb, (int, float)) and memory_mb > MAX_MEMORY_MB:
                log.error("Heap Node.js por encima del umbral: %sMB (máximo %sMB)",
                          memory_mb, MAX_MEMORY_MB)
            if (
                isinstance(silence_ms, (int, float))
                and silence_ms >= 0
                and silence_ms > MAX_SILENCE_S * 1000
                and isinstance(uptime, (int, float))
                and uptime > 60
            ):
                log.warning("Sin eventos recientes durante %.1fs.",
                            silence_ms / 1000)
            time.sleep(CHECK_INTERVAL_S)

    def _on_shutdown(self, _signal_number, _frame):
        log.info("Deteniendo Sentinel...")
        self.running = False


if __name__ == "__main__":
    Sentinel().run()
