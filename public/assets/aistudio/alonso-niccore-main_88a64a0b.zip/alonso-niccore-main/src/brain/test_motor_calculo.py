import socket
import struct
import sys

# Ruta del archivo del socket en el sistema de archivos de Debian/Linux
PATH_SOCKET = "/tmp/motor_calculo.sock"

# Datos de la integral a validar
operation_id = 5       # ID de la operación (8 bytes)
limit_a = 0.00001      # Límite inferior (8 bytes)
limit_b = 75.15        # Límite superior (8 bytes)
tolerance = 0.0        # Margen de error permitido (8 bytes)

# Definición del formato binario puro:
# '<' : Little-endian (arquitectura estándar Intel/AMD)
# 'Q' : unsigned long long de 8 bytes
# 'd' : double de 8 bytes (punto flotante de precisión doble)
formato_binario = '<Qddd'

# Empaquetamos los datos (Total: 32 bytes exactos)
buffer_bytes = struct.pack(formato_binario, operation_id, limit_a, limit_b, tolerance)

# Conexión Zero-Trust (Fail-Fast)
try:
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client_socket:
        client_socket.connect(PATH_SOCKET)
        
        # Enviamos la ráfaga de bytes pura
        client_socket.sendall(buffer_bytes)
        
        # Esperamos 1 byte de respuesta del motor C++ (0x00 = Falla, 0x05 = Éxito)
        respuesta = client_socket.recv(1)
        
        if respuesta == b'\x05':
            print("Python: Validación de integral exitosa en el cerebro C++.")
        else:
            print("Python: Validación rechazada por el motor.")

except socket.error as e:
    print(f"Error crítico: No se pudo contactar al motor C++ en {PATH_SOCKET}. Detalle: {e}")
    sys.exit(1) # Cae rápido
