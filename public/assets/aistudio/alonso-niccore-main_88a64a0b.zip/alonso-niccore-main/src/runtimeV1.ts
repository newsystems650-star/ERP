import express from 'express';
import path from 'node:path';
import { eventStore } from './core/event-store/eventStore';
import { taskRuntime } from './core/runtime/taskRuntime';
import { tasksRouter } from './network/tasks';
import { healthRouter } from './network/health';

export function createRuntimeV1App() {
  const app = express();
  app.use(express.json({ limit: '80kb' }));
  app.use('/api', healthRouter);
  app.use('/api/tasks', tasksRouter);
  app.get('/dashboard', (_req, res) => {
    res.sendFile(path.resolve(process.cwd(), 'docs/niccore-control-center.html'));
  });
  app.get('/health', (_req, res) => {
    res.json({ status: 'ok', runtime: taskRuntime.snapshot(), timestamp: new Date().toISOString() });
  });
  return app;
}

export function startRuntimeV1() {
  eventStore.initialize();
  taskRuntime.register('text.stats', async (input) => {
    if (typeof input.text !== 'string') throw new TypeError('input.text must be a string');
    const value = input.text;
    const trimmed = value.trim();
    return {
      characters: value.length,
      words: trimmed ? trimmed.split(/\s+/).length : 0,
      lines: value ? value.split(/\r?\n/).length : 0,
    };
  });
  taskRuntime.initialize();

  const app = createRuntimeV1App();
  const port = Number(process.env.PORT || 3001);
  return app.listen(port, '127.0.0.1', () => {
    console.log('[NICCORE Runtime V1] listening on 127.0.0.1:' + port);
  });
}

if (require.main === module) {
  const server = startRuntimeV1();
  const shutdown = () => server.close(() => process.exit(0));
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
}
