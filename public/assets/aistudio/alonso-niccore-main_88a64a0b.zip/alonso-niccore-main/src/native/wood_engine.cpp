#include <iostream>
#include <sqlite3.h>
#include <string>

int main(int argc, char* argv[]) {
    sqlite3* DB;
    // Abrimos la base de datos que usa Prisma para que sea la misma fuente
    int exit = sqlite3_open("prisma/niccore_bunker.db", &DB);

    if (exit) {
        std::cerr << "--- [ERROR] No se pudo abrir el Búnker ---" << std::endl;
        return (-1);
    }

    std::string sql = "CREATE TABLE IF NOT EXISTS WoodEntry ("
                      "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                      "entryCode TEXT NOT NULL,"
                      "woodType TEXT,"
                      "totalFeet REAL,"
                      "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);";

    char* messageError;
    exit = sqlite3_exec(DB, sql.c_str(), NULL, 0, &messageError);

    if (exit != SQLITE_OK) {
        std::cerr << "--- [ERROR NATIVO] --- " << messageError << std::endl;
        sqlite3_free(messageError);
    } else {
        std::cout << "--- [NICCORE] NÚCLEO DE DIAMANTE (C++) ACTIVADO ---" << std::endl;
    }

    sqlite3_close(DB);
    return 0;
}
