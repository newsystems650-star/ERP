#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>

#include <sqlite3.h>

namespace {

bool executeSQL(sqlite3* db, const char* sql) {
    char* error_message = nullptr;
    const int result = sqlite3_exec(db, sql, nullptr, nullptr, &error_message);
    if (result == SQLITE_OK) return true;

    std::cerr << "[NICCORE native] SQLite error: "
              << (error_message ? error_message : sqlite3_errmsg(db))
              << std::endl;
    sqlite3_free(error_message);
    return false;
}

bool recordAuditEvent(sqlite3* db, const std::string& event) {
    sqlite3_stmt* statement = nullptr;
    const char* sql = "INSERT INTO BrainAudit (event, status) VALUES (?, 'SUCCESS')";
    if (sqlite3_prepare_v2(db, sql, -1, &statement, nullptr) != SQLITE_OK) {
        std::cerr << "[NICCORE native] Cannot prepare audit statement: "
                  << sqlite3_errmsg(db) << std::endl;
        if (statement) sqlite3_finalize(statement);
        return false;
    }

    bool success = false;
    if (sqlite3_bind_text(statement, 1, event.c_str(),
                          static_cast<int>(event.size()), SQLITE_TRANSIENT) == SQLITE_OK) {
        success = sqlite3_step(statement) == SQLITE_DONE;
    }
    if (!success) {
        std::cerr << "[NICCORE native] Cannot record audit event: "
                  << sqlite3_errmsg(db) << std::endl;
    }
    sqlite3_finalize(statement);
    return success;
}

}  // namespace

int main(int argc, char* argv[]) {
    const char* configured_path = std::getenv("BUNKER_DB");
    const std::filesystem::path database_path =
        configured_path && *configured_path
            ? configured_path
            : "data/niccore_bunker.db";

    std::error_code filesystem_error;
    if (!database_path.parent_path().empty()) {
        std::filesystem::create_directories(database_path.parent_path(), filesystem_error);
        if (filesystem_error) {
            std::cerr << "[NICCORE native] Cannot create database directory: "
                      << filesystem_error.message() << std::endl;
            return 1;
        }
    }

    sqlite3* db = nullptr;
    if (sqlite3_open(database_path.string().c_str(), &db) != SQLITE_OK) {
        std::cerr << "[NICCORE native] Cannot open database: "
                  << (db ? sqlite3_errmsg(db) : "SQLite allocation failure") << std::endl;
        if (db) sqlite3_close(db);
        return 1;
    }

    const bool schema_ok = executeSQL(db, "PRAGMA foreign_keys = ON;")
        && executeSQL(db,
            "CREATE TABLE IF NOT EXISTS Company ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "taxId TEXT UNIQUE NOT NULL,"
            "name TEXT NOT NULL,"
            "industry TEXT,"
            "verified INTEGER NOT NULL DEFAULT 0);")
        && executeSQL(db,
            "CREATE TABLE IF NOT EXISTS Job ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "companyId INTEGER,"
            "title TEXT NOT NULL,"
            "salary REAL CHECK(salary >= 0),"
            "status TEXT NOT NULL DEFAULT 'OPEN',"
            "FOREIGN KEY(companyId) REFERENCES Company(id));")
        && executeSQL(db,
            "CREATE TABLE IF NOT EXISTS BrainAudit ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "event TEXT NOT NULL,"
            "status TEXT NOT NULL,"
            "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);");

    bool success = schema_ok;
    if (success && argc > 1) {
        success = recordAuditEvent(db, argv[1]);
    }

    const int close_result = sqlite3_close(db);
    if (close_result != SQLITE_OK) {
        std::cerr << "[NICCORE native] Cannot close SQLite database cleanly." << std::endl;
        success = false;
    }
    if (!success) return 1;

    std::cout << "[NICCORE native] SQLite schema ready: "
              << database_path.string() << std::endl;
    return 0;
}
