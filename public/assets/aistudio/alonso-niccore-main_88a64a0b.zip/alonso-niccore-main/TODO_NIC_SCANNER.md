# TODO: Implementación Nic-Scanner (Pacto de Pureza Técnica)

## Pasos del Plan Aprobado (Native C++ / FlatBuffers / Tubo Oculto)

### 1. [x] Extender src/protos/nic-os.fbs
- Agregar ProcessMetric y NicScannerPayload.

### 2. [ ] Crear src/core/nic_scanner.cpp
- Leer /proc/stat, /proc/[pid]/stat, meminfo.
- Filtrar PIDs: tsn (node API/Vite), nsp (self), nec (C++ engines).
- Firmar con llave USB.
- Daemon: Loop enviar FlatBuffer a /tmp/nic_scanner.sock.

### 3. [x] Actualizar src/core/Makefile
- Target: nic_scanner (g++ -O3).

### 4. [x] Actualizar src/brain/sentinel.py
- Escuchar socket, desempaquetar FlatBuffer, verificar signature.
- Actualizar tacómetros/alertas Telegram.

### 5. [x] Generar llaves USB (usb_key_gen.sh created & run)
- Par llaves para firma.

### 6. [x] Build & Test
- `make nic_scanner`
- `./bin/nic_scanner` (check socket).
- sentinel.py read.

### 7. [ ] Integrar Redis/BullMQ socket audit.

**Progress: 0/7**  
Siguiente: Edits FlatBuffers + C++.
