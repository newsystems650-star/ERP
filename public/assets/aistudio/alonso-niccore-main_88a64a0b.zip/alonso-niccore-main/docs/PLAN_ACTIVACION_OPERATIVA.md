# Plan de activación operativa de NICCORE

**Estado:** plan de ejecución; no certifica que los servicios estén activos.  
**Objetivo:** obtener un flujo mínimo que arranque, responda, registre eventos y pueda verificarse de forma repetible.

## Regla de activación

No declarar NICCORE operativo por la existencia de archivos, documentación o compilaciones aisladas. Un componente se considera activo únicamente cuando su prueba indicada termina correctamente y deja evidencia reproducible.

## Fases y criterios de salida

### Fase 0 — Congelar y registrar el punto de partida
- Registrar rama, commit, estado de cambios y entorno de ejecución.
- Conservar las versiones existentes; trabajar en una rama separada.
- Identificar archivos de configuración, variables de entorno y servicios requeridos.
- No publicar secretos, tokens, claves ni archivos `.env`.

**Salida:** registro inicial con commit, entorno y lista de bloqueos.

### Fase 1 — Arranque mínimo del backend
- Elegir una sola entrada de arranque como ruta canónica.
- Revisar `package.json`, `health-check.ts`, `src/index.ts` y los Dockerfiles antes de ejecutar.
- Resolver referencias a binarios faltantes o nombres de motores incompatibles.
- Confirmar qué puerto y ruta de salud implementa realmente el backend.
- Ejecutar instalación reproducible y compilación/type-check sin ocultar errores.

**Salida:** backend inicia en un entorno limpio y la ruta de salud real devuelve una respuesta exitosa.

### Fase 2 — Dependencias y persistencia
- Verificar conectividad a PostgreSQL/SQLite y Redis solo si el flujo elegido realmente los necesita.
- Validar esquema y migraciones antes de aplicarlas a datos importantes.
- Usar variables de entorno para credenciales; no aceptar contraseñas de ejemplo en despliegues.
- Comprobar lectura y escritura con un registro identificable y luego verificar su recuperación.

**Salida:** una operación de persistencia de extremo a extremo confirmada por evidencia.

### Fase 3 — Observabilidad mínima
- Registrar inicio/parada, errores, estado de dependencias y resultado de las pruebas.
- Medir latencia de la ruta de salud, errores y uso de CPU/RAM con herramientas del entorno.
- Cada métrica debe incluir timestamp, fuente, unidad y método de medición.
- Marcar explícitamente `NO MEDIDO` cuando no haya instrumentación.

**Salida:** informe de estado que distingue OK, ERROR, BLOQUEADO y NO MEDIDO.

### Fase 4 — Activación controlada de módulos
Activar uno por uno y solo después de verificar sus dependencias:
1. API y persistencia.
2. `nic_scanner` como recolector local, tras corregir la selección de procesos y validar el receptor del socket.
3. Forecast, con datos históricos reales y pruebas de casos límite.
4. Mesh, después de implementar y probar el protocolo gRPC, descubrimiento, relay y recuperación.

**Salida:** cada módulo tiene prueba, evidencia, límites conocidos y procedimiento de apagado.

### Fase 5 — Prueba de aceptación
- Arranque desde entorno limpio.
- Prueba de salud.
- Prueba de persistencia.
- Prueba de registro de errores.
- Reinicio y recuperación.
- Verificación de que no se expongan secretos.
- Guardar comandos ejecutados, códigos de salida, fecha y commit probado.

**Salida:** acta de aceptación con resultados reales. Los fallos permanecen abiertos; no se marcan como aprobados.

## Condiciones de bloqueo inmediato

Detener el despliegue si:
- se detectan credenciales reales en el repositorio;
- hay migraciones destructivas no revisadas;
- los servicios dependen de binarios no generados;
- un chequeo de salud da error;
- se informa como operativo un módulo que no ha sido probado.

## Formato del registro de ejecución

| Campo | Valor |
|---|---|
| Fecha y zona horaria | |
| Commit / rama | |
| Equipo y sistema operativo | |
| Comando ejecutado | |
| Resultado / código de salida | |
| Evidencia (log o salida) | |
| Estado: OK / ERROR / BLOQUEADO / NO MEDIDO | |
| Siguiente acción | |

## Definición de “NICCORE activo”

NICCORE solo puede declararse activo para el alcance probado cuando el backend inicia, su endpoint real de salud responde, la persistencia requerida funciona y los resultados pueden repetirse desde el mismo commit. Los módulos opcionales se reportan por separado.