# Operación, métricas y alertas de NICCORE

**Propósito:** guía de operación para el prototipo. No instala, inicia ni modifica servicios por sí misma.

## 1. Antes de arrancar

Desde la raíz del repositorio:

```bash
git status --short --branch
git rev-parse --short HEAD
node --version
npm --version
```

Revisar scripts, archivos de entorno, puertos, servicios y requisitos de cada Dockerfile. No imprimir el contenido completo de `.env` ni copiar secretos en los registros.

## 2. Validación estática y compilación

Ejecutar solo los scripts existentes y confirmados en `package.json`. En este repositorio el script `test` puede devolver error porque está configurado como marcador de posición; no tratarlo como una suite de pruebas.

```bash
npm run
npm run build
```

Si falla, guardar el error completo y el código de salida. No seguir a despliegue hasta resolver los errores de bloqueo.

## 3. Dependencias

Si el alcance requiere Docker Compose:

```bash
docker compose config --quiet
docker compose ps
docker compose logs --tail=100 api
docker compose logs --tail=100 postgres
docker compose logs --tail=100 redis
```

Estos comandos inspeccionan configuración y servicios; no prueban por sí solos que la API funcione. Confirmar que los nombres de servicios existen en el archivo Compose usado. No ejecutar migraciones sobre datos valiosos sin copia de seguridad y revisión del destino.

## 4. Verificar salud HTTP

Usar la ruta y el puerto definidos realmente por el servidor. No asumir que `/health` existe solo porque Docker la menciona.

```bash
curl --fail --show-error --silent --output /dev/null \
  --write-out 'http_code=%{http_code} total_seconds=%{time_total}\n' \
  http://127.0.0.1:3000/health
```

Si el endpoint real es diferente, cambiar la URL. Registrar el código HTTP y el tiempo medido. Una respuesta exitosa no verifica automáticamente base de datos, cola, motor nativo ni módulos secundarios.

## 5. Métricas del host

En Linux, capturar una muestra básica:

```bash
date --iso-8601=seconds
uptime
free -h
df -h
ps -eo pid,comm,%cpu,%mem,rss,etime --sort=-%cpu | head -n 15
```

Para contenedores, si Docker está disponible:

```bash
docker stats --no-stream
```

No sumar automáticamente cifras del host y de los contenedores. Indicar fuente, unidad y momento de captura.

## 6. Reglas de alerta iniciales

Los umbrales siguientes son **provisionales**, no valores medidos ni límites de rendimiento ya validados. Ajustarlos después de observar la carga normal.

| Señal | Condición inicial sugerida | Acción |
|---|---|---|
| API no responde | 2 comprobaciones consecutivas fallidas | comprobar proceso, puerto y logs |
| Dependencia caída | conexión fallida confirmada | revisar estado y configuración de esa dependencia |
| CPU alta | >85% durante 5 minutos | identificar proceso y correlacionar con errores |
| RAM alta | >90% de memoria disponible consumida durante 5 minutos | revisar RSS, fugas y límites |
| Disco | >85% utilizado | localizar crecimiento y preparar limpieza segura |
| Errores repetidos | mismo error 5 veces en 5 minutos | agrupar por causa y abrir incidente |
| Datos de telemetría ausentes | no llega ninguna muestra dentro del intervalo esperado | verificar productor, socket, permisos y receptor |

No emitir alertas de CPU/RAM/disco basándose en una sola muestra si la condición requiere persistencia.

## 7. Seguridad operativa

- Cambiar credenciales predeterminadas antes de exponer servicios.
- No publicar PostgreSQL, Redis ni puertos internos a Internet sin necesidad y controles adecuados.
- Mantener secretos fuera del repositorio y de los logs.
- Validar autenticidad e integridad con un mecanismo criptográfico apropiado. Un hash simple concatenado con un secreto no equivale automáticamente a una firma autenticada; considerar HMAC-SHA-256 con comparación segura.
- Limitar permisos del socket y definir explícitamente quién puede leerlo.
- Probar restauración de copias de seguridad, no solo su creación.

## 8. Formato de alerta

```text
ID:
Fecha/hora y zona:
Severidad: CRITICA | ALTA | MEDIA | BAJA
Componente:
Señal y umbral:
Valor observado y unidad:
Fuente:
Commit / entorno:
Impacto confirmado:
Acción inmediata:
Resultado y evidencia:
```

## 9. Cierre de cada jornada

Informar únicamente:
- OK: pruebas que pasaron con evidencia.
- ERROR: pruebas ejecutadas que fallaron.
- BLOQUEADO: pruebas impedidas por requisitos previos.
- NO MEDIDO: métricas sin fuente accesible.
- Una prioridad siguiente.

No afirmar que NICCORE está activo en su totalidad si solo se verificó un servicio.