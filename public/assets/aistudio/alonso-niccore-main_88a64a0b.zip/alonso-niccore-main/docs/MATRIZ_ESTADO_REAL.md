# Matriz de estado real de NICCORE

Esta matriz evita confundir código presente con capacidad operativa. Actualizarla con evidencia al ejecutar pruebas; no inferir resultados.

## Estados permitidos

- **OK:** prueba ejecutada y evidencia adjunta.
- **ERROR:** prueba ejecutada y falló.
- **BLOQUEADO:** no se pudo probar por una dependencia o requisito previo.
- **NO MEDIDO:** no existe medición disponible.
- **NO APLICA:** el componente no forma parte del alcance desplegado.

## Matriz inicial

| Área | Evidencia requerida | Estado inicial | Criterio para pasar a OK |
|---|---|---|---|
| Instalación | salida del gestor de paquetes y código de salida | NO MEDIDO | instalación reproducible sin errores |
| TypeScript/build | salida del build/type-check | NO MEDIDO | build finaliza con código 0 |
| Backend/API | log de arranque y proceso/puerto | NO MEDIDO | proceso activo y puerto esperado abierto |
| Health endpoint | URL real y respuesta HTTP | NO MEDIDO | respuesta exitosa del endpoint implementado |
| Base de datos | prueba de conexión y lectura/escritura | NO MEDIDO | escritura y lectura verificadas |
| Migraciones | estado de migraciones y esquema | NO MEDIDO | migraciones aplicadas a la base correcta |
| Redis/colas | ping y operación de ida/vuelta, si se usa | NO MEDIDO | operación comprobada |
| Motor nativo | compilación, ruta y ejecución real | NO MEDIDO | binario esperado existe y supera prueba |
| nic_scanner | muestras de métricas y recepción del socket | NO MEDIDO | PID real, medición válida y receptor confirmado |
| Forecast | pruebas unitarias y registros reales | NO MEDIDO | resultados correctos en casos normales y límite |
| Mesh/gRPC | prueba entre dos nodos y desconexión | NO MEDIDO | registro, comunicación, relay y recuperación demostrados |
| Seguridad | revisión de secretos y configuración | NO MEDIDO | sin secretos versionados; configuración segura |
| Observabilidad | log con fecha, fuente y nivel | NO MEDIDO | eventos y errores consultables |
| Recuperación | reinicio y reanudación | NO MEDIDO | servicio se recupera y deja evidencia |

## Métricas mínimas para cada ejecución

- disponibilidad del endpoint (% de comprobaciones exitosas);
- latencia de salud (ms, con método y número de muestras);
- errores del backend (conteo por intervalo);
- CPU y RAM del proceso real;
- uso de memoria del sistema;
- estado de dependencias;
- tiempo de arranque;
- cantidad de eventos recibidos, procesados y rechazados, si el módulo los expone.

No publicar porcentajes ni promedios si no se conoce el número de muestras, intervalo, unidad y fuente.

## Reglas de calidad de los datos

1. Registrar fecha y zona horaria, commit, entorno y comando.
2. Distinguir la métrica del host de la métrica del contenedor.
3. No sustituir procesos inexistentes por PID calculados o valores de ejemplo.
4. No etiquetar una simulación como medición real.
5. No declarar “cero errores” si no se consultaron logs durante un intervalo definido.
6. Guardar evidencias sin tokens, contraseñas, datos personales ni contenido sensible.

## Registro de ejecución

Añadir una fila por prueba o mantener un historial fechado:

| Fecha | Commit | Área | Estado | Resultado medido | Evidencia | Próxima acción |
|---|---|---|---|---|---|---|
| Pendiente de ejecución | — | Arranque inicial | NO MEDIDO | — | — | Ejecutar Fase 1 de `PLAN_ACTIVACION_OPERATIVA.md` |