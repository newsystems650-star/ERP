module.exports = {
  apps: [{
    name: "niccore-vortex",
    // Use the primary backend entrypoint. The legacy server is intentionally
    // opt-in because tenantMiddleware is not authentication.
    script: "src/index.ts",
    interpreter: "node_modules/.bin/tsx",
    env: {
      NODE_PATH: ".",
      NODE_ENV: "production",
      PORT: 3000
    },
    instances: 1,
    exec_mode: "fork",
    watch: false,
    max_memory_restart: "1G",
    exp_backoff_restart_delay: 100,
    error_file: "./logs/err.log",
    out_file: "./logs/out.log",
    merge_logs: true
  }]
};
