# Niccore Docker Compose TODO

## Approved Plan Steps

### 1. Enhance docker-compose.yml [ ]
- Add client dev service
- Add healthchecks/restarts/volumes
- Ensure DB/Redis persistence

### 2. Update Dockerfiles [ ]
- api.Dockerfile: Multi-stage, prisma
- engine.Dockerfile: Mount bin/ engines
- sentinel.Dockerfile: Python deps

### 3. Test [ ]
- docker compose up -d
- docker compose logs -f
- docker compose exec api npm run db:migrate

### 4. Prod optimizations [ ]
- .env.prod
- docker compose -f docker-compose.prod.yml

Progress: 0/4

