const vortex = require('./build/Release/vortex_engine');

const dummyData = {
  width: 30,
  thickness: 2.5,
  length: 250,
  pieces: 140,
  cost: 18,
  margin: 30
};

const start = map.hrtime();
const result = vortex.calculate(30, 2.5, 250, 140, 18, 30);
const end = process.hrtime(start);

console.log("🚀 RESULTADO DEL MOTOR C++:", result);
console.log(`⏱️ TIEMPO DE CÁLCULO: ${end[1] / 1000000} ms`);
