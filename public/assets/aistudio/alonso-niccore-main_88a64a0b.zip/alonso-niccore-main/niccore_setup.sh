#!/usr/bin/env bash
# =============================================================================
# NicCore — Setup de Integración
# Ejecutar desde la raíz del proyecto: bash niccore_setup.sh
# =============================================================================

set -e
BOLD='\033[1m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; RESET='\033[0m'

log()  { echo -e "${CYAN}[NicCore]${RESET} $1"; }
ok()   { echo -e "${GREEN}[OK]${RESET} $1"; }
head() { echo -e "\n${BOLD}━━━ $1 ━━━${RESET}"; }

head "CREANDO ESTRUCTURA DE DIRECTORIOS"

mkdir -p src/core/supervisor
mkdir -p src/core/ingestion
mkdir -p src/core/security
mkdir -p src/core/projections
mkdir -p src/core/workers
mkdir -p src/core/whatsapp
mkdir -p src/core/event-store
mkdir -p src/modules/alerts
mkdir -p src/modules/rutas
mkdir -p src/modules/inteligencia
mkdir -p src/network
mkdir -p src/brain
mkdir -p src/seeds
mkdir -p src/lib
mkdir -p client/src/pages
mkdir -p logs

ok "Directorios listos"

# =============================================================================
head "src/lib/prisma.ts"
# =============================================================================
cat > src/lib/prisma.ts << 'EOF'
import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };

export const prisma =
    globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== 'production') {
    globalForPrisma.prisma = prisma;
}
EOF
ok "src/lib/prisma.ts"

# =============================================================================
head "src/core/supervisor/engine.supervisor.ts"
# =============================================================================
cat > src/core/supervisor/engine.supervisor.ts << 'EOF'
import { spawn, ChildProcess } from 'child_process';
import path from 'path';

const ENGINE_BIN             = path.resolve('build/Release/niccore_engine');
const MAX_CRASHES_EN_MINUTO  = 5;
const RESTART_DELAY_MS       = 50;

export class EngineSupervisor {
    private proc:        ChildProcess | null = null;
    private crashCount:  number  = 0;
    private windowStart: number  = Date.now();
    private running:     boolean = false;

    public start(): void {
        this.running = true;
        this.launch();
    }

    private launch(): void {
        if (!this.running) return;

        this.proc = spawn(ENGINE_BIN, [], {
            stdio: ['ignore', 'inherit', 'inherit'],
        });

        this.proc.on('exit', (code, signal) => {
            if (!this.running) return;
            console.error(`[Supervisor] Engine caído. code=${code} signal=${signal}`);
            this.registrarCrash();

            if (this.debeAbandonar()) {
                console.error(`[Supervisor] ${MAX_CRASHES_EN_MINUTO} crashes en 60s. Intervención manual requerida.`);
                this.running = false;
                process.exit(1);
                return;
            }

            setTimeout(() => this.launch(), RESTART_DELAY_MS);
        });

        console.log(`[Supervisor] Engine PID ${this.proc.pid} activo.`);
    }

    private registrarCrash(): void {
        const ahora = Date.now();
        if (ahora - this.windowStart > 60_000) {
            this.crashCount  = 0;
            this.windowStart = ahora;
        }
        this.crashCount++;
    }

    private debeAbandonar(): boolean {
        return this.crashCount >= MAX_CRASHES_EN_MINUTO;
    }

    public stop(): void {
        this.running = false;
        if (this.proc) {
            this.proc.kill('SIGTERM');
            this.proc = null;
        }
        console.log('[Supervisor] Engine detenido limpiamente.');
    }
}

export const engineSupervisor = new EngineSupervisor();
EOF
ok "src/core/supervisor/engine.supervisor.ts"

# =============================================================================
head "src/core/ingestion/rate.limiter.ts"
# =============================================================================
cat > src/core/ingestion/rate.limiter.ts << 'EOF'
const VENTANA_MS   = 60_000;
const MAX_INTENTOS = 20;
const BLACKLIST_MS = 300_000;

interface EntradaIP {
    timestamps:     number[];
    bloqueadaHasta: number;
}

class RateLimiter {
    private tabla: Map<string, EntradaIP> = new Map();

    public estaLimitada(ip: string): boolean {
        const ahora   = Date.now();
        let   entrada = this.tabla.get(ip);

        if (!entrada) {
            entrada = { timestamps: [], bloqueadaHasta: 0 };
            this.tabla.set(ip, entrada);
        }

        if (ahora < entrada.bloqueadaHasta) return true;

        entrada.timestamps = entrada.timestamps.filter(
            (ts) => ahora - ts < VENTANA_MS
        );
        entrada.timestamps.push(ahora);

        if (entrada.timestamps.length > MAX_INTENTOS) {
            entrada.bloqueadaHasta = ahora + BLACKLIST_MS;
            console.warn(`[RateLimiter] IP bloqueada 5 min: ${ip}`);
            return true;
        }

        return false;
    }

    public purgarInactivas(): void {
        const ahora = Date.now();
        for (const [ip, entrada] of this.tabla.entries()) {
            const sinActividad    = entrada.timestamps.every((ts) => ahora - ts > VENTANA_MS);
            const blacklistExpiro = entrada.bloqueadaHasta < ahora;
            if (sinActividad && blacklistExpiro) this.tabla.delete(ip);
        }
    }
}

export const rateLimiter = new RateLimiter();

setInterval(() => rateLimiter.purgarInactivas(), 600_000);
EOF
ok "src/core/ingestion/rate.limiter.ts"

# =============================================================================
head "src/core/ingestion/udp_receiver.ts"
# =============================================================================
cat > src/core/ingestion/udp_receiver.ts << 'EOF'
import * as dgram  from 'dgram';
import * as crypto from 'crypto';
import { randomUUID }  from 'crypto';
import { eventBus }    from '../event-store/eventBus';
import { rateLimiter } from './rate.limiter';

const UDP_PORT          = 41234;
const MAX_DATAGRAM_SIZE = 256;
const REPLAY_WINDOW_S   = 60;
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const NODE_KEYS: Record<string, string> = JSON.parse(
    process.env.NIC_NODE_KEYS ?? '{}'
);

function jitter(): Promise<void> {
    return new Promise((r) => setTimeout(r, Math.floor(Math.random() * 50)));
}

export class TelemetryTunnel {
    private server: dgram.Socket;

    constructor() {
        this.server = dgram.createSocket('udp4');
        this.initialize();
    }

    private initialize(): void {
        this.server.on('error', async (err) => {
            console.error(`[TelemetryTunnel] Fallo crítico:\n${err.stack}`);
            await this.stop();
        });

        this.server.on('message', (msg, rinfo) => {
            if (msg.length > MAX_DATAGRAM_SIZE)       return;
            if (rateLimiter.estaLimitada(rinfo.address)) return;
            void this.authenticateAndProcess(msg, rinfo.address);
        });

        this.server.on('listening', () => {
            const addr = this.server.address();
            console.log(`[TelemetryTunnel] UDP activo → ${addr.address}:${addr.port}`);
        });
    }

    public start(): void { this.server.bind(UDP_PORT, '0.0.0.0'); }

    public stop(): Promise<void> {
        return new Promise((resolve) => {
            try { this.server.close(() => resolve()); }
            catch { resolve(); }
        });
    }

    private async authenticateAndProcess(msg: Buffer, ip: string): Promise<void> {
        const fields = msg.toString('utf-8').trim().split('|');

        if (fields.length !== 7) { await jitter(); return; }

        const [nodeId, latStr, lonStr, velStr, tsStr, tripId, receivedHmac] = fields;

        const secretKey = NODE_KEYS[nodeId];
        if (!secretKey || !UUID_REGEX.test(tripId)) { await jitter(); return; }

        const lat = parseFloat(latStr);
        const lon = parseFloat(lonStr);
        const vel = parseFloat(velStr);
        const ts  = parseInt(tsStr, 10);

        if (
            isNaN(lat) || lat < -90  || lat > 90  ||
            isNaN(lon) || lon < -180 || lon > 180 ||
            isNaN(vel) || vel < 0    || vel > 300 ||
            isNaN(ts)  || receivedHmac.length !== 64
        ) { await jitter(); return; }

        const body     = `${nodeId}|${latStr}|${lonStr}|${velStr}|${tsStr}|${tripId}`;
        const expected = crypto.createHmac('sha256', secretKey).update(body).digest('hex');

        const bExp = Buffer.from(expected,     'utf-8');
        const bRec = Buffer.from(receivedHmac, 'utf-8');

        if (bExp.length !== bRec.length || !crypto.timingSafeEqual(bExp, bRec)) {
            await jitter();
            console.warn(`[TelemetryTunnel] HMAC inválido. Nodo: ${nodeId} | IP: ${ip}`);
            return;
        }

        if (Math.abs(Math.floor(Date.now() / 1000) - ts) > REPLAY_WINDOW_S) {
            await jitter(); return;
        }

        eventBus.publish({
            id:        randomUUID(),
            type:      'LOGISTICS_NODE_BREADCRUMB',
            timestamp: new Date().toISOString(),
            payload: {
                nodeId, tripId,
                latitud:               lat,
                longitud:              lon,
                velocidad_kmh:         vel,
                timestamp_dispositivo: ts,
            },
        });
    }
}
EOF
ok "src/core/ingestion/udp_receiver.ts"

# =============================================================================
head "src/core/security/hmac.rotation.ts"
# =============================================================================
cat > src/core/security/hmac.rotation.ts << 'EOF'
import * as crypto from 'crypto';
import * as fs     from 'fs';
import * as path   from 'path';

const KEYS_PATH     = path.resolve('.niccore_keys.json');
const ROTATION_DAYS = 30;
const KEY_BYTES     = 32;

interface KeyEntry { key: string; rotatedAt: string; }
type KeyStore = Record<string, KeyEntry>;

function loadStore(): KeyStore {
    if (!fs.existsSync(KEYS_PATH)) return {};
    return JSON.parse(fs.readFileSync(KEYS_PATH, 'utf-8')) as KeyStore;
}

function saveStore(store: KeyStore): void {
    fs.writeFileSync(KEYS_PATH, JSON.stringify(store, null, 2), { mode: 0o600 });
}

function diasDesde(iso: string): number {
    return Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000);
}

export function rotarClave(nodeId: string): string {
    const store   = loadStore();
    const newKey  = crypto.randomBytes(KEY_BYTES).toString('hex');
    store[nodeId] = { key: newKey, rotatedAt: new Date().toISOString() };
    saveStore(store);
    console.log(`[HMACRotation] Clave rotada: ${nodeId}`);
    return newKey;
}

export function loadActiveKeys(): Record<string, string> {
    const store  = loadStore();
    const result: Record<string, string> = {};
    for (const [id, entry] of Object.entries(store)) result[id] = entry.key;
    return result;
}

export function runRotationCycle(): void {
    const store = loadStore();
    let rotadas = 0;
    for (const [nodeId, entry] of Object.entries(store)) {
        if (diasDesde(entry.rotatedAt) >= ROTATION_DAYS) {
            rotarClave(nodeId); rotadas++;
        }
    }
    if (rotadas > 0) {
        console.log(`[HMACRotation] ${rotadas} clave(s) rotadas.`);
        console.warn('[HMACRotation] Distribuir claves nuevas a nodos afectados.');
    }
}

export function startRotationScheduler(): void {
    runRotationCycle();
    setInterval(runRotationCycle, 86_400_000);
    console.log('[HMACRotation] Scheduler activo — verificación diaria.');
}
EOF
ok "src/core/security/hmac.rotation.ts"

# =============================================================================
head "src/core/projections/map.projection.ts"
# =============================================================================
cat > src/core/projections/map.projection.ts << 'EOF'
import { Response } from 'express';
import { eventBus } from '../event-store/eventBus';

interface NodeState {
    lat:        number;
    lon:        number;
    spd:        number;
    tripId:     string;
    lastUpdate: number;
}

export class LiveMapProjection {
    private activeNodes:  Map<string, NodeState> = new Map();
    private clients:      Set<Response>           = new Set();

    private readonly GHOST_TTL_MS   = 60_000;
    private readonly SWEEP_INTERVAL = 15_000;
    private readonly PUSH_INTERVAL  = 1_000;

    private sweepTimer?:     NodeJS.Timeout;
    private broadcastTimer?: NodeJS.Timeout;

    constructor() { this.initialize(); }

    private initialize(): void {
        eventBus.subscribe('LOGISTICS_NODE_BREADCRUMB', (event) => {
            const d = event.payload;
            this.activeNodes.set(d.nodeId, {
                lat:        d.latitud,
                lon:        d.longitud,
                spd:        d.velocidad_kmh,
                tripId:     d.tripId,
                lastUpdate: Date.now(),
            });
        });

        this.sweepTimer = setInterval(() => {
            const now = Date.now();
            for (const [id, state] of this.activeNodes.entries()) {
                if (now - state.lastUpdate > this.GHOST_TTL_MS) {
                    this.activeNodes.delete(id);
                    console.log(`[MapProjection] Nodo expirado: ${id}`);
                }
            }
        }, this.SWEEP_INTERVAL);

        this.broadcastTimer = setInterval(() => {
            if (this.clients.size === 0) return;
            const data = `data: ${JSON.stringify(this.getSnapshot())}\n\n`;
            for (const res of this.clients) {
                try { res.write(data); }
                catch { this.clients.delete(res); }
            }
        }, this.PUSH_INTERVAL);
    }

    public addClient(res: Response):    void { this.clients.add(res);    }
    public removeClient(res: Response): void { this.clients.delete(res); }

    public getSnapshot(): Record<string, NodeState> {
        const snap: Record<string, NodeState> = {};
        for (const [id, state] of this.activeNodes.entries()) snap[id] = state;
        return snap;
    }

    public shutdown(): void {
        clearInterval(this.sweepTimer);
        clearInterval(this.broadcastTimer);
        this.clients.clear();
        console.log('[MapProjection] Proyector detenido.');
    }
}

export const liveMapProjection = new LiveMapProjection();
EOF
ok "src/core/projections/map.projection.ts"

# =============================================================================
head "src/core/workers/postgres_batch.worker.ts"
# =============================================================================
cat > src/core/workers/postgres_batch.worker.ts << 'EOF'
import { eventBus } from '../event-store/eventBus';
import { prisma }   from '../../lib/prisma';

const FLUSH_INTERVAL_MS = 30_000;
const FLUSH_THRESHOLD   = 500;

interface BreadcrumbRecord {
    nodeId:       string;
    trip_id:      string;
    latitud:      number;
    longitud:     number;
    velocidadKmh: number;
    timestamp:    Date;
}

export class PostgresBatchWorker {
    private buffer:     BreadcrumbRecord[] = [];
    private flushTimer?: NodeJS.Timeout;
    private isFlushing  = false;

    constructor() { this.initialize(); }

    private initialize(): void {
        eventBus.subscribe('LOGISTICS_NODE_BREADCRUMB', (event) => {
            const d = event.payload;
            this.buffer.push({
                nodeId:       d.nodeId,
                trip_id:      d.tripId,
                latitud:      d.latitud,
                longitud:     d.longitud,
                velocidadKmh: d.velocidad_kmh,
                timestamp:    new Date(d.timestamp_dispositivo * 1000),
            });
            if (this.buffer.length >= FLUSH_THRESHOLD) void this.flush();
        });

        this.flushTimer = setInterval(() => void this.flush(), FLUSH_INTERVAL_MS);
    }

    private async flush(): Promise<void> {
        if (this.buffer.length === 0 || this.isFlushing) return;
        this.isFlushing  = true;
        const batch = this.buffer.splice(0, this.buffer.length);
        try {
            await prisma.node_breadcrumbs.createMany({ data: batch, skipDuplicates: true });
            console.log(`[BatchWorker] ${batch.length} breadcrumbs grabados.`);
        } catch (e) {
            console.error(`[BatchWorker] Lote descartado: ${batch.length} registros.`);
        } finally {
            this.isFlushing = false;
        }
    }

    public async shutdown(): Promise<void> {
        clearInterval(this.flushTimer);
        await this.flush();
        await prisma.$disconnect();
        console.log('[BatchWorker] Desconectado de PostgreSQL.');
    }
}

export const batchWorker = new PostgresBatchWorker();
EOF
ok "src/core/workers/postgres_batch.worker.ts"

# =============================================================================
head "src/core/whatsapp/whatsapp.client.ts"
# =============================================================================
cat > src/core/whatsapp/whatsapp.client.ts << 'EOF'
import { Client, LocalAuth } from 'whatsapp-web.js';
import qrcode from 'qrcode-terminal';

class WhatsAppEngine {
    private client:       Client;
    private ready         = false;
    private readyPromise: Promise<void>;
    private resolveReady!: () => void;

    constructor() {
        this.readyPromise = new Promise((res) => { this.resolveReady = res; });
        this.client = new Client({
            authStrategy: new LocalAuth({ dataPath: '.wwebjs_auth' }),
            puppeteer: {
                headless: true,
                args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
            },
        });
        this.initialize();
    }

    private initialize(): void {
        this.client.on('qr', (qr) => {
            console.log('\n[WhatsApp] Escanea este QR:');
            qrcode.generate(qr, { small: true });
        });
        this.client.on('ready', () => {
            this.ready = true;
            this.resolveReady();
            console.log('[WhatsApp] ✅ Sesión activa.');
        });
        this.client.on('auth_failure', (msg) => {
            console.error('[WhatsApp] ❌ Auth failure:', msg);
        });
        this.client.on('disconnected', (reason) => {
            this.ready = false;
            console.warn('[WhatsApp] Desconectado:', reason);
            setTimeout(() => this.client.initialize(), 10_000);
        });
        this.client.initialize();
    }

    private formatNumber(telefono: string): string {
        return `${telefono.replace(/\D/g, '')}@c.us`;
    }

    public async send(telefono: string, mensaje: string): Promise<{ ok: boolean; error?: string }> {
        if (!this.ready) return { ok: false, error: 'Motor no listo.' };
        try {
            await this.client.sendMessage(this.formatNumber(telefono), mensaje);
            return { ok: true };
        } catch (e) {
            return { ok: false, error: String(e) };
        }
    }

    public async shutdown(): Promise<void> {
        await this.client.destroy();
        console.log('[WhatsApp] Motor detenido.');
    }
}

export const whatsappEngine = new WhatsAppEngine();
EOF
ok "src/core/whatsapp/whatsapp.client.ts"

# =============================================================================
head "src/network/health.ts"
# =============================================================================
cat > src/network/health.ts << 'EOF'
import { Router, Request, Response } from 'express';
import { liveMapProjection } from '../core/projections/map.projection';

export const healthRouter = Router();

export const metrics = {
    breadcrumbsReceived: 0,
    breadcrumbsFlushed:  0,
    lastEventAt:         0,
};

healthRouter.get('/health', (_req: Request, res: Response) => {
    const mem       = process.memoryUsage();
    const snap      = liveMapProjection.getSnapshot();
    const silenceMs = metrics.lastEventAt > 0 ? Date.now() - metrics.lastEventAt : -1;

    res.json({
        status:              'ok',
        uptime:              Math.floor(process.uptime()),
        memoryMB:            Math.round(mem.heapUsed / 1024 / 1024),
        activeNodes:         Object.keys(snap).length,
        breadcrumbsReceived: metrics.breadcrumbsReceived,
        breadcrumbsFlushed:  metrics.breadcrumbsFlushed,
        silenceMs,
        timestamp:           new Date().toISOString(),
    });
});
EOF
ok "src/network/health.ts"

# =============================================================================
head "src/network/sse_stream.ts"
# =============================================================================
cat > src/network/sse_stream.ts << 'EOF'
import { Router, Request, Response } from 'express';
import { liveMapProjection } from '../core/projections/map.projection';

export const mapStreamRouter = Router();

mapStreamRouter.get('/stream/map', (req: Request, res: Response) => {
    res.setHeader('Content-Type',  'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection',    'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', process.env.CLIENT_ORIGIN ?? '*');
    res.flushHeaders();

    liveMapProjection.addClient(res);
    req.on('close', () => liveMapProjection.removeClient(res));
});
EOF
ok "src/network/sse_stream.ts"

# =============================================================================
head "src/modules/alerts/notifier.ts"
# =============================================================================
cat > src/modules/alerts/notifier.ts << 'EOF'
import { whatsappEngine } from '../../core/whatsapp/whatsapp.client';

const TELEGRAM_TOKEN = process.env.TELEGRAM_BOT_TOKEN ?? '';

interface SendResult { ok: boolean; canal: string; error?: string; }

async function sendTelegram(chatId: string, mensaje: string): Promise<SendResult> {
    if (!TELEGRAM_TOKEN) return { ok: false, canal: 'telegram', error: 'Sin token' };
    try {
        const res  = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chatId, text: mensaje, parse_mode: 'Markdown' }),
        });
        const data = await res.json() as { ok: boolean; description?: string };
        return data.ok ? { ok: true, canal: 'telegram' } : { ok: false, canal: 'telegram', error: data.description };
    } catch (e) {
        return { ok: false, canal: 'telegram', error: String(e) };
    }
}

export async function notify(
    telefono:   string,
    telegramId: string | null,
    mensaje:    string
): Promise<SendResult[]> {
    const resultados: SendResult[] = [];
    if (telefono) {
        const r = await whatsappEngine.send(telefono, mensaje);
        resultados.push({ ...r, canal: 'whatsapp' });
    }
    if (telegramId && TELEGRAM_TOKEN) {
        resultados.push(await sendTelegram(telegramId, mensaje));
    }
    return resultados;
}
EOF
ok "src/modules/alerts/notifier.ts"

# =============================================================================
head "src/modules/alerts/nicAlerts.service.ts"
# =============================================================================
cat > src/modules/alerts/nicAlerts.service.ts << 'EOF'
import { prisma }  from '../../lib/prisma';
import { notify }  from './notifier';

const NIVELES = [
    { nivel: 1, diasDesde: 1,  diasHasta: 7,        cadenciaDias: 7 },
    { nivel: 2, diasDesde: 8,  diasHasta: 15,       cadenciaDias: 3 },
    { nivel: 3, diasDesde: 16, diasHasta: Infinity,  cadenciaDias: 1 },
] as const;

function buildMensaje(nivel: number, nombre: string, concepto: string, monto: number, dias: number): string {
    const m = `$${monto.toFixed(2)} MXN`;
    const d = `${dias} día${dias !== 1 ? 's' : ''}`;
    if (nivel === 1) return `📋 *Recordatorio — NicCore Madería*\n\nHola *${nombre}*, tienes un saldo pendiente:\n\n📦 ${concepto}\n💰 *${m}*\n📅 Vencido hace ${d}\n\n¡Gracias por tu atención!`;
    if (nivel === 2) return `⚠️ *Aviso de adeudo — NicCore Madería*\n\n${nombre}, tu adeudo lleva *${d}* sin liquidarse:\n\n📦 ${concepto}\n💰 *${m}*\n\nContáctanos hoy para evitar inconvenientes.`;
    return `🚨 *ADEUDO URGENTE — NicCore Madería*\n\n${nombre}, tu adeudo de *${m}* tiene *${d}* de retraso.\n\n📦 ${concepto}\n\n*Comunícate HOY.* De no recibir respuesta procederemos con acciones adicionales.`;
}

async function yaEnviado(cuentaId: string, nivel: number, cadenciaDias: number): Promise<boolean> {
    const desde = new Date();
    desde.setDate(desde.getDate() - cadenciaDias);
    const reg = await prisma.alertLog.findFirst({
        where: { cuentaId, nivel, enviado: true, createdAt: { gte: desde } },
    });
    return reg !== null;
}

export async function runAlertCycle(): Promise<void> {
    console.log('[NicAlerts] Iniciando ciclo...');
    const hoy = new Date(); hoy.setHours(0, 0, 0, 0);

    const cuentas = await prisma.cuentaPorCobrar.findMany({
        where: { estado: { in: ['pendiente', 'parcial'] }, fechaVence: { lt: hoy } },
        include: { cliente: true },
    });

    let enviadas = 0;
    for (const cuenta of cuentas) {
        const vence = new Date(cuenta.fechaVence); vence.setHours(0, 0, 0, 0);
        const dias  = Math.floor((hoy.getTime() - vence.getTime()) / 86_400_000);
        const regla = NIVELES.find((n) => dias >= n.diasDesde && dias <= n.diasHasta);
        if (!regla) continue;
        if (await yaEnviado(cuenta.id, regla.nivel, regla.cadenciaDias)) continue;

        const monto   = Number(cuenta.monto) - Number(cuenta.montoPagado);
        const mensaje = buildMensaje(regla.nivel, cuenta.cliente.nombre, cuenta.concepto, monto, dias);
        const results = await notify(cuenta.cliente.telefono, cuenta.cliente.telegramId ?? null, mensaje);

        for (const r of results) {
            await prisma.alertLog.create({
                data: { cuentaId: cuenta.id, canal: r.canal, nivel: regla.nivel, enviado: r.ok, error: r.error ?? null },
            });
        }
        if (results.some((r) => r.ok)) enviadas++;
    }
    console.log(`[NicAlerts] Ciclo completo. Enviadas: ${enviadas}`);
}
EOF
ok "src/modules/alerts/nicAlerts.service.ts"

# =============================================================================
head "src/modules/alerts/alerts.scheduler.ts"
# =============================================================================
cat > src/modules/alerts/alerts.scheduler.ts << 'EOF'
import { runAlertCycle } from './nicAlerts.service';

const DIAS_HABILES  = [1, 2, 3, 4, 5, 6];
const HORAS_DISPARO = [9, 15];

let schedulerTimer: NodeJS.Timeout | undefined;

function debeDisparar(): boolean {
    const ahora = new Date();
    return DIAS_HABILES.includes(ahora.getDay())
        && HORAS_DISPARO.includes(ahora.getHours())
        && ahora.getMinutes() === 0;
}

function tick(): void {
    if (debeDisparar()) {
        console.log('[AlertScheduler] Disparo activado.');
        runAlertCycle().catch((e) => console.error('[AlertScheduler]', e));
    }
    schedulerTimer = setTimeout(tick, 60_000 - (Date.now() % 60_000));
}

export function startAlertScheduler(): void {
    console.log('[AlertScheduler] Activo — 9:00 y 15:00 días hábiles.');
    schedulerTimer = setTimeout(tick, 60_000 - (Date.now() % 60_000));
}

export function stopAlertScheduler(): void {
    if (schedulerTimer) { clearTimeout(schedulerTimer); console.log('[AlertScheduler] Detenido.'); }
}
EOF
ok "src/modules/alerts/alerts.scheduler.ts"

# =============================================================================
head "src/modules/rutas/rutas.service.ts"
# =============================================================================
cat > src/modules/rutas/rutas.service.ts << 'EOF'
import { prisma } from '../../lib/prisma';

export interface Breadcrumb { lat: number; lon: number; spd: number; timestamp: string; }
export interface Viaje {
    tripId: string; nodeId: string; inicio: string; fin: string;
    duracionMin: number; distanciaKm: number; spdPromedio: number; spdMaxima: number;
    puntos: Breadcrumb[];
}
export interface ViajeResumen { tripId: string; inicio: string; fin: string; duracionMin: number; distanciaKm: number; }
export interface ResumenNodo { nodeId: string; totalViajes: number; viajes: ViajeResumen[]; }

function haversine(la1: number, lo1: number, la2: number, lo2: number): number {
    const R = 6371, dL = ((la2 - la1) * Math.PI) / 180, dO = ((lo2 - lo1) * Math.PI) / 180;
    const a = Math.sin(dL / 2) ** 2 + Math.cos((la1 * Math.PI) / 180) * Math.cos((la2 * Math.PI) / 180) * Math.sin(dO / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function calcularDistancia(puntos: { lat: number; lon: number }[]): number {
    let total = 0;
    for (let i = 1; i < puntos.length; i++) total += haversine(puntos[i-1].lat, puntos[i-1].lon, puntos[i].lat, puntos[i].lon);
    return parseFloat(total.toFixed(2));
}

export async function getViaje(tripId: string): Promise<Viaje | null> {
    const registros = await prisma.node_breadcrumbs.findMany({ where: { trip_id: tripId }, orderBy: { timestamp: 'asc' } });
    if (registros.length === 0) return null;
    const puntos: Breadcrumb[] = registros.map((r) => ({ lat: r.latitud, lon: r.longitud, spd: r.velocidadKmh, timestamp: r.timestamp.toISOString() }));
    const speeds = puntos.map((p) => p.spd);
    const inicio = puntos[0].timestamp, fin = puntos[puntos.length - 1].timestamp;
    return {
        tripId, nodeId: registros[0].nodeId, inicio, fin,
        duracionMin: parseFloat(((new Date(fin).getTime() - new Date(inicio).getTime()) / 60_000).toFixed(1)),
        distanciaKm: calcularDistancia(puntos),
        spdPromedio: parseFloat((speeds.reduce((a, b) => a + b, 0) / speeds.length).toFixed(1)),
        spdMaxima:   parseFloat(Math.max(...speeds).toFixed(1)),
        puntos,
    };
}

export async function getViajesDeNodo(nodeId: string, desde: Date, hasta: Date): Promise<ResumenNodo> {
    const grupos = await prisma.node_breadcrumbs.groupBy({
        by: ['trip_id'], where: { nodeId, timestamp: { gte: desde, lte: hasta } },
        _min: { timestamp: true }, _max: { timestamp: true }, orderBy: { _min: { timestamp: 'desc' } },
    });
    const viajes: ViajeResumen[] = [];
    for (const g of grupos) {
        const inicio = g._min.timestamp!, fin = g._max.timestamp!;
        const puntos = await prisma.node_breadcrumbs.findMany({ where: { trip_id: g.trip_id }, orderBy: { timestamp: 'asc' }, select: { latitud: true, longitud: true } });
        viajes.push({
            tripId: g.trip_id, inicio: inicio.toISOString(), fin: fin.toISOString(),
            duracionMin: parseFloat(((fin.getTime() - inicio.getTime()) / 60_000).toFixed(1)),
            distanciaKm: calcularDistancia(puntos.map((p) => ({ lat: p.latitud, lon: p.longitud }))),
        });
    }
    return { nodeId, totalViajes: viajes.length, viajes };
}

export async function getNodosConActividad(desde: Date, hasta: Date): Promise<string[]> {
    const nodos = await prisma.node_breadcrumbs.findMany({ where: { timestamp: { gte: desde, lte: hasta } }, distinct: ['nodeId'], select: { nodeId: true } });
    return nodos.map((n) => n.nodeId);
}
EOF
ok "src/modules/rutas/rutas.service.ts"

# =============================================================================
head "src/modules/rutas/rutas.router.ts"
# =============================================================================
cat > src/modules/rutas/rutas.router.ts << 'EOF'
import { Router, Request, Response } from 'express';
import { getViaje, getViajesDeNodo, getNodosConActividad } from './rutas.service';

export const rutasRouter = Router();

rutasRouter.get('/viaje/:tripId', async (req: Request, res: Response) => {
    try {
        const viaje = await getViaje(req.params.tripId);
        if (!viaje) return res.status(404).json({ error: 'Viaje no encontrado.' });
        res.json(viaje);
    } catch (e) { res.status(500).json({ error: String(e) }); }
});

rutasRouter.get('/nodo/:nodeId', async (req: Request, res: Response) => {
    const { desde, hasta } = req.query as { desde?: string; hasta?: string };
    const fechaDesde = desde ? new Date(desde) : (() => { const d = new Date(); d.setDate(d.getDate() - 7); return d; })();
    const fechaHasta = hasta ? new Date(hasta) : new Date();
    if (isNaN(fechaDesde.getTime()) || isNaN(fechaHasta.getTime()))
        return res.status(400).json({ error: 'Fechas inválidas. Formato ISO requerido.' });
    try {
        res.json(await getViajesDeNodo(req.params.nodeId, fechaDesde, fechaHasta));
    } catch (e) { res.status(500).json({ error: String(e) }); }
});

rutasRouter.get('/nodos', async (req: Request, res: Response) => {
    const { desde, hasta } = req.query as { desde?: string; hasta?: string };
    const fechaDesde = desde ? new Date(desde) : (() => { const d = new Date(); d.setDate(d.getDate() - 7); return d; })();
    const fechaHasta = hasta ? new Date(hasta) : new Date();
    try {
        res.json({ nodos: await getNodosConActividad(fechaDesde, fechaHasta) });
    } catch (e) { res.status(500).json({ error: String(e) }); }
});
EOF
ok "src/modules/rutas/rutas.router.ts"

# =============================================================================
head "src/modules/inteligencia/inteligencia.service.ts"
# =============================================================================
cat > src/modules/inteligencia/inteligencia.service.ts << 'EOF'
import { prisma } from '../../lib/prisma';
import { Decimal } from '@prisma/client/runtime/library';

export interface LineaComparacion {
    proveedorId: string; proveedor: string; zona: string | null;
    precio: number; fecha: string; diasDesdeQuote: number;
    esMasBarato: boolean; ahorroVsPromedio: number; notas: string | null;
}
export interface ComparacionProducto {
    productoId: string; clave: string; nombre: string; unidad: string;
    ranking: LineaComparacion[]; mejorPrecio: number; peorPrecio: number;
    promedio: number; ahorroMaximo: number;
}

function diasDesde(f: Date): number { return Math.floor((Date.now() - f.getTime()) / 86_400_000); }
function toNum(d: Decimal | number): number { return typeof d === 'number' ? d : Number(d.toString()); }

export async function compararProducto(productoId: string): Promise<ComparacionProducto | null> {
    const producto = await prisma.productoCatalogo.findUnique({ where: { id: productoId } });
    if (!producto) return null;
    const proveedores = await prisma.proveedor.findMany({ where: { activo: true } });
    const lineas: LineaComparacion[] = [];
    for (const prov of proveedores) {
        const ultima = await prisma.cotizacionProveedor.findFirst({ where: { proveedorId: prov.id, productoId }, orderBy: { fecha: 'desc' } });
        if (!ultima) continue;
        lineas.push({ proveedorId: prov.id, proveedor: prov.nombre, zona: prov.zona, precio: toNum(ultima.precio), fecha: ultima.fecha.toISOString(), diasDesdeQuote: diasDesde(ultima.fecha), esMasBarato: false, ahorroVsPromedio: 0, notas: ultima.notas });
    }
    if (lineas.length === 0) return null;
    lineas.sort((a, b) => a.precio - b.precio);
    const precios  = lineas.map((l) => l.precio);
    const mejor    = precios[0], peor = precios[precios.length - 1];
    const promedio = precios.reduce((s, p) => s + p, 0) / precios.length;
    for (const l of lineas) { l.esMasBarato = l.precio === mejor; l.ahorroVsPromedio = parseFloat((promedio - l.precio).toFixed(2)); }
    return { productoId: producto.id, clave: producto.clave, nombre: producto.nombre, unidad: producto.unidad, ranking: lineas, mejorPrecio: parseFloat(mejor.toFixed(2)), peorPrecio: parseFloat(peor.toFixed(2)), promedio: parseFloat(promedio.toFixed(2)), ahorroMaximo: parseFloat((peor - mejor).toFixed(2)) };
}

export async function getResumen() {
    const productos = await prisma.productoCatalogo.findMany({ where: { activo: true } });
    const comparaciones = []; let ahorroTotal = 0;
    for (const prod of productos) {
        const comp = await compararProducto(prod.id);
        if (!comp) continue;
        comparaciones.push(comp);
        if (comp.ranking.length >= 2) ahorroTotal += comp.ahorroMaximo;
    }
    return { totalProductos: productos.length, productosComparados: comparaciones.filter((c) => c.ranking.length >= 2).length, ahorroTotalPosible: parseFloat(ahorroTotal.toFixed(2)), productos: comparaciones, generadoEn: new Date().toISOString() };
}

export async function registrarCotizacion(data: { proveedorId: string; productoId: string; precio: number; notas?: string }) {
    const r = await prisma.cotizacionProveedor.create({ data: { ...data, notas: data.notas ?? null } });
    return { id: r.id };
}
EOF
ok "src/modules/inteligencia/inteligencia.service.ts"

# =============================================================================
head "src/modules/inteligencia/inteligencia.router.ts"
# =============================================================================
cat > src/modules/inteligencia/inteligencia.router.ts << 'EOF'
import { Router, Request, Response } from 'express';
import { compararProducto, getResumen, registrarCotizacion } from './inteligencia.service';

export const inteligenciaRouter = Router();

inteligenciaRouter.get('/resumen', async (_req, res) => {
    try { res.json(await getResumen()); } catch (e) { res.status(500).json({ error: String(e) }); }
});

inteligenciaRouter.get('/producto/:id', async (req, res) => {
    try {
        const comp = await compararProducto(req.params.id);
        if (!comp) return res.status(404).json({ error: 'Sin cotizaciones.' });
        res.json(comp);
    } catch (e) { res.status(500).json({ error: String(e) }); }
});

inteligenciaRouter.post('/cotizacion', async (req: Request, res: Response) => {
    const { proveedorId, productoId, precio, notas } = req.body;
    if (!proveedorId || !productoId || precio == null || typeof precio !== 'number' || precio <= 0)
        return res.status(400).json({ error: 'proveedorId, productoId y precio (positivo) requeridos.' });
    try { res.status(201).json(await registrarCotizacion({ proveedorId, productoId, precio, notas })); }
    catch (e) { res.status(500).json({ error: String(e) }); }
});
EOF
ok "src/modules/inteligencia/inteligencia.router.ts"

# =============================================================================
head "src/brain/sentinel.py"
# =============================================================================
cat > src/brain/sentinel.py << 'EOF'
#!/usr/bin/env python3
import os, sys, time, signal, logging, requests, psutil
from datetime import datetime

HEALTH_URL          = "http://localhost:3000/api/health"
CHECK_INTERVAL_S    = 5
MAX_MEMORY_MB       = 400
MAX_SILENCE_S       = 120
MAX_RESTARTS        = 3
RESTART_COOLDOWN_S  = 15

os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler("logs/sentinel.log", encoding="utf-8")],
)
log = logging.getLogger("Sentinel")

class Sentinel:
    def __init__(self):
        self.restart_count = 0; self.consecutive_fails = 0; self.running = True
        signal.signal(signal.SIGINT, self._on_shutdown)
        signal.signal(signal.SIGTERM, self._on_shutdown)

    def _find_node(self):
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if 'tsx' in " ".join(proc.info.get('cmdline') or []) and 'src/index.ts' in " ".join(proc.info.get('cmdline') or []):
                    return proc
            except: continue
        return None

    def _fetch_health(self):
        try: return requests.get(HEALTH_URL, timeout=3).json()
        except: return None

    def _restart(self, reason):
        if self.restart_count >= MAX_RESTARTS:
            log.critical(f"Límite de {MAX_RESTARTS} reinicios. Intervención manual requerida.")
            self.running = False; return False
        log.warning(f"REINICIO #{self.restart_count + 1} — {reason}")
        proc = self._find_node()
        if proc:
            try: proc.send_signal(signal.SIGTERM); proc.wait(timeout=10)
            except psutil.TimeoutExpired: proc.kill()
            except psutil.NoSuchProcess: pass
        self.restart_count += 1; self.consecutive_fails = 0
        time.sleep(RESTART_COOLDOWN_S); return True

    def run(self):
        log.info(f"NicCore Sentinel V1 — ACTIVO | Pulso: {CHECK_INTERVAL_S}s | RAM máx: {MAX_MEMORY_MB}MB")
        while self.running:
            health = self._fetch_health()
            if health is None:
                self.consecutive_fails += 1
                log.warning(f"Sin respuesta #{self.consecutive_fails}")
                if self.consecutive_fails >= 3: self._restart(f"Health muerto ({self.consecutive_fails} intentos)")
                time.sleep(CHECK_INTERVAL_S); continue
            self.consecutive_fails = 0
            mem = health.get("memoryMB", 0); active = health.get("activeNodes", 0)
            silence = health.get("silenceMs", -1); uptime = health.get("uptime", 0)
            log.info(f"OK | RAM: {mem}MB | Nodos: {active} | Uptime: {uptime}s")
            if mem > MAX_MEMORY_MB: self._restart(f"RAM crítica: {mem}MB"); time.sleep(CHECK_INTERVAL_S); continue
            if MAX_SILENCE_S > 0 and silence > MAX_SILENCE_S * 1000 and active > 0 and uptime > 60:
                log.warning(f"Silencio: {silence/1000:.1f}s con {active} nodos activos.")
            time.sleep(CHECK_INTERVAL_S)

    def _on_shutdown(self, s, f): log.info("Deteniendo Sentinel..."); self.running = False

if __name__ == "__main__":
    Sentinel().run()
EOF
ok "src/brain/sentinel.py"

# =============================================================================
head "client/src/pages/RutasHistoricas.tsx"
# =============================================================================
cat > client/src/pages/RutasHistoricas.tsx << 'EOF'
import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Breadcrumb { lat: number; lon: number; spd: number; timestamp: string; }
interface ViajeResumen { tripId: string; inicio: string; fin: string; duracionMin: number; distanciaKm: number; }
interface ResumenNodo { nodeId: string; totalViajes: number; viajes: ViajeResumen[]; }
interface Viaje { tripId: string; nodeId: string; inicio: string; fin: string; duracionMin: number; distanciaKm: number; spdPromedio: number; spdMaxima: number; puntos: Breadcrumb[]; }

const API = 'http://localhost:3000/api';
const colorVel = (spd: number) => spd < 20 ? '#22c55e' : spd < 60 ? '#f59e0b' : '#ef4444';

export default function RutasHistoricas() {
    const mapRef     = useRef<HTMLDivElement>(null);
    const leafletMap = useRef<L.Map | null>(null);
    const layers     = useRef<L.LayerGroup | null>(null);
    const [nodeId, setNodeId]     = useState('');
    const [nodos,  setNodos]      = useState<string[]>([]);
    const [resumen, setResumen]   = useState<ResumenNodo | null>(null);
    const [viaje,  setViaje]      = useState<Viaje | null>(null);
    const [loading, setLoading]   = useState(false);

    useEffect(() => {
        if (!mapRef.current || leafletMap.current) return;
        leafletMap.current = L.map(mapRef.current, { center: [19.43, -99.13], zoom: 11 });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(leafletMap.current);
        layers.current = L.layerGroup().addTo(leafletMap.current);
    }, []);

    useEffect(() => {
        fetch(`${API}/rutas/nodos`).then((r) => r.json()).then((d) => setNodos(d.nodos ?? [])).catch(console.error);
    }, []);

    async function cargarViajes(nodo: string) {
        setNodeId(nodo); setResumen(null); setViaje(null); layers.current?.clearLayers(); setLoading(true);
        try { setResumen(await (await fetch(`${API}/rutas/nodo/${nodo}`)).json()); }
        catch (e) { console.error(e); } finally { setLoading(false); }
    }

    async function renderizarViaje(tripId: string) {
        layers.current?.clearLayers(); setLoading(true);
        try {
            const data: Viaje = await (await fetch(`${API}/rutas/viaje/${tripId}`)).json();
            setViaje(data);
            if (!leafletMap.current || !layers.current || data.puntos.length === 0) return;
            for (let i = 1; i < data.puntos.length; i++) {
                const a = data.puntos[i - 1], b = data.puntos[i];
                L.polyline([[a.lat, a.lon], [b.lat, b.lon]], { color: colorVel(a.spd), weight: 4, opacity: 0.85 }).addTo(layers.current);
            }
            const p0 = data.puntos[0], pN = data.puntos[data.puntos.length - 1];
            L.circleMarker([p0.lat, p0.lon], { radius: 8, color: '#16a34a', fillColor: '#22c55e', fillOpacity: 1 }).bindPopup(`<b>Inicio</b><br>${new Date(p0.timestamp).toLocaleTimeString()}`).addTo(layers.current);
            L.circleMarker([pN.lat, pN.lon], { radius: 8, color: '#b91c1c', fillColor: '#ef4444', fillOpacity: 1 }).bindPopup(`<b>Fin</b><br>${new Date(pN.timestamp).toLocaleTimeString()}`).addTo(layers.current);
            leafletMap.current.fitBounds(L.latLngBounds(data.puntos.map((p) => [p.lat, p.lon] as [number, number])), { padding: [32, 32] });
        } catch (e) { console.error(e); } finally { setLoading(false); }
    }

    const s: Record<string, React.CSSProperties> = {
        wrap:    { display: 'flex', height: '100vh', fontFamily: 'monospace' },
        panel:   { width: '300px', minWidth: '300px', background: '#0f172a', color: '#e2e8f0', display: 'flex', flexDirection: 'column', borderRight: '1px solid #1e293b' },
        header:  { padding: '16px', borderBottom: '1px solid #1e293b' },
        label:   { fontSize: '11px', color: '#64748b', marginBottom: '4px' },
        select:  { width: '100%', padding: '8px', background: '#1e293b', color: '#e2e8f0', border: '1px solid #334155', borderRadius: '4px' },
        stats:   { padding: '16px', borderBottom: '1px solid #1e293b' },
        list:    { flex: 1, overflowY: 'auto', padding: '8px' },
        map:     { flex: 1 },
    };

    return (
        <div style={s.wrap}>
            <div style={s.panel}>
                <div style={s.header}>
                    <div style={s.label}>NICCORE / RUTAS HISTÓRICAS</div>
                    <select value={nodeId} onChange={(e) => cargarViajes(e.target.value)} style={s.select}>
                        <option value="">— Seleccionar nodo —</option>
                        {nodos.map((n) => <option key={n} value={n}>{n}</option>)}
                    </select>
                </div>

                {viaje && (
                    <div style={s.stats}>
                        <div style={s.label}>VIAJE ACTIVO</div>
                        {[['Nodo', viaje.nodeId], ['Distancia', `${viaje.distanciaKm} km`], ['Duración', `${viaje.duracionMin} min`], ['Vel. prom.', `${viaje.spdPromedio} km/h`], ['Vel. máx.', `${viaje.spdMaxima} km/h`], ['Puntos', viaje.puntos.length]].map(([l, v]) => (
                            <div key={String(l)} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', fontSize: '12px' }}>
                                <span style={{ color: '#64748b' }}>{l}</span>
                                <span style={{ color: '#38bdf8' }}>{v}</span>
                            </div>
                        ))}
                        <div style={{ ...s.label, marginTop: '12px' }}>VELOCIDAD</div>
                        {[['#22c55e', '< 20 km/h'], ['#f59e0b', '20–60 km/h'], ['#ef4444', '> 60 km/h']].map(([c, l]) => (
                            <div key={String(l)} style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px', fontSize: '11px' }}>
                                <div style={{ width: '24px', height: '4px', background: String(c), borderRadius: '2px' }} />
                                <span>{l}</span>
                            </div>
                        ))}
                    </div>
                )}

                <div style={s.list}>
                    {loading && <div style={{ padding: '16px', color: '#64748b', fontSize: '12px' }}>Cargando...</div>}
                    {resumen && !loading && resumen.viajes.map((v) => (
                        <div key={v.tripId} onClick={() => renderizarViaje(v.tripId)} style={{ padding: '10px', marginBottom: '4px', background: viaje?.tripId === v.tripId ? '#1e3a5f' : '#1e293b', border: `1px solid ${viaje?.tripId === v.tripId ? '#38bdf8' : '#334155'}`, borderRadius: '4px', cursor: 'pointer' }}>
                            <div style={{ fontSize: '10px', color: '#38bdf8', marginBottom: '4px' }}>{new Date(v.inicio).toLocaleDateString('es-MX', { weekday: 'short', day: 'numeric', month: 'short' })}</div>
                            <div style={{ fontSize: '11px', color: '#94a3b8' }}>{new Date(v.inicio).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })} → {new Date(v.fin).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '4px', fontSize: '11px', color: '#64748b' }}>
                                <span>{v.distanciaKm} km</span><span>{v.duracionMin} min</span>
                            </div>
                        </div>
                    ))}
                    {resumen && !loading && resumen.viajes.length === 0 && <div style={{ padding: '16px', color: '#64748b', fontSize: '12px' }}>Sin viajes en los últimos 7 días.</div>}
                </div>
            </div>
            <div ref={mapRef} style={s.map} />
        </div>
    );
}
EOF
ok "client/src/pages/RutasHistoricas.tsx"

# =============================================================================
head "nicnode.sh (emisor Termux)"
# =============================================================================
cat > nicnode.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# NicCore Node Emisor V2
# Dependencias: pkg install termux-api netcat openssl jq
# Permisos: chmod 600 ~/.nicnode_secret && chmod +x nicnode.sh

NODE_ID="ZARCO_01"
SECRET="$(cat ~/.nicnode_secret)"
DEST_IP="TU_IP_PUBLICA_O_DDNS"
DEST_PORT="41234"
TRIP_ID="$(uuidgen)"
INTERVALO=3

echo "[NicNode] Nodo: $NODE_ID | Trip: $TRIP_ID"

while true; do
    RAW=$(termux-location -p gps -r once 2>/dev/null)
    if [ -z "$RAW" ]; then sleep $INTERVALO; continue; fi

    LAT=$(echo "$RAW" | jq -r '.latitude')
    LON=$(echo "$RAW" | jq -r '.longitude')
    VEL=$(echo "$RAW" | jq -r '.speed // 0' | awk '{printf "%.1f", $1 * 3.6}')
    TS=$(date +%s)

    CUERPO="${NODE_ID}|${LAT}|${LON}|${VEL}|${TS}|${TRIP_ID}"
    FIRMA=$(printf '%s' "$CUERPO" | openssl dgst -sha256 -hmac "$SECRET" | awk '{print $2}')

    printf '%s' "${CUERPO}|${FIRMA}" | nc -u -w1 "$DEST_IP" "$DEST_PORT"
    echo "[$(date '+%H:%M:%S')] TX → $CUERPO"
    sleep $INTERVALO
done
EOF
chmod +x nicnode.sh
ok "nicnode.sh"

# =============================================================================
head "prisma/schema — modelos a añadir (REFERENCIA)"
# =============================================================================
cat > prisma/niccore_models.prisma << 'EOF'
// ── AÑADIR al schema.prisma existente ────────────────────────────────────────

model node_breadcrumbs {
  id           String   @id @default(uuid())
  nodeId       String
  trip_id      String
  latitud      Float
  longitud     Float
  velocidadKmh Float
  timestamp    DateTime
  createdAt    DateTime @default(now())

  @@unique([nodeId, trip_id, timestamp])
  @@index([nodeId, timestamp])
  @@index([trip_id])
}

model Cliente {
  id         String            @id @default(uuid())
  nombre     String
  telefono   String
  telegramId String?
  activo     Boolean           @default(true)
  createdAt  DateTime          @default(now())
  cuentas    CuentaPorCobrar[]
}

model CuentaPorCobrar {
  id          String     @id @default(uuid())
  clienteId   String
  cliente     Cliente    @relation(fields: [clienteId], references: [id])
  concepto    String
  monto       Decimal    @db.Decimal(12, 2)
  montoPagado Decimal    @db.Decimal(12, 2) @default(0)
  fechaVenta  DateTime
  fechaVence  DateTime
  estado      String     @default("pendiente")
  notas       String?
  createdAt   DateTime   @default(now())
  alertas     AlertLog[]

  @@index([clienteId, estado])
  @@index([fechaVence, estado])
}

model AlertLog {
  id        String          @id @default(uuid())
  cuentaId  String
  cuenta    CuentaPorCobrar @relation(fields: [cuentaId], references: [id])
  canal     String
  nivel     Int
  enviado   Boolean         @default(false)
  error     String?
  createdAt DateTime        @default(now())

  @@index([cuentaId, nivel, createdAt])
}

model Proveedor {
  id           String                @id @default(uuid())
  nombre       String
  contacto     String?
  telefono     String?
  zona         String?
  activo       Boolean               @default(true)
  createdAt    DateTime              @default(now())
  cotizaciones CotizacionProveedor[]
}

model ProductoCatalogo {
  id           String                @id @default(uuid())
  clave        String                @unique
  nombre       String
  unidad       String
  activo       Boolean               @default(true)
  createdAt    DateTime              @default(now())
  cotizaciones CotizacionProveedor[]
}

model CotizacionProveedor {
  id          String           @id @default(uuid())
  proveedorId String
  proveedor   Proveedor        @relation(fields: [proveedorId], references: [id])
  productoId  String
  producto    ProductoCatalogo @relation(fields: [productoId], references: [id])
  precio      Decimal          @db.Decimal(10, 2)
  fecha       DateTime         @default(now())
  notas       String?

  @@index([productoId, fecha])
  @@index([proveedorId, productoId, fecha])
}
EOF
ok "prisma/niccore_models.prisma (referencia)"

# =============================================================================
head ".gitignore — entradas NicCore"
# =============================================================================
cat >> .gitignore << 'EOF'
.niccore_keys.json
.wwebjs_auth/
.wwebjs_cache/
logs/
EOF
ok ".gitignore actualizado"

# =============================================================================
head "RESUMEN FINAL"
# =============================================================================

echo ""
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${GREEN}  NicCore — Estructura creada exitosamente${RESET}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
echo "  SIGUIENTES PASOS:"
echo ""
echo "  1. Añadir modelos al schema:"
echo "     cat prisma/niccore_models.prisma >> prisma/schema.prisma"
echo ""
echo "  2. Migración:"
echo "     npx prisma migrate dev --name niccore_full_v1"
echo ""
echo "  3. Dependencias npm (raíz):"
echo "     npm install whatsapp-web.js qrcode-terminal"
echo ""
echo "  4. Dependencias npm (client/):"
echo "     cd client && npm install leaflet @types/leaflet"
echo ""
echo "  5. Dependencias Python:"
echo "     pip install psutil requests --break-system-packages"
echo ""
echo "  6. Variables de entorno (.env):"
echo "     NIC_NODE_KEYS='{\"ZARCO_01\":\"tu_secret_hex\"}'"
echo "     TELEGRAM_BOT_TOKEN=opcional"
echo "     CLIENT_ORIGIN=http://localhost:5173"
echo ""
echo "  7. Arrancar:"
echo "     npm run dev"
echo ""
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
