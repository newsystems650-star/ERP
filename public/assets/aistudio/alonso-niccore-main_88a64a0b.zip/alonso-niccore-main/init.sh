#!/bin/bash
echo "🚀 Iniciando NicCore LLIN..."

# 1. Limpieza de residuos
docker compose down --remove-orphans

# 2. Permisos del Búnker (Seguridad de escritura)
chmod 666 prisma/niccore_bunker.db

# 3. Construcción y levantamiento (Fuerza Bruta)
docker compose up -d --build

# 4. Sincronización de Base de Datos
docker compose exec api npx prisma generate
docker compose exec api npx prisma migrate deploy

echo "✅ Sistema operativo y motores sincronizados."
