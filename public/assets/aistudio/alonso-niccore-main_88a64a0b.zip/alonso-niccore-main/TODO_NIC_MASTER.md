# TODO: Nic-Master Editor (Air-Gapped Terminal IDE)

## Pasos
### 1. [x] src/core/nic_master.cpp (ncurses UI)
- Socket /tmp/nic_scanner.sock read metrics.
- Tacómetros ASCII (tsn/nsp/nec CPU/mem bars).
- File tree nav niccore/.
- Edit buffer, save verify USB key.
- Hex view toggle.

### 2. [x] Makefile target nic_master (g++ ncurses).

### 3. [ ] Build/test: `make nic_master`, `./bin/nic_master`.

Progress: 0/3
